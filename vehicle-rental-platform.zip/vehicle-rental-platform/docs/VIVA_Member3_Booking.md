# Viva Guide - Member 3: Booking & Return Management

## What I built

| Layer | Files |
|---|---|
| Model | `booking/RentalTransaction.java` (abstract), `Booking.java`, `BookingStatus.java` (enum) |
| Interfaces | `booking/FineCalculator.java`, `booking/AvailabilityChecker.java` |
| Fine rules | `RegularFineCalculator.java`, `PremiumFineCalculator.java` |
| Exception | `booking/VehicleNotAvailableException.java` (HTTP 409) |
| Service | `booking/BookingService.java` |
| Controller | `booking/BookingController.java` |
| Pages | `bookings/book.html`, `return.html`, `list.html` |
| Front end | `css/booking.css`, `js/booking.js` |
| Data | `data/bookings.txt` |

## CRUD map

| Operation | Page | HTTP | Java method |
|---|---|---|---|
| **Create** - book | `book.html` | `POST /api/bookings` | `BookingService.create()` |
| **Read** - price before booking | `book.html` | `GET /api/bookings/quote?...` | `quote()` |
| **Read** - list / filter | `list.html` | `GET /api/bookings?status=ACTIVE/OVERDUE/RETURNED&customerId=` | `search()` |
| **Read** - late fee preview | `return.html` | `GET /api/bookings/{id}/fine?returnDate=` | `finePreview()` |
| **Update** - return vehicle | `return.html` | `PUT /api/bookings/{id}/return` | `returnVehicle()` |
| **Update** - cancel | `list.html` | `PUT /api/bookings/{id}/cancel` | `cancel()` |
| **Delete** - completed only | `list.html` | `DELETE /api/bookings/{id}` | `delete()` |

## Class diagram

```
  <<interface>> FileStorable            <<interface>> AvailabilityChecker
          ^                                      ^
  <<abstract>> RentalTransaction                 |  implements
  - id, createdDate                     BookingService ----uses----> CustomerService (M1)
  + calculateTotal() {abstract}               |      \----uses-----> VehicleService  (M2)
  + getSummary() {abstract}                   | uses
          ^                                   v
       Booking                       <<interface>> FineCalculator
  - customerId, vehicleId ...         + calculateFine(daysLate, rate)
  - startDate, dueDate, returnDate    + getPolicyDescription()
  - baseCost, lateFee, status              ^                 ^
  + markReturned(), cancel()     RegularFineCalculator   PremiumFineCalculator
  + getDaysLate() / getDaysLate(date)   1.5 x rate/day     1 free day, then 1.0 x rate/day
```

## The booking flow (say this step by step)

1. Page asks for a **quote** while you change dates: shows days, standard price, member discount, availability.
2. `create()`:
   * finds the `Customer` (M1) and the `Vehicle` (M2),
   * validates dates (not in the past, return after pick-up, max 30 days),
   * checks the customer's limit with `customer.getMaxActiveBookings()` (2 Regular / 5 Premium - polymorphism),
   * calls `isVehicleAvailable()` - **abstraction**: the caller only gets true/false,
   * if not available, throws `VehicleNotAvailableException` (409),
   * price = `vehicle.calculateRentalCost(days, customer.getDiscountRate())` - **two polymorphic calls** in one line,
   * saves the booking and sets the vehicle to RENTED.
3. **Return:** the right `FineCalculator` is chosen by tier, the fine is calculated, `markReturned()` records it, the
   vehicle becomes AVAILABLE again, mileage is added, and the customer earns 10 loyalty points per day.

```java
FineCalculator calculator = fineCalculatorFor(b.getCustomerTier());   // interface type
double fine = calculator.calculateFine(b.getDaysLate(returnDate), b.getDailyRate());
```

**Demo:** `kasuni` (Regular) has booking `BKG-008`, which is overdue. On the Return page the fee is 1.5 x Rs. 7,500
per late day. A Premium booking (`BKG-009`, Amaya) returned two days late pays only one day (the grace day).

## OOP concepts - what to point at

**Encapsulation.** Fields are private and only change through methods that check rules: `markReturned()` refuses to
run twice or with a date before pick-up; `cancel()` only works on ACTIVE bookings. There is no `setStatus()`.

**Abstraction.** `AvailabilityChecker` interface (how availability is decided is hidden). `RentalTransaction` is
abstract; `calculateTotal()` has no body there.

**Inheritance.** `Booking extends RentalTransaction` and overrides `calculateTotal()` (base cost + late fee) and
`getSummary()`.

**Polymorphism.** "Different fine-calculation methods for regular and premium customers" - `FineCalculator`
interface with two implementations. Also uses M1's and M2's polymorphic methods.

**Overloading.** `getDaysLate()` (today or the actual return date) and `getDaysLate(LocalDate)`.

**Association.** A booking stores the *ids* of a customer and a vehicle (one-way association) plus a copy of their
names, so old bookings still read correctly if a vehicle is later removed.

**Custom exception.** `VehicleNotAvailableException extends AppException`, status 409 Conflict.

**SOLID - Dependency Inversion.** `BookingService` depends on the `FineCalculator` *interface*. A "Corporate" fine
rule could be added as a new class without touching the return code.

## Front-end features to show

* Booking page: a "rental ticket" that updates live (dates, discount, total counting up), availability badge,
  quick-date chips, and a **BOOKED** stamp on success. Staff can book for any customer.
* Return page: overdue bookings first with a red edge, live late-fee preview as you change the return date,
  **RETURNED** stamp receipt.
* List page: customers see "My bookings"; staff see all. Due-date progress bars, "Due in 2 days" / "Overdue by 2
  days", auto-refresh every 30 seconds, cancel and delete with confirmation.

## Likely viva questions

1. **Interface vs abstract class here?** `FineCalculator` is an interface: only behaviour, no shared fields, and a
   class could implement several interfaces. `RentalTransaction` is abstract because it shares fields (id, created
   date) and code.
2. **Where do you check availability?** `isVehicleAvailable()` - vehicle must be AVAILABLE and no ACTIVE booking
   overlaps the dates (`Booking.overlaps()`).
3. **Why can't active bookings be deleted?** The vehicle is still out; deleting would lose the record. Only
   RETURNED or CANCELLED transactions can be removed.
4. **How is a late fee calculated?** Days late = days between due date and return date. Regular: days x rate x 1.5.
   Premium: (days - 1) x rate.
5. **Which relationship does Booking have with Customer?** Association (uses-a); Booking keeps the customer id.
   BookingService has an association with CustomerService and VehicleService through its fields.
