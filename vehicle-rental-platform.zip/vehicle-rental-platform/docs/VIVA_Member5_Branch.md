# Viva Guide - Member 5: Branch Management

## What I built

| Layer | Files |
|---|---|
| Model | `branch/Branch.java` (abstract), `MainBranch.java`, `SubBranch.java` |
| Service | `branch/BranchService.java` |
| Controller | `branch/BranchController.java` |
| Pages | `branches/register.html`, `list.html`, `edit.html` |
| Front end | `css/branch.css`, `js/branch.js` |
| Data | `data/branches.txt` |

## CRUD map

| Operation | Page | HTTP | Java method |
|---|---|---|---|
| **Create** - add branch | `register.html` | `POST /api/branches` | `BranchService.create()` |
| **Read** - search by location or name | `list.html` | `GET /api/branches?q=&city=&type=` | `search()` |
| **Read** - city list | `list.html` | `GET /api/branches/cities` | `getCities()` (TreeSet) |
| **Read** - one | `edit.html` | `GET /api/branches/{id}` | `findById()` |
| **Update** - hours, contact, capacity | `edit.html` | `PUT /api/branches/{id}` | `update()` |
| **Delete** | `list.html` (staff), `edit.html` | `DELETE /api/branches/{id}` | `delete()` |

## Class diagram

```
              <<abstract>> Branch  implements FileStorable
              - id, name, city, address, phone, email
              - openingTime, closingTime : LocalTime, managerName
              + getType() {abstract}
              + getServices() {abstract}
              + getVehicleCapacity() {abstract}
              + getDisplayInfo() {abstract}
              + isOpenNow()
              + isOpenAt(LocalTime)         <- overloaded
              + isOpenAt(int hour, int min) <- overloaded
              + setOperatingHours(open, close)
                    ^                      ^
                    |                      |
               MainBranch               SubBranch
          - vehicleCapacity (>= 10)   - parentBranchId  ---> MainBranch  (one-way association)
          - hasServiceCenter          - vehicleCapacity (1..25)
```

## OOP concepts - what to point at

**Encapsulation.** Private fields with validation: name >= 3 characters, 10-digit phone, valid email, full address.
Opening and closing time can **only** be changed together through `setOperatingHours()`, which refuses a closing
time before the opening time. That keeps the object always in a valid state.

**Inheritance.** `MainBranch` and `SubBranch` reuse all location/contact/hours fields and methods from `Branch`.

**Abstraction.** `Branch` is abstract with four abstract methods.

**Polymorphism.** "Branch information displayed differently based on branch type":
```java
// MainBranch
public String getDisplayInfo() {
    return "Main branch in " + getCity() + " with space for " + vehicleCapacity + " vehicles"
            + (hasServiceCenter ? " and an on-site service workshop." : ".");
}
// SubBranch
public String getDisplayInfo() {
    return "Pick-up point in " + getCity() + " for up to " + vehicleCapacity
            + " vehicles, supported by main branch " + parentBranchId + ".";
}
```
`getServices()` also differs: a main branch offers long-term rentals, airport delivery and (if it has one) the
workshop; a sub branch only pick-up/drop-off and short rentals. The list page prints `displayInfo` and `services`
straight from the server, so the difference you see comes from the overridden Java methods.

**Overloading.** `isOpenAt(LocalTime)` and `isOpenAt(int hour, int minute)`; `isOpenNow()` calls `isOpenAt` with
the current time. Equal opening and closing times mean "open 24 hours" (the airport desk).

**Association.** A `SubBranch` stores the id of its parent `MainBranch` (one-way: the sub knows its parent, the
parent does not keep a list of subs).

**instanceof and downcasting.** In `update()` the service checks `if (b instanceof MainBranch)` before casting to
reach `setHasServiceCenter()`. In `delete()` it looks for any `SubBranch` whose parent is this branch.

**Business rules.**
* A sub branch must point to an existing **main** branch.
* A main branch that still supports sub branches cannot be deleted (try deleting Kandy Lake Branch in the demo).
* Branch names are unique.

**Collections.** `ArrayList<Branch>` for branches, `TreeSet<String>` for the city filter (removes duplicates and
sorts).

## How other modules use my work

* Vehicles (M2) store a `branchId`; the add/edit vehicle form lists my branches.
* The branch cards count how many vehicles are stationed at each branch.
* The home page and dashboard show "branches open now".

## Front-end features to show

* **Live opening status:** each card has a 24-hour bar with the open window in green and a red "now" needle. Every
  30 seconds the needle moves and the Open now / Closed badge updates. The JS uses the same rule as
  `Branch.isOpenAt()`.
* City chips (from `/cities`), type filter, "open now" filter, live search.
* Register/edit: Main vs Sub type cards; the parent-branch dropdown appears only for Sub; "Open 24 hours" switch;
  live preview card.
* Staff see edit/delete buttons; customers see a "Vehicles" button that opens the fleet filtered by that branch.

## Likely viva questions

1. **Why is `getDisplayInfo()` abstract?** Each branch type describes itself differently; the parent has no general
   text.
2. **Show overloading.** The two `isOpenAt` methods - same name, different parameters.
3. **What relationship is SubBranch to MainBranch?** One-way association through `parentBranchId`. It is **not**
   inheritance - a sub branch is not a kind of main branch.
4. **Why change opening and closing time in one method?** To keep the object valid; two separate setters could
   leave closing before opening for a moment.
5. **What does `instanceof` do and when is downcasting safe?** It checks the real class at run time; casting is
   safe right after a true `instanceof` check.
