# Work Distribution - Vehicle Rental Service Platform

SE1020 Object Oriented Programming | Team of 6 | Spring Boot + HTML/CSS/JS + `.txt` file storage

Every member owns **one CRUD entity, its own data file, its own Java package, 3-4 pages, one CSS file and one JS file**.
The backend work is split into six equal shares. The shared infrastructure was set up jointly at kickoff, so no
member carries extra backend load.

---

## Shared kickoff (all six members together)

| Area | Files |
|---|---|
| Project skeleton | `pom.xml`, `VehicleRentalApplication.java`, `application.properties`, `.gitignore`, `README.md` |
| Shared base class | `common/User.java` (abstract parent of `Customer` and `Admin`) |
| File storage | `common/FileStorable.java` (interface), `common/FileHandler.java` (static file utility), `common/IdGenerator.java` |
| Request handling | `common/RequestData.java` (validated form access, method overloading) |
| Error handling | `common/AppException.java` (abstract), `ValidationException`, `ResourceNotFoundException`, `GlobalExceptionHandler` |
| Front-end base | `static/index.html` (home), `contact.html`, `css/style.css`, `css/home.css`, `css/contact.css`, `js/app.js` (API helper, session, header/footer, toasts, vehicle photos), `js/home.js`, `js/contact.js` |
| Design assets | `images/backgrounds/` (hero, cars, vans, motorcycles, contact, login and road backgrounds from the design board), Poppins font |

---

## Member 1 - Component 01: User (Customer) Management

| | |
|---|---|
| **Java** | `Customer` (abstract, extends `User`), `RegularCustomer`, `PremiumCustomer`, `CustomerService`, `CustomerController` |
| **Pages** | `customers/register.html`, `customers/login.html`, `customers/profile.html`, `customers/list.html` (admin) |
| **Front end** | `css/customer.css`, `js/customer.js` |
| **Data** | `data/customers.txt` |
| **Create** | Register a customer (name, contact, driving licence) |
| **Read** | Search by ID, username, name, email or licence. Sign in |
| **Update** | Change email, phone, licence, password and membership tier (Regular / Premium) |
| **Delete** | Customer deletes own account. Admin deletes any account |
| **OOP** | Encapsulation (validated setters, hashed password). Inheritance (`User` > `Customer` > `Regular/PremiumCustomer`). Polymorphism (`authenticate()`, `getDiscountRate()`, `getMaxActiveBookings()`). Abstract class. Static counter and static factory `fromFileString()` |

## Member 2 - Component 02: Vehicle Management

| | |
|---|---|
| **Java** | `Vehicle` (abstract), `Car`, `Van`, `Motorcycle`, `VehicleStatus` (enum), `VehicleService`, `VehicleController` |
| **Pages** | `vehicles/cars.html`, `vans.html`, `motorcycles.html`, `search.html`, `add.html`, `edit.html`, `list.html` |
| **Photos** | `images/vehicles/` - 30 photos (10 cars, 10 vans, 10 motorcycles) and `manifest.json` for the photo picker |
| **Front end** | `css/vehicle.css`, `js/vehicle.js` |
| **Data** | `data/vehicles.txt` |
| **Create** | Add a car, van or motorcycle (model, brand, type, plate, rate, photo ...) |
| **Read** | Search by brand/model/plate, type, branch, maximum price, status. Price quote |
| **Update** | Edit details and photo, change availability status, correct mileage |
| **Delete** | Remove vehicles no longer in service (blocked while on rent) |
| **OOP** | Encapsulation. Inheritance (`Vehicle` > `Car/Van/Motorcycle`). Runtime polymorphism (`calculateRentalCost(days)`, `getFeatures()`, `applyTypeDetails()`). Compile-time polymorphism (overloaded `calculateRentalCost(days, discount)`). Abstract methods. Enum. Open/Closed principle |

## Member 3 - Component 03: Booking & Return Management

| | |
|---|---|
| **Java** | `RentalTransaction` (abstract), `Booking`, `BookingStatus` (enum), `FineCalculator` (interface), `RegularFineCalculator`, `PremiumFineCalculator`, `AvailabilityChecker` (interface), `VehicleNotAvailableException`, `BookingService`, `BookingController` |
| **Pages** | `bookings/book.html`, `bookings/return.html`, `bookings/list.html` |
| **Front end** | `css/booking.css`, `js/booking.js` |
| **Data** | `data/bookings.txt` |
| **Create** | Record a booking after checking availability |
| **Read** | All bookings, active / overdue / returned filters, due-date countdown, price quote, late-fee preview |
| **Update** | Return a vehicle (late fee calculated), cancel a booking |
| **Delete** | Remove completed (returned or cancelled) transactions |
| **OOP** | Encapsulation (`markReturned()` guards the state). Abstraction (`AvailabilityChecker`, abstract `RentalTransaction`). Polymorphism (`FineCalculator` Regular vs Premium). Association with Customer and Vehicle. Custom exception |

## Member 4 - Component 04: Admin & Staff Management

| | |
|---|---|
| **Java** | `Admin` (extends `User`, implements `AdminPrivileges`), `AdminPrivileges` (interface), `AdminRole` (enum with permissions), `ActivityLog`, `AdminService`, `AdminController` |
| **Pages** | `admin/login.html`, `admin/dashboard.html`, `admin/register.html`, `admin/staff.html` |
| **Front end** | `css/admin.css`, `js/admin.js` |
| **Data** | `data/admins.txt`, `data/admin_logs.txt` |
| **Create** | Register a staff account with a role |
| **Read** | Staff list, activity logs, live dashboard combining every module |
| **Update** | Edit profile, change role, activate / deactivate |
| **Delete** | Remove staff accounts (not yourself, not the last Super admin) |
| **OOP** | Encapsulation. Inheritance (`Admin extends User`). Abstraction (`AdminPrivileges` admin-only methods). Polymorphism (overridden `authenticate()`, `getRole()`). Composition (`Admin` owns its `ActivityLog` objects). Enum with constructor |

## Member 5 - Component 05: Branch Management

| | |
|---|---|
| **Java** | `Branch` (abstract), `MainBranch`, `SubBranch`, `BranchService`, `BranchController` |
| **Pages** | `branches/register.html`, `branches/list.html`, `branches/edit.html` |
| **Front end** | `css/branch.css`, `js/branch.js` |
| **Data** | `data/branches.txt` |
| **Create** | Add a main branch or a sub branch (name, location, contact, hours) |
| **Read** | Search by name, city, type, open now |
| **Update** | Change operating hours, contact details, capacity |
| **Delete** | Remove branches (a main branch with sub branches is protected) |
| **OOP** | Encapsulation (`setOperatingHours()` keeps times consistent). Inheritance (`Branch` > `MainBranch/SubBranch`). Polymorphism (`getDisplayInfo()`, `getServices()`). Overloading (`isOpenAt(LocalTime)` / `isOpenAt(int, int)`). Association (`SubBranch` > parent id). `instanceof` and downcasting |

## Member 6 - Component 06: Feedback and Review Management

| | |
|---|---|
| **Java** | `Review` (abstract), `PublicReview`, `VerifiedReview`, `ReviewStatus` (enum), `ContentModerator` (static), `ReviewService`, `ReviewController` |
| **Pages** | `reviews/submit.html`, `reviews/view.html`, `reviews/moderate.html` |
| **Front end** | `css/review.css`, `js/review.js` |
| **Data** | `data/reviews.txt` |
| **Create** | Customer submits a rating and review (becomes Verified if they rented that vehicle) |
| **Read** | Public reviews per vehicle, rating summary, admin moderation view |
| **Update** | Customer edits own review. Admin publishes / flags / hides |
| **Delete** | Author or moderator deletes a review |
| **OOP** | Encapsulation. Inheritance (`Review` > `PublicReview/VerifiedReview`). Polymorphism (`displayForCustomer()` vs `displayForAdmin()`, `getWeight()`). Static utility class. Uses the `AdminPrivileges` interface type |

---

## Lecture concepts and where each member uses them

| Lecture topic | M1 | M2 | M3 | M4 | M5 | M6 |
|---|---|---|---|---|---|---|
| L1-2 Class, object, access modifiers, encapsulation | Customer | Vehicle | Booking | Admin | Branch | Review |
| L2 Default + overloaded constructors | Customer | Car/Van/Motorcycle | Booking | Admin | MainBranch | VerifiedReview |
| L2 Method overloading | (RequestData) | calculateRentalCost | getDaysLate | ActivityLog ctor | isOpenAt | - |
| L3 Noun/verb analysis, CRC | customer, register, login | vehicle, add, search | booking, return, fine | admin, permission | branch, hours | review, rate, moderate |
| L4 Inheritance | User > Customer > 2 types | Vehicle > 3 types | RentalTransaction > Booking | User > Admin | Branch > 2 types | Review > 2 types |
| L4 Polymorphism (overriding) | authenticate | calculateRentalCost | FineCalculator | authenticate | getDisplayInfo | displayFor... |
| L4 Composition / aggregation / association | - | - | Booking > Customer, Vehicle | Admin owns ActivityLog | SubBranch > MainBranch | Review > Vehicle, Booking |
| L5 Abstract class | Customer | Vehicle | RentalTransaction | User (shared) | Branch | Review |
| L5 Interface | FileStorable | FileStorable | FineCalculator, AvailabilityChecker | AdminPrivileges | FileStorable | FileStorable |
| L5 static | objectsCreated, fromFileString | createEmpty | constants | AdminRole constants | fromFileString | ContentModerator |
| L6 Exceptions (custom, try/catch) | ValidationException | ValidationException | VehicleNotAvailableException | ValidationException | ValidationException | ValidationException |
| L7 SOLID | SRP layers | Open/Closed | Dependency Inversion | Interface Segregation | Liskov | SRP |
| L8 ArrayList + generics | `ArrayList<Customer>` | `ArrayList<Vehicle>` | `ArrayList<Booking>` | `ArrayList<Admin>`, `ArrayList<ActivityLog>` | `ArrayList<Branch>` | `ArrayList<Review>` |
