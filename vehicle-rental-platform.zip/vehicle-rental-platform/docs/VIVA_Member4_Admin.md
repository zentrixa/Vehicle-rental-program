# Viva Guide - Member 4: Admin & Staff Management

## What I built

| Layer | Files |
|---|---|
| Model | `admin/Admin.java` (extends `User`), `ActivityLog.java`, `AdminRole.java` (enum) |
| Interface | `admin/AdminPrivileges.java` |
| Service | `admin/AdminService.java` |
| Controller | `admin/AdminController.java` |
| Pages | `admin/login.html`, `dashboard.html`, `register.html`, `staff.html` |
| Front end | `css/admin.css`, `js/admin.js` |
| Data | `data/admins.txt`, `data/admin_logs.txt` |

## CRUD map

| Operation | Page | HTTP | Java method |
|---|---|---|---|
| Sign in | `login.html` | `POST /api/admins/login` | `AdminService.login()` |
| **Create** - register staff | `register.html` | `POST /api/admins` | `create()` |
| **Read** - staff list | `staff.html` | `GET /api/admins?q=&role=` | `search()` |
| **Read** - activity logs | `staff.html`, `dashboard.html` | `GET /api/admins/{id}/logs`, `/logs/recent` | `getLogs()`, `getRecentLogs()` |
| **Read** - roles + permissions | `register.html` | `GET /api/admins/roles` | `AdminRole.values()` |
| **Update** - profile / role | `register.html?id=` | `PUT /api/admins/{id}` | `update()` |
| **Update** - activate / deactivate | `staff.html` | `PATCH /api/admins/{id}/active` | `setActive()` |
| **Delete** | `staff.html` | `DELETE /api/admins/{id}?actingAdminId=` | `delete()` |

## Class diagram

```
        <<abstract>> User (shared)            <<interface>> AdminPrivileges
                 ^                            + canManageStaff()
                 |  extends                   + canDeleteRecords()
                 |                            + canModerateReviews()
               Admin  ---------implements---->+ hasPermission(p)
               - adminRole : AdminRole        + getPermissions()
               - active : boolean
               - activityLogs : ArrayList<ActivityLog>   <>------ ActivityLog
               + logActivity(action)          (composition,        - adminId
               + authenticate()  {override}     filled diamond)     - timestamp
               + getRole()       {override}                         - action

  <<enum>> AdminRole: SUPER_ADMIN, MANAGER, STAFF  (each with a label and a permission list)
```

## Roles

| Role | Permissions |
|---|---|
| Super admin | Manage staff, fleet, bookings, customers, branches, moderate reviews, delete records |
| Branch manager | Fleet, bookings, customers, branches, moderate reviews |
| Counter staff | Bookings, moderate reviews |

## OOP concepts - what to point at

**Inheritance.** "Admin inherits from the shared User base class" - `Admin extends User`, exactly like
`Customer`. Both reuse username, email, phone, password hashing and validation.

**Abstraction (admin-only methods).** `AdminPrivileges` declares the abilities only staff have. Only `Admin`
implements it; `Customer` never gets these methods (Interface Segregation). Review moderation (M6) checks a
moderator through this interface type:
```java
AdminPrivileges moderator = adminService.findById(adminId);
if (!moderator.canModerateReviews()) { throw new ValidationException("Your role cannot moderate reviews"); }
```

**Polymorphism.** `Admin` overrides `authenticate()`: accepts username or email **and** refuses deactivated
accounts. `getRole()` (abstract in `User`) returns `SUPER_ADMIN`, `MANAGER` or `STAFF`.

**Encapsulation.** Fields are private. `getActivityLogs()` returns `Collections.unmodifiableList(...)`, so outside
code can read logs but not delete them. The `ActivityLog` constructor is package-private: only classes in the
admin package can create logs.

**Composition (Lecture 4).** An `Admin` *owns* its `ActivityLog` objects - they are created inside
`logActivity()` and are deleted together with the admin. That is the "part cannot exist without the whole"
relationship (filled diamond).

**Enum with a constructor.** `AdminRole` stores a label and a permission list for each constant.

**Business rules (validation + custom exceptions).**
* Only a Super admin can create, edit roles, deactivate or delete staff.
* You cannot deactivate or delete your own account.
* The last active Super admin can never be removed (otherwise nobody could manage staff).
* On first run, if `admins.txt` is empty, a default `admin / admin123` account is created.

## Dashboard (reads every module)

The dashboard calls the APIs of all six modules at once (`Promise.all`) and refreshes every 15 seconds:
revenue and late fees (M3), vehicles on rent and the fleet status donut (M2), customers (M1), branches open now
(M5), average rating and flagged reviews (M6), overdue returns with a Return button (M3), and the **live staff
activity feed** (M4). Every page in the admin area records actions with `Session.logAdminAction()`, which
calls `POST /api/admins/{id}/logs`, so the feed shows what staff did in every module. New entries flash in.
Quick actions are greyed out when your role lacks the permission.

## Front-end features to show

* Staff sign-in page with demo accounts. Wrong password shakes the form.
* Register page: role cards list their permissions (read from the enum through `/api/admins/roles`), and a staff
  ID badge previews live and swings in.
* Staff panel: cards with permission chips, last active time, activate/deactivate switch, activity timeline dialog.

## Likely viva questions

1. **Why does `Admin` extend `User` and not `Customer`?** An admin is not a customer; both are kinds of users that
   can sign in. Shared code lives in `User`.
2. **Composition vs aggregation?** Composition: logs belong to one admin and die with it. Aggregation would be parts
   that can live on their own (e.g. vehicles belonging to a branch).
3. **Why an interface for privileges?** It separates admin-only behaviour from the user model, and other modules
   can depend on "something that can moderate" instead of the concrete `Admin` class.
4. **How is a deactivated account stopped?** `Admin.authenticate()` returns false when `active` is false.
5. **How do you stop someone deleting the last Super admin?** `countActiveSuperAdmins()` in the service.
