# Viva Guide - Shared Core (every member should know this)

## 1. The big picture in one minute

> "Our system is a Spring Boot web application. The browser shows HTML pages. JavaScript on each page
> calls our REST API with `fetch()`. A **Controller** receives the request and passes it to a **Service**,
> which applies the business rules on an `ArrayList` of model objects. After every change, the Service saves
> the list to a `.txt` file using the shared `FileHandler`. Each of us owns one module: model classes,
> service, controller, data file, pages, CSS and JS."

```
Browser page (HTML)
   |  user clicks "Save"
   v
module.js  --fetch("/api/vehicles", POST, JSON)-->  VehicleController   (HTTP only)
                                                         |
                                                         v
                                                   VehicleService      (rules, ArrayList<Vehicle>)
                                                         |
                                                         v
                                             Car / Van / Motorcycle    (data + behaviour)
                                                         |
                                                         v
                                   FileHandler.writeAll("vehicles.txt", vehicles)
```

## 2. Why this layer structure? (SOLID - Lecture 7)

| Principle | Where we show it |
|---|---|
| **S** Single Responsibility | Model = data + its own behaviour, Service = rules + storage, Controller = HTTP only, JS = page behaviour |
| **O** Open/Closed | Add a `Truck` class extending `Vehicle` without changing search, update or delete code |
| **L** Liskov Substitution | Anywhere a `Customer` is expected, a `RegularCustomer` or `PremiumCustomer` works |
| **I** Interface Segregation | `AdminPrivileges` holds admin-only methods, so `Customer` is not forced to have them |
| **D** Dependency Inversion | `BookingService` uses the `FineCalculator` interface, not a concrete class. Spring injects services through constructors |

## 3. Shared classes (`com.vehiclerental.common`)

| Class | Concept | What to say |
|---|---|---|
| `User` | **Abstract class**, encapsulation, inheritance | Parent of `Customer` (M1) and `Admin` (M4). Holds username, email, phone, password hash. `getRole()` is abstract. `authenticate()` is a normal method that children **override**. Setters validate data (email pattern, 10-digit phone). Passwords are hashed with SHA-256 and the hash getter is hidden from JSON with `@JsonIgnore`. |
| `FileStorable` | **Interface** | Contract: `getId()` and `toFileString()`. Every model implements it, so `FileHandler.writeAll()` can save *any* module's list (polymorphism through an interface). |
| `FileHandler` | **static** methods, static block, **try / catch / finally** | Utility class with a private constructor, so it is never instantiated. The static block creates the `data` folder once. `readLines()` uses a classic try/catch/finally to always close the reader. |
| `IdGenerator` | static | Finds the largest existing number and returns the next id (`VEH-014`). |
| `RequestData` | **Method overloading**, encapsulation | `getString(key)` (required) vs `getString(key, default)` (optional). Same for `getInt`, `getDouble`. Missing or invalid values throw `ValidationException`. |
| `AppException` | **Abstract class + custom exceptions** | Abstract `getStatusCode()`. `ValidationException` returns 400, `ResourceNotFoundException` returns 404, `VehicleNotAvailableException` (M3) returns 409. |
| `GlobalExceptionHandler` | Polymorphism | One `@ExceptionHandler(AppException.class)` handles every custom exception: `ex.getStatusCode()` runs the child's version. |

## 4. How a `.txt` file is read and written

```
customers.txt
PREMIUM|CUS-001|nimal|Nimal Perera|nimal.perera@gmail.com|0771234567|<sha256 hash>|B1234567|2026-03-14|140
```

* **Write:** `customer.toFileString()` joins the fields with `|` (`FileHandler.join`).
* **Read:** `Customer.fromFileString(line)` is a **static factory method**. It splits the line and looks at the
  first field to decide which child object to create (`new PremiumCustomer()` or `new RegularCustomer()`).
* At start-up each Service loads its file into an `ArrayList`.
* **Works on any computer:** files are read and written as **UTF-8** (Windows otherwise uses another encoding), and if a
  data file is missing it is restored from the demo copy in `src/main/resources/seed-data/` (`getResourceAsStream` +
  `Files.copy`). The data folder is found even if IntelliJ was opened one folder too high. The start-up message prints
  the address to open and the data folder in use. After each create/update/delete it rewrites the file.

## 5. Spring Boot words you may be asked about

| Term | Meaning in our project |
|---|---|
| Spring Boot 4.1.1 | The framework version. Runs on Java 17 to 26; the code is compiled for Java 17 so it works on any of them |
| `@SpringBootApplication` | Marks the main class; Spring scans all our packages |
| `@Service` | Spring creates **one** object of this class and shares it |
| `@RestController` | Methods return data (JSON), not HTML views |
| `@RequestMapping("/api/vehicles")` | Base URL of a controller |
| `@GetMapping` `@PostMapping` `@PutMapping` `@PatchMapping` `@DeleteMapping` | Read / Create / Update / partial update / Delete |
| `@PathVariable` | Value from the URL, e.g. `/api/vehicles/{id}` |
| `@RequestParam` | Value after `?`, e.g. `?type=CAR` |
| `@RequestBody` | The JSON the page sent, received as a `Map` and wrapped in `RequestData` |
| Constructor injection | `public BookingController(BookingService s)` - Spring passes the service in |
| `ResponseEntity` | Response with a status code (200, 201 Created, 400 ...) |
| Jackson (version 3) | Library that turns our objects into JSON using their getters. Dates become text like 2026-10-10 |

## 6. Front-end shared library (`js/app.js`)

* `api.get/post/put/patch/del` - wraps `fetch()`, throws an `Error` with the server's message.
* `Session` - remembers who is signed in (customer or admin) in `localStorage`.
* `toast()`, `confirmDialog()`, `openModal()` - feedback and confirmation dialogs.
* `ui.vehicleMedia(v)` shows the vehicle's photo (`v.imageUrl`) and falls back to `ui.vehicleArt()`, an SVG drawing, when a vehicle
  has no photo or the image fails to load. `ui.plate()` draws a licence plate, `ui.countUp()` animates numbers.
* The header is transparent over the page photo and turns solid when you scroll (`.site-header.solid`).
* Draws the same header, admin bar and footer on every page.

## 7. Shared pages and design

* **Home (`index.html`)** - recreated from the design board: coastal-road hero with the pick-up location / date search bar,
  a live strip (vehicles ready, on the road, branches open, average rating - refreshed every 15 seconds), category tiles for
  Cars / Vans / Motorcycles, vehicles with photos, the "More Than Just a Ride" band, the features band, branches, a reviews
  marquee and membership tiers. It reads data from all six modules.
* **Contact (`contact.html`)** - contact cards, live branch phone numbers and opening status (Member 5's API), quick-answer
  FAQ, and a message form that opens the visitor's email app (the system has no message storage, so nothing is faked).
* **Backgrounds** - `images/backgrounds/*.jpg` were cropped from the design board. A CSS class such as `bg-cars` on a page
  header picks the photo (`.page-band.photo.bg-cars`).
* **Theme** - deep teal-black with a green accent, Poppins font, the white car logo with "Drive Your Freedom".

## 8. Honest limitations (good to mention if asked "what would you improve?")

* Sign-in is kept in the browser (`localStorage`). A real system would use server sessions or tokens (Spring Security).
* The background photos come from the design board image, so they are lower resolution than original photos would be.
  Replace a file in `images/backgrounds/` with a sharper photo of the same name and every page updates.
* `.txt` files are fine for coursework. A database (MySQL with JPA) would handle many users at once better.
* Services use `synchronized` methods so two requests cannot write a file at the same moment.
