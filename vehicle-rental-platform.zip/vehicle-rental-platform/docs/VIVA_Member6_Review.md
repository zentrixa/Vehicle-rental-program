# Viva Guide - Member 6: Feedback and Review Management

## What I built

| Layer | Files |
|---|---|
| Model | `review/Review.java` (abstract), `PublicReview.java`, `VerifiedReview.java`, `ReviewStatus.java` (enum) |
| Helper | `review/ContentModerator.java` (static checker) |
| Service | `review/ReviewService.java` |
| Controller | `review/ReviewController.java` |
| Pages | `reviews/submit.html`, `view.html`, `moderate.html` |
| Front end | `css/review.css`, `js/review.js` |
| Data | `data/reviews.txt` |

## CRUD map

| Operation | Page | HTTP | Java method |
|---|---|---|---|
| **Create** - submit review | `submit.html` | `POST /api/reviews` | `ReviewService.create()` |
| **Read** - customer view | `view.html`, home page | `GET /api/reviews?vehicleId=` | `getPublicView()` -> `displayForCustomer()` |
| **Read** - admin view | `moderate.html` | `GET /api/reviews/admin?status=&q=` | `getAdminView()` -> `displayForAdmin()` |
| **Read** - rating summary | `view.html`, dashboard | `GET /api/reviews/summary?vehicleId=` | `summary()` |
| **Update** - edit own review | `submit.html?edit=` | `PUT /api/reviews/{id}` | `update()` |
| **Update** - moderate | `moderate.html` | `PATCH /api/reviews/{id}/status` | `moderate()` |
| **Delete** - author or moderator | `submit.html`, `moderate.html` | `DELETE /api/reviews/{id}?customerId= / adminId=` | `delete()` |

## Class diagram

```
            <<abstract>> Review  implements FileStorable
            - id, vehicleId, vehicleName, customerId, customerName
            - rating (1-5), title, comment, createdDate, editedDate
            - status : ReviewStatus, flagReason
            + getType() {abstract}
            + getBadge() {abstract}
            + getWeight() {abstract}
            + displayForCustomer() : Map
            + displayForAdmin() : Map
            + edit(), moderate()
                 ^                         ^
                 |                         |
           PublicReview              VerifiedReview
           weight 1.0                - bookingId
           "Customer review"         weight 1.5, "Verified rental"
                                     overrides displayForCustomer()/displayForAdmin() using super

  ContentModerator (static): findIssue(text) -> blocked words, links, ALL CAPS
```

## OOP concepts - what to point at

**Encapsulation.** Private fields; `setRating()` only accepts 1-5, title 3-80 characters, comment 10-1000. The
status can only change through `moderate()`, which also clears the reason when a review is published.

**Inheritance.** "PublicReview and VerifiedReview classes" both extend `Review`.

**Polymorphism.** "Different display methods for admin and regular customers":
```java
// Review (parent)
public Map<String, Object> displayForCustomer() { ... author = "Nimal P." ... }   // short name, no moderation data
public Map<String, Object> displayForAdmin() {
    Map<String, Object> map = displayForCustomer();
    map.put("author", customerName);         // full name
    map.put("status", status.name());        // + moderation data
    map.put("flagReason", flagReason);
    map.put("weight", getWeight());
    return map;
}
// VerifiedReview (child) - extends the parent's output with super
@Override
public Map<String, Object> displayForAdmin() {
    Map<String, Object> map = super.displayForAdmin();
    map.put("bookingId", bookingId);
    return map;
}
```
The controller returns `displayForCustomer()` on the public page and `displayForAdmin()` on the moderation page:
two views of the same object.

`getWeight()` is overridden too: a verified review counts 1.5 times in the **weighted average**
(`summary()`), a public review 1.0.

**How a review becomes Verified.** In `create()` the service asks Booking (M3):
`bookingService.findCompletedRental(customerId, vehicleId)`. If the customer has a RETURNED booking for that
vehicle, a `VerifiedReview` is created with that booking id; otherwise a `PublicReview`. After that, the rest of
the code only uses the `Review` type.

**static.** `ContentModerator` is a utility class with a static word list and a static `findIssue()` method; it
has a private constructor. New or edited reviews containing a blocked word, a link, or mostly capitals are
automatically **FLAGGED**, which hides them from the public until a moderator decides.

**Interface type from another module.** Moderation checks the admin through `AdminPrivileges`
(`canModerateReviews()`) from Member 4.

**Rules.** One review per customer per vehicle. Only the author can edit. The author **or** a moderator can delete.
Customers see their own flagged/hidden reviews with a notice; others do not.

## Front-end features to show

* **Animated star rating input:** hover previews the stars and the word (Poor ... Excellent), clicking pops each star.
* Submit page tells you before posting whether your review will be Verified (it checks your returned bookings),
  live preview card, character counter, "My reviews" list with edit links. Edit mode adds a Delete button.
* View page: big average that counts up, weighted rating, animated star-distribution bars (click a bar to filter),
  verified/5-star/low filters, sort.
* Home page: reviews scroll in a continuous marquee.
* Moderation: Flagged / Published / Hidden tabs with counts, the automatic flag reason, Publish / Hide / Flag /
  Delete actions with a reason dialog; cards slide out after an action.

**Demo:** sign in as `nimal`, review a vehicle with the word "trash" in it, and it is held for moderation. Then
sign in as `admin` and publish or hide it.

## Likely viva questions

1. **Where is the polymorphism the brief asks for?** `displayForCustomer()` / `displayForAdmin()` (two views),
   overridden in `VerifiedReview` with `super`; plus `getWeight()`, `getBadge()`, `getType()`.
2. **Why abstract `Review`?** Every review is either public or verified; `getWeight()` and `getBadge()` have no
   sensible default.
3. **Why is `ContentModerator` static?** It has no per-object data; one shared word list and a pure function.
4. **How is the weighted average computed?** Sum of (rating x weight) / sum of weights, visible reviews only.
5. **What relationships does Review have?** Association with Vehicle, Customer and (for verified reviews) Booking,
   through stored ids.
