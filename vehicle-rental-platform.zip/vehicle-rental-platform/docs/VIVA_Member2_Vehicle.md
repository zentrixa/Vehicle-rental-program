# Viva Guide - Member 2: Vehicle Management

## What I built

| Layer | Files |
|---|---|
| Model | `vehicle/Vehicle.java` (abstract), `Car.java`, `Van.java`, `Motorcycle.java`, `VehicleStatus.java` (enum) |
| Service | `vehicle/VehicleService.java` |
| Controller | `vehicle/VehicleController.java` |
| Pages | `vehicles/cars.html`, `vans.html`, `motorcycles.html`, `search.html`, `add.html`, `edit.html`, `list.html` |
| Photos | `images/vehicles/{cars,vans,motorcycles}/*.jpg` (30 photos) and `images/vehicles/manifest.json` |
| Front end | `css/vehicle.css`, `js/vehicle.js` |
| Data | `data/vehicles.txt` |

## CRUD map

| Operation | Page | HTTP | Java method |
|---|---|---|---|
| **Create** - add vehicle | `add.html` | `POST /api/vehicles` | `VehicleService.add()` |
| **Read** - search | `search.html`, `list.html` | `GET /api/vehicles?q=&type=&status=&branchId=&maxRate=` | `search()` |
| **Read** - by category | `cars.html`, `vans.html`, `motorcycles.html` | `GET /api/vehicles?type=CAR` (or VAN / MOTORCYCLE) | `search()` |
| **Read** - one / quote / stats | `edit.html`, search dialog | `GET /api/vehicles/{id}`, `/{id}/quote?days=`, `/stats` | `findById()`, `quote()`, `getStats()` |
| **Update** - details | `edit.html` | `PUT /api/vehicles/{id}` | `update()` |
| **Update** - availability | `list.html` | `PATCH /api/vehicles/{id}/status` | `updateStatus()` |
| **Delete** | `edit.html`, `list.html` | `DELETE /api/vehicles/{id}` | `delete()` |

## Class diagram

```
                 <<abstract>> Vehicle  implements FileStorable
                 - id, brand, model, year, plateNumber, dailyRate, mileage
                 - status : VehicleStatus, branchId, colour, fuelType
                 + getType() {abstract}
                 + getCategory() {abstract}
                 + calculateRentalCost(days) {abstract}
                 + calculateRentalCost(days, discount)      <- overloaded, concrete
                 + getFeatures() {abstract}
                 + applyTypeDetails(data) {abstract}
                 + fromFileString(line) {static}
                   ^             ^              ^
                   |             |              |
                  Car           Van         Motorcycle
           seats,          seats,            engineCc,
           transmission    cargoCapacityKg   helmetIncluded
```

## Pricing rules (the heart of the polymorphism)

| Class | `calculateRentalCost(days)` |
|---|---|
| `Car` | rate x days, **10% off** when days >= 7 |
| `Van` | rate x days **+ Rs. 2,000 cleaning fee** |
| `Motorcycle` | rate x days, + Rs. 150/day if no helmet, **5% off** when days >= 3 |

```java
// in Vehicle (parent) - overloaded version, works for every child
public double calculateRentalCost(int days, double discountRate) {
    double cost = calculateRentalCost(days);      // runs the CHILD version (runtime polymorphism)
    return Math.round(cost * (1 - discountRate) * 100.0) / 100.0;
}
```

**Demo:** open a vehicle on the search page and move the "rental days" slider. Drag a car past 7 days and the
price drops; a van always has the cleaning fee. The page calls `/api/vehicles/{id}/quote`.

## OOP concepts - what to point at

**Encapsulation.** Private fields; setters validate: plate must match `PLATE_PATTERN` (`CAB-1234`), rate > 0, year
between 1990 and next year, mileage not negative, seats in range per type.

**Inheritance.** `Car`, `Van`, `Motorcycle` extend `Vehicle` and reuse 11 common fields and all getters/setters.
Child constructors call `super(...)`.

**Abstraction.** `Vehicle` is abstract and has 6 abstract methods; the parent cannot know how "a vehicle" is
priced or which extra fields it has.

**Polymorphism.**
* Runtime: `calculateRentalCost(days)`, `getCategory()`, `getFeatures()`, `applyTypeDetails()`.
* Compile time: the two `calculateRentalCost` methods (overloading).
* The service keeps one `ArrayList<Vehicle>` that holds all three types.

**Enum.** `VehicleStatus` (AVAILABLE, RENTED, MAINTENANCE) has a constructor and a `label` field. Using an enum
means a status can never be a misspelt string.

**static.** `Vehicle.fromFileString()` and `Vehicle.createEmpty(type)` are static factory methods.

**Open/Closed principle.** To add a `Truck`: create `class Truck extends Vehicle`, add one `case` in
`createEmpty()`/`build()`. Search, update, delete and the pages keep working unchanged.

**Business rules.** Plate numbers are unique. A vehicle **on rent cannot be deleted**. Lowering mileage needs the
"correct mileage" tick box (prevents typing mistakes).

## Vehicle photos (imageUrl)

Every vehicle has a private `imageUrl` field, for example `/images/vehicles/cars/toyota-prius.jpg`.

* **Encapsulation:** `setImageUrl()` only accepts an empty value or a path/web address ending in jpg, jpeg, png or webp
  (`IMAGE_PATTERN`). Anything else throws `ValidationException`.
* **File storage:** `imageUrl` is written as the **last** field of each line in `vehicles.txt`. `fromFileString()` reads it
  only if the line has it (`p.length > 14`), so older files without photos still load (backward compatible).
* **Update / remove:** `VehicleService.update()` uses `RequestData.contains("imageUrl")`: an empty value sent on purpose
  removes the photo, and leaving the field out keeps the current one.
* **JSON:** `getImageUrl()` and `isHasPhoto()` are sent to the browser. The page shows the photo, or the SVG drawing when
  there is none.
* **Photo picker (add/edit pages):** reads `manifest.json` and shows the gallery in tabs (Cars / Vans / Motorcycles).
  Typing a brand and model that match a gallery photo (e.g. "Toyota" + "Prius") selects it automatically. A path can
  also be typed in.

The fleet has **30 vehicles**: 10 cars, 10 vans and 10 motorcycles, each matched to its photo.

## Category pages

`cars.html`, `vans.html` and `motorcycles.html` each use one background from the design board and call
`GET /api/vehicles?type=...`. They show stats (how many, how many ready now, cheapest daily rate, branches), live search,
an "available now" filter, sorting, and the same details dialog with the polymorphic price slider. `Van.getCategory()`
now has three answers: Passenger van (10+ seats), Family van / MPV (6-9 seats) and Cargo van.

## How other modules use my work

* Booking (M3) calls `calculateRentalCost(days, discount)` and `updateStatus()` (RENTED when booked, AVAILABLE
  when returned) and `addMileage()` on return.
* Branch (M5) counts vehicles per branch with `branchId`. Reviews (M6) use `getDisplayName()`.

## Front-end features to show

* Cars / Vans / Motorcycles pages: photo cards that zoom on hover, greyed out when on rent or in maintenance.
* Search page: live text search, type chips, price slider, branch filter, "only bookable now", sort. Cards animate in.
* Vehicle detail dialog: the vehicle "drives in", the price recalculates as you slide the number of days.
* Add page: choose a type card and only that type's fields appear (hidden fields are disabled so they are not sent);
  a live preview card redraws the vehicle in the chosen colour.
* List page: change status straight from the table (PATCH), stat counters, animated row delete.

## Likely viva questions

1. **Why is `calculateRentalCost` abstract in `Vehicle`?** Each type prices differently; the parent has no correct
   general formula.
2. **Where is overloading?** `calculateRentalCost(int)` and `calculateRentalCost(int, double)`.
3. **How do you rebuild the right object from the file?** `fromFileString()` reads the first field (`CAR`, `VAN`,
   `MOTORCYCLE`), calls `createEmpty()` for the right child, fills common fields, then the child reads its own
   two extra fields with `readExtraFields()` (another overridden method).
4. **Why use an enum for status?** Fixed set of allowed values, compile-time checking, can hold a label.
5. **What stops deleting a rented vehicle?** `VehicleService.delete()` checks `status == RENTED` and throws
   `ValidationException`.
6. **What is `applyTypeDetails()`?** On update, each child reads its own special fields (seats, cargo, engine)
   from the form, so the service doesn't need `if (v instanceof Car)` checks.
7. **How are photos stored?** Only the path is stored, as the last field in `vehicles.txt`. The image files live in
   `static/images/vehicles/` and Spring Boot serves them. Storing paths keeps the text file small and readable.
8. **What if a vehicle has no photo?** `imageUrl` is empty, `isHasPhoto()` is false, and the page draws the vehicle in SVG
   in its colour. If an image file fails to load, the page also falls back to the drawing.
