# How to run the website in IntelliJ IDEA

Works with IntelliJ IDEA **Community or Ultimate**, on Windows, macOS or Linux.
The first run needs an internet connection (Maven downloads Spring Boot, about 30 MB, once).

## 1. Check your JDK (17 to 26)

The project uses **Spring Boot 4.1.1**, which supports **Java 17 up to and including Java 26**.
JDK 17, 21, 25 and **26** all work. Java 8 or 11 will not work.

* In IntelliJ: **File > Project Structure > Project > SDK**.
  * If it shows 17, 21, 25 or 26, you are fine.
  * If it is empty or shows 1.8 / 11: open the SDK list > **Download JDK...** > Version **17** (or 21),
    vendor **Eclipse Temurin** > Download. Then select it.

## 2. Open the project the right way

1. Unzip `vehicle-rental-platform.zip` (or clone the GitHub repository).
2. In IntelliJ: **File > Open** and select the folder that **directly contains `pom.xml`**.
   * Correct: `...\vehicle-rental-platform\` (inside you see `pom.xml`, `src`, `data`).
   * Wrong: the folder *above* it. IntelliJ then does not see a Maven project and everything stays red.
3. If IntelliJ asks *"Trust project?"* click **Trust Project**. If it asks *"Maven build scripts found / Load"* click **Load**.
4. Wait until the progress bar at the bottom finishes (Maven downloads the libraries). Red underlines disappear.

## 3. Run it

* Top right, choose **Run Vehicle Rental website** and press the green **Run** button.
  (This run configuration is included in the project, in the `.run` folder.)
* Or open `src/main/java/com/vehiclerental/VehicleRentalApplication.java` and click the green arrow next to `main`.

When it is ready, the Run window shows:

```
==============================================================
  Vehicle Rental is running.  Open:  http://localhost:8080
  Staff sign in:  http://localhost:8080/admin/login.html  (admin / admin123)
  Data folder:    C:\...\vehicle-rental-platform\data
==============================================================
```

Open **http://localhost:8080** in Chrome / Edge / Firefox.

> Do **not** open the `.html` files directly (double-click, or the little browser icons IntelliJ shows on an
> HTML file). Those open `localhost:63342` or `file://` and the pages cannot load any data. The pages now show
> a "Start the server first" message if this happens.

## 4. If something goes wrong

| What you see | Why | Fix |
|---|---|---|
| Everything is red: `Cannot resolve symbol 'springframework'` | The project was not loaded as Maven | Right-click `pom.xml` > **Add as Maven Project** (or **Maven** tool window > **Reload All Maven Projects**). Make sure you opened the folder that contains `pom.xml`. |
| `release version 17 not supported` / `invalid target release: 17` / `class file has wrong version 61.0` | IntelliJ or Maven is using Java 8 or 11 | Set the project SDK to 17+ (step 1). Also **Settings > Build, Execution, Deployment > Build Tools > Maven > Runner > JRE** = *Use Project JDK*. |
| `Could not transfer artifact` / `Unknown host repo.maven.apache.org` | No internet, or Maven is in offline mode | Connect to the internet. In the **Maven** tool window turn off **Toggle Offline Mode**, then **Reload**. On a university network, try a phone hotspot for the first download. |
| `Web server failed to start. Port 8080 was already in use.` | Another program (Oracle, Tomcat, another project) uses port 8080 | Stop the other program, or open `src/main/resources/application.properties` and change `server.port=8080` to `server.port=8081`, then open http://localhost:8081 |
| The Run button is grey / `No run configuration` | IntelliJ has not indexed the project yet | Wait for indexing to finish, then open `VehicleRentalApplication.java` and use the green arrow beside `main`. |
| `Error: Could not find or load main class com.vehiclerental.VehicleRentalApplication` | Not built yet | **Build > Rebuild Project**, then run again. |
| The site opens but there are no vehicles | Data files missing | Nothing to do: missing files are recreated from the demo data automatically (`src/main/resources/seed-data/`). The Run window shows which data folder is used. |
| Pages look unstyled and show "Start the server first" | The HTML file was opened directly | Run the application and use **http://localhost:8080** |

## 5. Reset the demo data

Stop the application, delete the `data` folder, and run again. All seven files are recreated from
`src/main/resources/seed-data/`.

## Command line (optional)

If Maven is installed: `mvn spring-boot:run` in the folder that contains `pom.xml`.
