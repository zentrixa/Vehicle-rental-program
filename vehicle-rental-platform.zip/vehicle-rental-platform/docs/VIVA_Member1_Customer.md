# Viva Guide - Member 1: User (Customer) Management

## What I built

| Layer | Files |
|---|---|
| Model | `customer/Customer.java` (abstract), `RegularCustomer.java`, `PremiumCustomer.java` |
| Service | `customer/CustomerService.java` |
| Controller | `customer/CustomerController.java` |
| Pages | `customers/register.html`, `login.html`, `profile.html`, `list.html` (admin) |
| Front end | `css/customer.css`, `js/customer.js` |
| Data | `data/customers.txt` |

## CRUD map

| Operation | Page | HTTP | Java method |
|---|---|---|---|
| **Create** - register | `register.html` | `POST /api/customers` | `CustomerService.register()` |
| **Read** - sign in | `login.html` | `POST /api/customers/login` | `CustomerService.login()` |
| **Read** - search | `list.html` | `GET /api/customers?q=&tier=` | `CustomerService.search()` |
| **Read** - one | `profile.html` | `GET /api/customers/{id}` | `CustomerService.findById()` |
| **Update** - profile, password, tier | `profile.html`, `list.html` | `PUT /api/customers/{id}` | `CustomerService.update()` |
| **Delete** | `profile.html`, `list.html` | `DELETE /api/customers/{id}` | `CustomerService.delete()` |

## Class diagram

```
             <<abstract>> User  (shared)
             - id, username, fullName, email, phone, passwordHash, joinedDate
             + authenticate(id, pw) : boolean
             + getRole() : String {abstract}
                      ^
                      |
             <<abstract>> Customer
             - licenceNo : String
             - loyaltyPoints : int
             - objectsCreated : int {static}
             + getDiscountRate() : double     {abstract}
             + getMaxActiveBookings() : int   {abstract}
             + getMembershipTier() : String   {abstract}
             + getPerks() : List<String>      {abstract}
             + fromFileString(line) : Customer {static}
                ^                        ^
                |                        |
        RegularCustomer            PremiumCustomer
        discount 0%                discount 10%
        max 2 bookings             max 5 bookings
        sign in: username          sign in: username OR email
```

## OOP concepts - what to point at

**Encapsulation.** Every field is `private`. `setLicenceNo()` only accepts 1 letter + 7 digits (`LICENCE_PATTERN`),
`setEmail()` and `setPhone()` (in `User`) check formats. The password is never stored in plain text: `setPassword()`
hashes it, and `getPasswordHash()` has `@JsonIgnore` so the browser never receives it.

**Inheritance.** `Customer extends User` reuses username, email, phone and password logic from the shared class.
`RegularCustomer` and `PremiumCustomer` extend `Customer`. The constructors chain with `super(...)`.

**Abstraction.** `Customer` is abstract: you cannot write `new Customer()`. Its abstract methods
(`getDiscountRate`, `getMaxActiveBookings`, `getMembershipTier`, `getPerks`) force each tier to give its own answer.

**Polymorphism (runtime / overriding).** "Different authentication mechanisms for customer types":
```java
// PremiumCustomer
@Override
public boolean authenticate(String identifier, String rawPassword) {
    boolean emailMatches = identifier.trim().equalsIgnoreCase(getEmail());
    return super.authenticate(identifier, rawPassword) || (emailMatches && checkPassword(rawPassword));
}
```
In `CustomerService.login()` the loop calls `c.authenticate(...)` on a `Customer` variable. Java decides at run
time which version runs. **Demo:** sign in as `nimal.perera@gmail.com` (works, Premium) and as
`kasuni.f@gmail.com` (refused, Regular).

**Constructors.** Default constructor (used when loading from the file) and an overloaded constructor (used when
registering). The default constructor of `User` sets the joined date. The overloaded one calls `this()` first.

**static.** `objectsCreated` is shared by all customers and counts objects. `fromFileString()` is a static factory
method that reads the first field (`REGULAR` / `PREMIUM`) and creates the right child object.

**Changing tier.** An object cannot change its class. So `changeTier()` creates a new `PremiumCustomer`,
`copyTo()` copies the data across, and `customers.set(index, replacement)` swaps it in the `ArrayList`.

**ArrayList + generics.** `ArrayList<Customer> customers` holds both child types together.

**Exceptions.** Duplicate username/email/licence and wrong passwords throw `ValidationException` (HTTP 400).
A missing id throws `ResourceNotFoundException` (404).

## How other modules use my work

* Booking (M3) calls `getDiscountRate()` and `getMaxActiveBookings()`, so a Premium customer pays 10% less and can
  hold 5 bookings, without Booking knowing which class it has.
* Booking calls `addLoyaltyPoints()` when a vehicle is returned (10 points per day).
* Review (M6) uses my customers to name the reviewer.

## Front-end features to show

* The member card on the register page updates **live** as you type, and turns gold for Premium.
* Password strength meter. The sign-in form shakes on a wrong password.
* Profile: animated loyalty points, perks from the server (`getPerks()`), upgrade/downgrade with confirmation.
* Admin list: live search (debounced), tier filter chips, edit in a dialog, animated row removal.

## Likely viva questions

1. **Why is `Customer` abstract?** A customer is always Regular or Premium; a plain customer would have no
   discount or booking limit, so those methods have no meaningful body in the parent.
2. **Where is polymorphism?** `authenticate()`, `getDiscountRate()`, `getMaxActiveBookings()`, `getPerks()` -
   called through the `Customer` type, the child's version runs.
3. **Overloading vs overriding?** Overloading = same name, different parameters, chosen at compile time (the two
   constructors). Overriding = same signature in a child class, chosen at run time (`authenticate`).
4. **How is the password protected?** Private field, stored as a SHA-256 hash, no JSON output (`@JsonIgnore`),
   checked with `checkPassword()`.
5. **What happens when I register?** `register.html` > `customer.js` sends `POST /api/customers` >
   `CustomerController.register()` > `CustomerService.register()` checks unique username/email/licence > creates
   `RegularCustomer` or `PremiumCustomer` > adds to the ArrayList > `FileHandler.writeAll("customers.txt", ...)`.
6. **What does `super` do in `PremiumCustomer.authenticate()`?** Calls the parent (`User`) version to reuse the
   username check, then adds the email check.
7. **What is `protected`?** Visible to subclasses (and the same package). `setId()` and `setPasswordHash()` in
   `User` are protected so only child classes can call them while loading from the file.
