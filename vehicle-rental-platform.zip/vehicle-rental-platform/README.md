# Vehicle Rental - Drive Your Freedom

Vehicle Rental Service Platform.

SE1020 Object Oriented Programming group project (6 members).
A Spring Boot web application where customers rent cars, vans and motorcycles, and staff manage
the fleet, bookings, branches, reviews and staff accounts. All data is stored in plain `.txt` files.

## Run it in IntelliJ IDEA

**Step-by-step guide with fixes for common errors: [`docs/HOW_TO_RUN_IN_INTELLIJ.md`](docs/HOW_TO_RUN_IN_INTELLIJ.md)**

1. Use **any JDK from 17 to 26** (File > Project Structure > SDK). The project uses **Spring Boot 4.1.1**, which
   officially supports Java 17 up to and including **Java 26**. Java 8 / 11 will not work.
2. **File > Open** the folder that **directly contains `pom.xml`** (not the folder above it). Trust and load the Maven project.
3. Wait for Maven to finish downloading (first time only, needs internet).
4. Choose the run configuration **Run Vehicle Rental website** (top right) and press Run,
   or run `src/main/java/com/vehiclerental/VehicleRentalApplication.java`.
5. Open **<http://localhost:8080>**. Do not open the `.html` files directly.

**Pages:** Home, Cars, Vans, Motorcycles, Branches, Reviews, Contact, plus the customer area (register, sign in,
profile, book, my bookings, write a review) and the staff area (`/admin/login.html`).

Command line instead: `mvn spring-boot:run`

> Data is kept in `./data/*.txt`. If a file is missing it is recreated from the demo copy in
> `src/main/resources/seed-data/`, so a fresh clone always starts with demo data.

## Demo accounts

| Who | Username | Password | Notes |
|---|---|---|---|
| Premium customer | `nimal` | `nimal123` | Can also sign in with `nimal.perera@gmail.com` |
| Regular customer | `kasuni` | `kasuni123` | Username only. Has an overdue booking |
| Super admin | `admin` | `admin123` | Staff sign in: `/admin/login.html` |
| Branch manager | `dilini` | `dilini123` | Cannot manage staff |
| Counter staff | `kasun` | `kasun123` | Bookings, returns, reviews only |

## Project structure

```
pom.xml
.run/                                   <- ready-made IntelliJ run configuration
data/                                   <- the .txt "database" (one file per module)
src/main/java/com/vehiclerental/
    VehicleRentalApplication.java       <- starts the server (shared)
    common/                             <- shared kickoff code (User, FileHandler, exceptions ...)
    customer/                           <- Member 1
    vehicle/                            <- Member 2
    booking/                            <- Member 3
    admin/                              <- Member 4
    branch/                             <- Member 5
    review/                             <- Member 6
src/main/resources/
    application.properties
    seed-data/                          <- demo copies of the data files (restored automatically)
    static/                             <- HTML, CSS, JS served by Spring Boot
        index.html  contact.html  css/style.css  js/app.js   (shared)
        images/backgrounds/   page background photos (shared)
        images/vehicles/      30 vehicle photos + manifest.json (Member 2)
        customers/  vehicles/  bookings/  admin/  branches/  reviews/
docs/                                   <- work distribution + viva guide for every member
```

Every module follows the same layers:

```
HTML page  ->  module .js (fetch)  ->  Controller (REST)  ->  Service (rules + ArrayList)  ->  Model classes  ->  FileHandler  ->  data/*.txt
```

## Who owns what

| Member | Component | Java package | Pages | Data file |
|---|---|---|---|---|
| 1 | Customer Management | `customer` | `customers/register, login, profile, list` | `customers.txt` |
| 2 | Vehicle Management | `vehicle` | `vehicles/cars, vans, motorcycles, search, add, edit, list` | `vehicles.txt` |
| 3 | Booking & Return Management | `booking` | `bookings/book, return, list` | `bookings.txt` |
| 4 | Admin & Staff Management | `admin` | `admin/login, dashboard, register, staff` | `admins.txt`, `admin_logs.txt` |
| 5 | Branch Management | `branch` | `branches/register, list, edit` | `branches.txt` |
| 6 | Feedback & Review Management | `review` | `reviews/submit, view, moderate` | `reviews.txt` |

Full details: [`docs/WORK_DISTRIBUTION.md`](docs/WORK_DISTRIBUTION.md).
Viva preparation: `docs/VIVA_*.md`.

## Uploading to GitHub (order matters)

Each member's zip contains only that member's files, laid out with the same folders as the repository.
Unzip it **into the repository root** so the files land in the right place.

1. **Kickoff (one person, together with the team):** push `00-shared-core` first.
2. Then each member, in this order: Member 1, 2, 3, 4, 5, 6. Booking uses Customer and Vehicle, and Reviews use
   Booking and Admin, so the project compiles fully once all six are in.

```bash
git clone https://github.com/<your-team>/<repo>.git
cd <repo>
git checkout -b member2-vehicle          # your own branch
# unzip your member zip here (into the repo root)
git add .
git commit -m "Member 2: Vehicle management (CRUD, pages, vehicles.txt)"
git push -u origin member2-vehicle       # then open a Pull Request into main
```
