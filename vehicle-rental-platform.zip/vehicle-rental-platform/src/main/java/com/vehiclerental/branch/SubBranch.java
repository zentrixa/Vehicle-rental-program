package com.vehiclerental.branch;

import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

import com.vehiclerental.common.ValidationException;

/**
 * MEMBER 5 - A small pick-up point that belongs to a main branch.
 *
 * Association: a SubBranch knows the id of its parent MainBranch (one-way association -
 * the sub branch knows its parent, the parent does not store its children).
 */
public class SubBranch extends Branch {

    public static final String TYPE = "SUB";
    private static final int MAX_CAPACITY = 25;

    private String parentBranchId;
    private int vehicleCapacity;

    public SubBranch() {
        super();
        this.vehicleCapacity = 15;
        this.parentBranchId = "";
    }

    public SubBranch(String id, String name, String city, String address, String phone, String email,
                     LocalTime opening, LocalTime closing, String managerName,
                     String parentBranchId, int vehicleCapacity) {
        super(id, name, city, address, phone, email, opening, closing, managerName);
        this.parentBranchId = parentBranchId;
        setVehicleCapacity(vehicleCapacity);
    }

    @Override
    public String getType() {
        return TYPE;
    }

    @Override
    public List<String> getServices() {
        List<String> list = new ArrayList<>();
        list.add("Pick-up & drop-off");
        list.add("Short-term rentals");
        return list;
    }

    @Override
    public int getVehicleCapacity() {
        return vehicleCapacity;
    }

    @Override
    public String getDisplayInfo() {
        return "Pick-up point in " + getCity() + " for up to " + vehicleCapacity
                + " vehicles, supported by main branch " + parentBranchId + ".";
    }

    @Override
    protected String[] extraFileFields() {
        return new String[] { parentBranchId, String.valueOf(vehicleCapacity) };
    }

    @Override
    protected void readExtraFields(String extra1, String extra2) {
        this.parentBranchId = extra1;
        this.vehicleCapacity = Integer.parseInt(extra2);
    }

    public String getParentBranchId() {
        return parentBranchId;
    }

    void setParentBranchId(String parentBranchId) {
        this.parentBranchId = parentBranchId;
    }

    public void setVehicleCapacity(int vehicleCapacity) {
        if (vehicleCapacity < 1 || vehicleCapacity > MAX_CAPACITY) {
            throw new ValidationException("A sub branch can hold between 1 and " + MAX_CAPACITY + " vehicles");
        }
        this.vehicleCapacity = vehicleCapacity;
    }
}
