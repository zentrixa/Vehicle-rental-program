package com.vehiclerental.branch;

import java.time.LocalTime;
import java.util.List;

import com.vehiclerental.common.FileHandler;
import com.vehiclerental.common.FileStorable;
import com.vehiclerental.common.ValidationException;

/**
 * MEMBER 5 - Component 05: Branch Management
 *
 *            Branch (abstract)
 *            /             \
 *      MainBranch        SubBranch
 *
 * Lecture concepts:
 *  - Encapsulation: private fields; setters validate phone, email and opening hours.
 *  - Abstraction: getType(), getServices(), getVehicleCapacity() and getDisplayInfo() are abstract.
 *  - Inheritance: MainBranch and SubBranch reuse everything here.
 *  - Polymorphism: getDisplayInfo() / getServices() give different output for each branch type,
 *    isOpenAt(...) is overloaded.
 *
 * File format (branches.txt):
 * TYPE|id|name|city|address|phone|email|openingTime|closingTime|managerName|extra1|extra2
 */
public abstract class Branch implements FileStorable {

    private String id;
    private String name;
    private String city;
    private String address;
    private String phone;
    private String email;
    private LocalTime openingTime;
    private LocalTime closingTime;
    private String managerName;

    protected Branch() {
        this.openingTime = LocalTime.of(8, 0);
        this.closingTime = LocalTime.of(18, 0);
    }

    protected Branch(String id, String name, String city, String address, String phone, String email,
                     LocalTime openingTime, LocalTime closingTime, String managerName) {
        this();
        this.id = id;
        setName(name);
        setCity(city);
        setAddress(address);
        setPhone(phone);
        setEmail(email);
        setOperatingHours(openingTime, closingTime);
        setManagerName(managerName);
    }

    // ------------------------------------------------------------------ abstract methods

    /** MAIN or SUB. */
    public abstract String getType();

    /** Services offered at this branch - depends on the branch type. */
    public abstract List<String> getServices();

    /** Maximum number of vehicles that can be parked at the branch. */
    public abstract int getVehicleCapacity();

    /** A sentence describing the branch - each type formats it differently. */
    public abstract String getDisplayInfo();

    protected abstract String[] extraFileFields();

    protected abstract void readExtraFields(String extra1, String extra2);

    // ------------------------------------------------------------------ behaviour

    /** Is the branch open right now? (no parameters) */
    public boolean isOpenNow() {
        return isOpenAt(LocalTime.now());
    }

    /** Overloaded: is the branch open at a given time? */
    public boolean isOpenAt(LocalTime time) {
        if (openingTime.equals(closingTime)) {
            return true;                                   // 24 hours
        }
        return !time.isBefore(openingTime) && time.isBefore(closingTime);
    }

    /** Overloaded: is the branch open at a given hour and minute? */
    public boolean isOpenAt(int hour, int minute) {
        return isOpenAt(LocalTime.of(hour, minute));
    }

    public String getOperatingHours() {
        return openingTime.equals(closingTime) ? "Open 24 hours" : openingTime + " - " + closingTime;
    }

    @Override
    public String toFileString() {
        String[] extra = extraFileFields();
        return FileHandler.join(getType(), id, name, city, address, phone, email, openingTime, closingTime,
                managerName, extra[0], extra[1]);
    }

    public static Branch fromFileString(String line) {
        String[] p = FileHandler.split(line);
        Branch b = "MAIN".equals(p[0]) ? new MainBranch() : new SubBranch();
        b.id = p[1];
        b.name = p[2];
        b.city = p[3];
        b.address = p[4];
        b.phone = p[5];
        b.email = p[6];
        b.openingTime = LocalTime.parse(p[7]);
        b.closingTime = LocalTime.parse(p[8]);
        b.managerName = p[9];
        b.readExtraFields(p[10], p[11]);
        return b;
    }

    // ------------------------------------------------------------------ getters & setters

    @Override
    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        if (name == null || name.trim().length() < 3) {
            throw new ValidationException("Branch name must have at least 3 characters");
        }
        this.name = name.trim();
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        if (city == null || city.trim().isEmpty()) {
            throw new ValidationException("City is required");
        }
        String c = city.trim();
        this.city = Character.toUpperCase(c.charAt(0)) + c.substring(1);
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        if (address == null || address.trim().length() < 5) {
            throw new ValidationException("Enter the full street address");
        }
        this.address = address.trim();
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        String digits = phone == null ? "" : phone.replaceAll("[\\s-]", "");
        if (!digits.matches("0\\d{9}")) {
            throw new ValidationException("Phone number must have 10 digits and start with 0");
        }
        this.phone = digits;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        if (email == null || !email.trim().matches("^[\\w.+-]+@[\\w-]+(\\.[\\w-]+)+$")) {
            throw new ValidationException("Enter a valid branch email address");
        }
        this.email = email.trim().toLowerCase();
    }

    public LocalTime getOpeningTime() {
        return openingTime;
    }

    public LocalTime getClosingTime() {
        return closingTime;
    }

    /** Opening and closing times are always changed together so they stay consistent. */
    public void setOperatingHours(LocalTime opening, LocalTime closing) {
        if (opening == null || closing == null) {
            throw new ValidationException("Opening and closing times are required");
        }
        if (closing.isBefore(opening)) {
            throw new ValidationException("Closing time must be after opening time");
        }
        this.openingTime = opening;
        this.closingTime = closing;
    }

    public String getManagerName() {
        return managerName;
    }

    public void setManagerName(String managerName) {
        this.managerName = managerName == null ? "" : managerName.trim();
    }
}
