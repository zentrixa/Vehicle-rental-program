package com.vehiclerental.branch;

import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.TreeSet;

import org.springframework.stereotype.Service;

import com.vehiclerental.common.FileHandler;
import com.vehiclerental.common.IdGenerator;
import com.vehiclerental.common.RequestData;
import com.vehiclerental.common.ResourceNotFoundException;
import com.vehiclerental.common.ValidationException;

/**
 * MEMBER 5 - Business logic + file handling for branches (branches.txt).
 *
 * Rules:
 *  - A sub branch must point to an existing MAIN branch.
 *  - A main branch that still has sub branches cannot be deleted.
 *  - Branch names must be unique.
 */
@Service
public class BranchService {

    private static final String FILE = "branches.txt";
    private final ArrayList<Branch> branches = new ArrayList<>();

    public BranchService() {
        for (String line : FileHandler.readLines(FILE)) {
            try {
                branches.add(Branch.fromFileString(line));
            } catch (RuntimeException e) {
                System.err.println("Skipping bad branch line: " + line);
            }
        }
    }

    // ------------------------------------------------------------------ CREATE

    public synchronized Branch create(RequestData d) {
        String name = d.getString("name");
        ensureNameUnique(null, name);
        String id = IdGenerator.next("BR", branches);
        LocalTime opening = d.getTime("openingTime");
        LocalTime closing = d.getTime("closingTime");
        String type = d.getString("type", MainBranch.TYPE).toUpperCase();

        Branch branch;
        if (SubBranch.TYPE.equals(type)) {
            String parentId = d.getString("parentBranchId");
            requireMainBranch(parentId);
            branch = new SubBranch(id, name, d.getString("city"), d.getString("address"), d.getString("phone"),
                    d.getString("email"), opening, closing, d.getString("managerName", ""),
                    parentId, d.getInt("vehicleCapacity", 15));
        } else {
            branch = new MainBranch(id, name, d.getString("city"), d.getString("address"), d.getString("phone"),
                    d.getString("email"), opening, closing, d.getString("managerName", ""),
                    d.getInt("vehicleCapacity", 60), d.getBoolean("hasServiceCenter", true));
        }
        branches.add(branch);
        save();
        return branch;
    }

    // ------------------------------------------------------------------ READ

    public synchronized List<Branch> search(String q, String city, String type) {
        ArrayList<Branch> result = new ArrayList<>();
        String text = q == null ? "" : q.trim().toLowerCase();
        for (Branch b : branches) {
            boolean textMatch = text.isEmpty()
                    || (b.getName() + " " + b.getCity() + " " + b.getAddress()).toLowerCase().contains(text);
            boolean cityMatch = city == null || city.isEmpty() || b.getCity().equalsIgnoreCase(city);
            boolean typeMatch = type == null || type.isEmpty() || b.getType().equalsIgnoreCase(type);
            if (textMatch && cityMatch && typeMatch) {
                result.add(b);
            }
        }
        return result;
    }

    public synchronized Branch findById(String id) {
        for (Branch b : branches) {
            if (b.getId().equalsIgnoreCase(id)) {
                return b;
            }
        }
        throw new ResourceNotFoundException("Branch", id);
    }

    /** Sorted list of cities (TreeSet removes duplicates and sorts). */
    public synchronized List<String> getCities() {
        TreeSet<String> cities = new TreeSet<>();
        for (Branch b : branches) {
            cities.add(b.getCity());
        }
        return new ArrayList<>(cities);
    }

    // ------------------------------------------------------------------ UPDATE

    public synchronized Branch update(String id, RequestData d) {
        Branch b = findById(id);
        String name = d.getString("name", b.getName());
        ensureNameUnique(id, name);
        b.setName(name);
        b.setCity(d.getString("city", b.getCity()));
        b.setAddress(d.getString("address", b.getAddress()));
        b.setPhone(d.getString("phone", b.getPhone()));
        b.setEmail(d.getString("email", b.getEmail()));
        b.setManagerName(d.getString("managerName", b.getManagerName()));
        LocalTime opening = d.has("openingTime") ? d.getTime("openingTime") : b.getOpeningTime();
        LocalTime closing = d.has("closingTime") ? d.getTime("closingTime") : b.getClosingTime();
        b.setOperatingHours(opening, closing);

        if (b instanceof MainBranch) {                       // downcasting after an instanceof check
            MainBranch main = (MainBranch) b;
            main.setVehicleCapacity(d.getInt("vehicleCapacity", main.getVehicleCapacity()));
            main.setHasServiceCenter(d.getBoolean("hasServiceCenter", main.isHasServiceCenter()));
        } else if (b instanceof SubBranch) {
            SubBranch sub = (SubBranch) b;
            sub.setVehicleCapacity(d.getInt("vehicleCapacity", sub.getVehicleCapacity()));
            if (d.has("parentBranchId")) {
                requireMainBranch(d.getString("parentBranchId"));
                sub.setParentBranchId(d.getString("parentBranchId"));
            }
        }
        save();
        return b;
    }

    // ------------------------------------------------------------------ DELETE

    public synchronized void delete(String id) {
        Branch b = findById(id);
        for (Branch other : branches) {
            if (other instanceof SubBranch && ((SubBranch) other).getParentBranchId().equals(b.getId())) {
                throw new ValidationException(b.getName() + " still supports " + other.getName()
                        + ". Move or remove its sub branches first.");
            }
        }
        branches.remove(b);
        save();
    }

    // ------------------------------------------------------------------ helpers

    private void requireMainBranch(String parentId) {
        Branch parent = findById(parentId);
        if (!(parent instanceof MainBranch)) {
            throw new ValidationException("A sub branch must be linked to a MAIN branch");
        }
    }

    private void ensureNameUnique(String ignoreId, String name) {
        for (Branch b : branches) {
            if (!b.getId().equals(ignoreId) && b.getName().equalsIgnoreCase(name.trim())) {
                throw new ValidationException("A branch called '" + name + "' already exists");
            }
        }
    }

    private void save() {
        FileHandler.writeAll(FILE, branches);
    }
}
