package com.vehiclerental.branch;

import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

import com.vehiclerental.common.ValidationException;

/**
 * MEMBER 5 - A large regional branch with a service workshop.
 * Sub-branches report to a main branch.
 */
public class MainBranch extends Branch {

    public static final String TYPE = "MAIN";

    private int vehicleCapacity;
    private boolean hasServiceCenter;

    public MainBranch() {
        super();
        this.vehicleCapacity = 60;
        this.hasServiceCenter = true;
    }

    public MainBranch(String id, String name, String city, String address, String phone, String email,
                      LocalTime opening, LocalTime closing, String managerName,
                      int vehicleCapacity, boolean hasServiceCenter) {
        super(id, name, city, address, phone, email, opening, closing, managerName);
        setVehicleCapacity(vehicleCapacity);
        this.hasServiceCenter = hasServiceCenter;
    }

    @Override
    public String getType() {
        return TYPE;
    }

    @Override
    public List<String> getServices() {
        List<String> list = new ArrayList<>();
        list.add("Pick-up & drop-off");
        list.add("Long-term rentals");
        list.add("Airport delivery");
        if (hasServiceCenter) {
            list.add("Service & repair workshop");
        }
        return list;
    }

    @Override
    public int getVehicleCapacity() {
        return vehicleCapacity;
    }

    @Override
    public String getDisplayInfo() {
        return "Main branch in " + getCity() + " with space for " + vehicleCapacity + " vehicles"
                + (hasServiceCenter ? " and an on-site service workshop." : ".");
    }

    @Override
    protected String[] extraFileFields() {
        return new String[] { String.valueOf(vehicleCapacity), String.valueOf(hasServiceCenter) };
    }

    @Override
    protected void readExtraFields(String extra1, String extra2) {
        this.vehicleCapacity = Integer.parseInt(extra1);
        this.hasServiceCenter = Boolean.parseBoolean(extra2);
    }

    public void setVehicleCapacity(int vehicleCapacity) {
        if (vehicleCapacity < 10) {
            throw new ValidationException("A main branch must hold at least 10 vehicles");
        }
        this.vehicleCapacity = vehicleCapacity;
    }

    public boolean isHasServiceCenter() {
        return hasServiceCenter;
    }

    public void setHasServiceCenter(boolean hasServiceCenter) {
        this.hasServiceCenter = hasServiceCenter;
    }
}
