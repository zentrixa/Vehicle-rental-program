package com.vehiclerental.branch;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.vehiclerental.common.RequestData;

/**
 * MEMBER 5 - REST endpoints used by the branch pages.
 *
 *  POST   /api/branches                    add branch        (Create)
 *  GET    /api/branches?q=&city=&type=     search / list     (Read)
 *  GET    /api/branches/cities             city filter list  (Read)
 *  GET    /api/branches/{id}               one branch        (Read)
 *  PUT    /api/branches/{id}               edit branch       (Update)
 *  DELETE /api/branches/{id}               remove branch     (Delete)
 */
@RestController
@RequestMapping("/api/branches")
public class BranchController {

    private final BranchService branchService;

    public BranchController(BranchService branchService) {
        this.branchService = branchService;
    }

    @PostMapping
    public ResponseEntity<Branch> create(@RequestBody Map<String, Object> body) {
        return ResponseEntity.status(HttpStatus.CREATED).body(branchService.create(new RequestData(body)));
    }

    @GetMapping
    public ResponseEntity<List<Branch>> search(@RequestParam(value = "q", required = false) String q,
                                               @RequestParam(value = "city", required = false) String city,
                                               @RequestParam(value = "type", required = false) String type) {
        return ResponseEntity.ok(branchService.search(q, city, type));
    }

    @GetMapping("/cities")
    public ResponseEntity<List<String>> cities() {
        return ResponseEntity.ok(branchService.getCities());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Branch> getOne(@PathVariable("id") String id) {
        return ResponseEntity.ok(branchService.findById(id));
    }

    @PutMapping("/{id}")
    public ResponseEntity<Branch> update(@PathVariable("id") String id, @RequestBody Map<String, Object> body) {
        return ResponseEntity.ok(branchService.update(id, new RequestData(body)));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Map<String, Object>> delete(@PathVariable("id") String id) {
        branchService.delete(id);
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("message", "Branch " + id + " removed");
        return ResponseEntity.ok(result);
    }
}
