package com.vehiclerental.admin;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * MEMBER 4 - The three staff levels and the permissions each one gets.
 *
 * An enum with a constructor and private fields (encapsulation) - each constant is an object
 * that carries its own label and permission list.
 */
public enum AdminRole {

    SUPER_ADMIN("Super admin", Arrays.asList(
            AdminRole.MANAGE_STAFF, AdminRole.MANAGE_FLEET, AdminRole.MANAGE_BOOKINGS,
            AdminRole.MANAGE_CUSTOMERS, AdminRole.MANAGE_BRANCHES, AdminRole.MODERATE_REVIEWS,
            AdminRole.DELETE_RECORDS)),

    MANAGER("Branch manager", Arrays.asList(
            AdminRole.MANAGE_FLEET, AdminRole.MANAGE_BOOKINGS, AdminRole.MANAGE_CUSTOMERS,
            AdminRole.MANAGE_BRANCHES, AdminRole.MODERATE_REVIEWS)),

    STAFF("Counter staff", Arrays.asList(
            AdminRole.MANAGE_BOOKINGS, AdminRole.MODERATE_REVIEWS));

    // permission names (static constants)
    public static final String MANAGE_STAFF = "Manage staff";
    public static final String MANAGE_FLEET = "Manage fleet";
    public static final String MANAGE_BOOKINGS = "Manage bookings";
    public static final String MANAGE_CUSTOMERS = "Manage customers";
    public static final String MANAGE_BRANCHES = "Manage branches";
    public static final String MODERATE_REVIEWS = "Moderate reviews";
    public static final String DELETE_RECORDS = "Delete records";

    private final String label;
    private final List<String> permissions;

    AdminRole(String label, List<String> permissions) {
        this.label = label;
        this.permissions = permissions;
    }

    public String getLabel() {
        return label;
    }

    public List<String> getPermissions() {
        return Collections.unmodifiableList(permissions);
    }

    public static AdminRole fromText(String text) {
        for (AdminRole r : values()) {
            if (r.name().equalsIgnoreCase(text)) {
                return r;
            }
        }
        throw new com.vehiclerental.common.ValidationException("Role must be SUPER_ADMIN, MANAGER or STAFF");
    }
}
