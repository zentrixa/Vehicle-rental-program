package com.vehiclerental.admin;

import java.util.List;

/**
 * MEMBER 4 - Admin-only abilities (abstraction).
 *
 * Only Admin implements this interface; Customer does not. So code that receives an
 * AdminPrivileges object can ask "can you manage staff?" and a customer object can never be
 * passed in by mistake. This also follows the Interface Segregation principle (SOLID):
 * customers are not forced to have admin methods they do not use.
 */
public interface AdminPrivileges {

    boolean canManageStaff();

    boolean canDeleteRecords();

    boolean canModerateReviews();

    boolean hasPermission(String permission);

    List<String> getPermissions();
}
