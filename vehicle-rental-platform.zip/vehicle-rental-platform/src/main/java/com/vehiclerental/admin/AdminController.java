package com.vehiclerental.admin;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.vehiclerental.common.RequestData;

/**
 * MEMBER 4 - REST endpoints used by the admin pages.
 *
 *  POST   /api/admins/login                 staff sign in
 *  POST   /api/admins                       register staff          (Create)
 *  GET    /api/admins?q=&role=              list staff              (Read)
 *  GET    /api/admins/{id}                  one staff member        (Read)
 *  GET    /api/admins/{id}/logs             activity of one admin   (Read)
 *  GET    /api/admins/logs/recent?limit=    live activity feed      (Read)
 *  POST   /api/admins/{id}/logs             record an action
 *  PUT    /api/admins/{id}                  edit profile / role     (Update)
 *  PATCH  /api/admins/{id}/active           activate / deactivate   (Update)
 *  DELETE /api/admins/{id}?actingAdminId=   remove staff            (Delete)
 */
@RestController
@RequestMapping("/api/admins")
public class AdminController {

    private final AdminService adminService;

    public AdminController(AdminService adminService) {
        this.adminService = adminService;
    }

    @PostMapping("/login")
    public ResponseEntity<Admin> login(@RequestBody Map<String, Object> body) {
        RequestData data = new RequestData(body);
        return ResponseEntity.ok(adminService.login(data.getString("identifier"), data.getString("password")));
    }

    @PostMapping
    public ResponseEntity<Admin> create(@RequestBody Map<String, Object> body) {
        return ResponseEntity.status(HttpStatus.CREATED).body(adminService.create(new RequestData(body)));
    }

    @GetMapping
    public ResponseEntity<List<Admin>> search(@RequestParam(value = "q", required = false) String q,
                                              @RequestParam(value = "role", required = false) String role) {
        return ResponseEntity.ok(adminService.search(q, role));
    }

    /** The roles and their permissions (read from the AdminRole enum, so the page never goes out of date). */
    @GetMapping("/roles")
    public ResponseEntity<List<Map<String, Object>>> roles() {
        List<Map<String, Object>> list = new java.util.ArrayList<>();
        for (AdminRole role : AdminRole.values()) {
            Map<String, Object> map = new LinkedHashMap<>();
            map.put("role", role.name());
            map.put("label", role.getLabel());
            map.put("permissions", role.getPermissions());
            list.add(map);
        }
        return ResponseEntity.ok(list);
    }

    @GetMapping("/logs/recent")
    public ResponseEntity<List<ActivityLog>> recentLogs(@RequestParam(value = "limit", defaultValue = "15") int limit) {
        return ResponseEntity.ok(adminService.getRecentLogs(limit));
    }

    @GetMapping("/{id}")
    public ResponseEntity<Admin> getOne(@PathVariable("id") String id) {
        return ResponseEntity.ok(adminService.findById(id));
    }

    @GetMapping("/{id}/logs")
    public ResponseEntity<List<ActivityLog>> logs(@PathVariable("id") String id) {
        return ResponseEntity.ok(adminService.getLogs(id));
    }

    @PostMapping("/{id}/logs")
    public ResponseEntity<ActivityLog> record(@PathVariable("id") String id, @RequestBody Map<String, Object> body) {
        return ResponseEntity.ok(adminService.recordActivity(id, new RequestData(body).getString("action")));
    }

    @PutMapping("/{id}")
    public ResponseEntity<Admin> update(@PathVariable("id") String id, @RequestBody Map<String, Object> body) {
        return ResponseEntity.ok(adminService.update(id, new RequestData(body)));
    }

    @PatchMapping("/{id}/active")
    public ResponseEntity<Admin> setActive(@PathVariable("id") String id, @RequestBody Map<String, Object> body) {
        RequestData data = new RequestData(body);
        return ResponseEntity.ok(adminService.setActive(id, data.getBoolean("active", true), data.getString("actingAdminId", null)));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Map<String, Object>> delete(@PathVariable("id") String id,
                                                      @RequestParam(value = "actingAdminId", required = false) String actingAdminId) {
        adminService.delete(id, actingAdminId);
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("message", "Staff account " + id + " deleted");
        return ResponseEntity.ok(result);
    }
}
