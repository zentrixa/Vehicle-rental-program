package com.vehiclerental.admin;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import org.springframework.stereotype.Service;

import com.vehiclerental.common.FileHandler;
import com.vehiclerental.common.IdGenerator;
import com.vehiclerental.common.RequestData;
import com.vehiclerental.common.ResourceNotFoundException;
import com.vehiclerental.common.ValidationException;

/**
 * MEMBER 4 - Business logic + file handling for staff accounts (admins.txt) and their
 * activity logs (admin_logs.txt).
 *
 * Rules enforced here:
 *  - Only an admin with the "Manage staff" permission can create, edit roles or delete staff.
 *  - Nobody can delete or deactivate their own account.
 *  - The last active Super admin can never be removed (the system would be locked out).
 *  - Deleting an admin also deletes its activity logs (composition).
 */
@Service
public class AdminService {

    private static final String FILE = "admins.txt";
    private static final String LOG_FILE = "admin_logs.txt";

    private final ArrayList<Admin> admins = new ArrayList<>();

    public AdminService() {
        for (String line : FileHandler.readLines(FILE)) {
            try {
                admins.add(Admin.fromFileString(line));
            } catch (RuntimeException e) {
                System.err.println("Skipping bad admin line: " + line);
            }
        }
        for (String line : FileHandler.readLines(LOG_FILE)) {
            try {
                ActivityLog log = ActivityLog.fromFileString(line);
                for (Admin a : admins) {
                    if (a.getId().equals(log.getAdminId())) {
                        a.attachLog(log);
                    }
                }
            } catch (RuntimeException e) {
                System.err.println("Skipping bad log line: " + line);
            }
        }
        if (admins.isEmpty()) {
            // first run - create a default super admin so someone can sign in
            Admin root = new Admin("ADM-001", "admin", "System Administrator", "admin@vehiclerental.lk",
                    "0112345678", "admin123", AdminRole.SUPER_ADMIN);
            root.logActivity("Account created automatically on first start");
            admins.add(root);
            save();
        }
    }

    // ------------------------------------------------------------------ login

    public synchronized Admin login(String identifier, String password) {
        for (Admin a : admins) {
            if (a.authenticate(identifier, password)) {         // overridden authenticate()
                a.logActivity("Signed in to the dashboard");
                save();
                return a;
            }
        }
        throw new ValidationException("Incorrect username or password, or the account is deactivated");
    }

    // ------------------------------------------------------------------ CREATE

    public synchronized Admin create(RequestData data) {
        Admin acting = requireStaffManager(data.getString("actingAdminId", null));
        String username = data.getString("username");
        String email = data.getString("email");
        ensureUnique(null, username, email);

        Admin admin = new Admin(IdGenerator.next("ADM", admins), username, data.getString("fullName"), email,
                data.getString("phone"), data.getString("password"), AdminRole.fromText(data.getString("role", "STAFF")));
        admin.logActivity("Account created by " + (acting == null ? "system" : acting.getUsername()));
        admins.add(admin);
        if (acting != null) {
            acting.logActivity("Created staff account " + admin.getUsername() + " (" + admin.getRoleLabel() + ")");
        }
        save();
        return admin;
    }

    // ------------------------------------------------------------------ READ

    public synchronized List<Admin> search(String q, String role) {
        ArrayList<Admin> result = new ArrayList<>();
        String text = q == null ? "" : q.trim().toLowerCase();
        for (Admin a : admins) {
            boolean textMatch = text.isEmpty() || (a.getId() + " " + a.getUsername() + " " + a.getFullName() + " "
                    + a.getEmail()).toLowerCase().contains(text);
            boolean roleMatch = role == null || role.isEmpty() || a.getRole().equalsIgnoreCase(role);
            if (textMatch && roleMatch) {
                result.add(a);
            }
        }
        return result;
    }

    public synchronized Admin findById(String id) {
        for (Admin a : admins) {
            if (a.getId().equalsIgnoreCase(id)) {
                return a;
            }
        }
        throw new ResourceNotFoundException("Admin", id);
    }

    public synchronized List<ActivityLog> getLogs(String adminId) {
        ArrayList<ActivityLog> logs = new ArrayList<>(findById(adminId).getActivityLogs());
        logs.sort(Comparator.comparing(ActivityLog::timestampValue).reversed());
        return logs;
    }

    /** Most recent activity of all admins - for the live feed on the dashboard. */
    public synchronized List<ActivityLog> getRecentLogs(int limit) {
        ArrayList<ActivityLog> all = new ArrayList<>();
        for (Admin a : admins) {
            all.addAll(a.getActivityLogs());
        }
        all.sort(Comparator.comparing(ActivityLog::timestampValue).reversed());
        return all.size() > limit ? new ArrayList<>(all.subList(0, limit)) : all;
    }

    // ------------------------------------------------------------------ UPDATE

    public synchronized Admin update(String id, RequestData data) {
        Admin admin = findById(id);
        String actingId = data.getString("actingAdminId", id);
        Admin acting = findById(actingId);
        boolean editingSelf = actingId.equalsIgnoreCase(id);
        if (!editingSelf && !acting.canManageStaff()) {
            throw new ValidationException("Only a Super admin can edit other staff accounts");
        }

        String email = data.getString("email", admin.getEmail());
        ensureUnique(id, admin.getUsername(), email);
        admin.setFullName(data.getString("fullName", admin.getFullName()));
        admin.setEmail(email);
        admin.setPhone(data.getString("phone", admin.getPhone()));
        if (data.has("password")) {
            admin.setPassword(data.getString("password"));
        }
        if (data.has("role")) {
            AdminRole newRole = AdminRole.fromText(data.getString("role"));
            if (newRole != admin.getAdminRole()) {
                if (!acting.canManageStaff()) {
                    throw new ValidationException("You do not have permission to change roles");
                }
                if (admin.getAdminRole() == AdminRole.SUPER_ADMIN && countActiveSuperAdmins() <= 1) {
                    throw new ValidationException("At least one Super admin must remain");
                }
                admin.setAdminRole(newRole);
            }
        }
        acting.logActivity(editingSelf ? "Updated own profile" : "Updated staff account " + admin.getUsername());
        save();
        return admin;
    }

    public synchronized Admin setActive(String id, boolean active, String actingId) {
        Admin acting = requireStaffManager(actingId);
        Admin admin = findById(id);
        if (acting != null && acting.getId().equals(id)) {
            throw new ValidationException("You cannot deactivate your own account");
        }
        if (!active && admin.getAdminRole() == AdminRole.SUPER_ADMIN && countActiveSuperAdmins() <= 1) {
            throw new ValidationException("At least one active Super admin must remain");
        }
        admin.setActive(active);
        if (acting != null) {
            acting.logActivity((active ? "Activated " : "Deactivated ") + admin.getUsername());
        }
        save();
        return admin;
    }

    /** Any page in the admin area can record what the admin just did. */
    public synchronized ActivityLog recordActivity(String adminId, String action) {
        if (action == null || action.trim().isEmpty()) {
            throw new ValidationException("Action text is required");
        }
        ActivityLog log = findById(adminId).logActivity(action);
        save();
        return log;
    }

    // ------------------------------------------------------------------ DELETE

    public synchronized void delete(String id, String actingId) {
        Admin acting = requireStaffManager(actingId);
        Admin admin = findById(id);
        if (acting != null && acting.getId().equals(id)) {
            throw new ValidationException("You cannot delete your own account");
        }
        if (admin.getAdminRole() == AdminRole.SUPER_ADMIN && countActiveSuperAdmins() <= 1) {
            throw new ValidationException("The last Super admin cannot be deleted");
        }
        admins.remove(admin);          // its ActivityLog objects disappear with it (composition)
        if (acting != null) {
            acting.logActivity("Deleted staff account " + admin.getUsername());
        }
        save();
    }

    // ------------------------------------------------------------------ helpers

    private Admin requireStaffManager(String actingId) {
        if (actingId == null || actingId.isEmpty()) {
            throw new ValidationException("Sign in as an admin to manage staff accounts");
        }
        Admin acting = findById(actingId);
        if (!acting.canManageStaff()) {
            throw new ValidationException("Only a Super admin can manage staff accounts");
        }
        return acting;
    }

    private int countActiveSuperAdmins() {
        int count = 0;
        for (Admin a : admins) {
            if (a.getAdminRole() == AdminRole.SUPER_ADMIN && a.isActive()) {
                count++;
            }
        }
        return count;
    }

    private void ensureUnique(String ignoreId, String username, String email) {
        for (Admin a : admins) {
            if (a.getId().equals(ignoreId)) {
                continue;
            }
            if (a.getUsername().equalsIgnoreCase(username)) {
                throw new ValidationException("Username '" + username + "' is already taken");
            }
            if (a.getEmail().equalsIgnoreCase(email)) {
                throw new ValidationException("A staff account with this email already exists");
            }
        }
    }

    private void save() {
        FileHandler.writeAll(FILE, admins);
        ArrayList<String> logLines = new ArrayList<>();
        for (Admin a : admins) {
            for (ActivityLog log : a.getActivityLogs()) {
                logLines.add(log.toFileString());
            }
        }
        FileHandler.writeLines(LOG_FILE, logLines);
    }
}
