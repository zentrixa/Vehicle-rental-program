package com.vehiclerental.admin;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.vehiclerental.common.FileHandler;
import com.vehiclerental.common.User;

/**
 * MEMBER 4 - Component 04: Admin &amp; Staff Management
 *
 * A staff account that can sign in to the admin dashboard.
 *
 * Lecture concepts:
 *  - Inheritance: Admin extends the shared User base class (same as Customer) - it reuses
 *    username, email, password hashing and validation.
 *  - Interface + abstraction: implements AdminPrivileges, the admin-only methods.
 *  - Polymorphism (overriding): getRole() returns the staff role; authenticate() also
 *    refuses a deactivated account.
 *  - Composition: owns an ArrayList of ActivityLog objects that it creates itself.
 *  - Encapsulation: the log list is private; outside code gets a read-only copy.
 *
 * File format (admins.txt):
 * id|username|fullName|email|phone|passwordHash|role|active|joinedDate
 */
public class Admin extends User implements AdminPrivileges {

    private AdminRole adminRole;
    private boolean active;
    private final ArrayList<ActivityLog> activityLogs = new ArrayList<>();   // composition

    public Admin() {
        super();
        this.adminRole = AdminRole.STAFF;
        this.active = true;
    }

    public Admin(String id, String username, String fullName, String email, String phone,
                 String rawPassword, AdminRole role) {
        super(id, username, fullName, email, phone, rawPassword);
        this.adminRole = role;
        this.active = true;
    }

    // ------------------------------------------------------------------ User (overridden)

    @Override
    public String getRole() {
        return adminRole.name();
    }

    /** Admins must also be active to sign in. Both username and email are accepted. */
    @Override
    public boolean authenticate(String identifier, String rawPassword) {
        if (!active || identifier == null) {
            return false;
        }
        boolean idMatches = identifier.trim().equalsIgnoreCase(getUsername())
                || identifier.trim().equalsIgnoreCase(getEmail());
        return idMatches && checkPassword(rawPassword);
    }

    @Override
    public String toFileString() {
        return FileHandler.join(getId(), getUsername(), getFullName(), getEmail(), getPhone(),
                getPasswordHash(), adminRole.name(), active, getJoinedDate());
    }

    public static Admin fromFileString(String line) {
        String[] p = FileHandler.split(line);
        Admin a = new Admin();
        a.setId(p[0]);
        a.setUsername(p[1]);
        a.setFullName(p[2]);
        a.setEmail(p[3]);
        a.setPhone(p[4]);
        a.setPasswordHash(p[5]);
        a.adminRole = AdminRole.valueOf(p[6]);
        a.active = Boolean.parseBoolean(p[7]);
        a.setJoinedDate(LocalDate.parse(p[8]));
        return a;
    }

    // ------------------------------------------------------------------ AdminPrivileges

    @Override
    public boolean canManageStaff() {
        return hasPermission(AdminRole.MANAGE_STAFF);
    }

    @Override
    public boolean canDeleteRecords() {
        return hasPermission(AdminRole.DELETE_RECORDS);
    }

    @Override
    public boolean canModerateReviews() {
        return hasPermission(AdminRole.MODERATE_REVIEWS);
    }

    @Override
    public boolean hasPermission(String permission) {
        return adminRole.getPermissions().contains(permission);
    }

    @Override
    public List<String> getPermissions() {
        return adminRole.getPermissions();
    }

    // ------------------------------------------------------------------ composition: activity logs

    /** Creates a new log entry that belongs to this admin. */
    public ActivityLog logActivity(String action) {
        ActivityLog log = new ActivityLog(getId(), action);
        activityLogs.add(log);
        return log;
    }

    /** Used only while loading admin_logs.txt. */
    void attachLog(ActivityLog log) {
        activityLogs.add(log);
    }

    /** Read-only list so nobody can delete logs from outside. Hidden from the normal JSON. */
    @JsonIgnore
    public List<ActivityLog> getActivityLogs() {
        return Collections.unmodifiableList(activityLogs);
    }

    public int getActivityCount() {
        return activityLogs.size();
    }

    public String getLastActive() {
        return activityLogs.isEmpty() ? null : activityLogs.get(activityLogs.size() - 1).getTimestamp();
    }

    // ------------------------------------------------------------------ getters & setters

    public AdminRole getAdminRole() {
        return adminRole;
    }

    public String getRoleLabel() {
        return adminRole.getLabel();
    }

    public void setAdminRole(AdminRole adminRole) {
        this.adminRole = adminRole;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }
}
