package com.vehiclerental.admin;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import com.vehiclerental.common.FileHandler;

/**
 * MEMBER 4 - One entry in an admin's activity history ("Logged in", "Removed vehicle VEH-004" ...).
 *
 * COMPOSITION (Lecture 04): an ActivityLog is created INSIDE an Admin (Admin.logActivity)
 * and belongs to exactly one admin. When the admin account is deleted, its logs are deleted too -
 * the part cannot live without the whole (filled diamond in UML).
 *
 * File format (admin_logs.txt): adminId|timestamp|action
 */
public class ActivityLog {

    private static final DateTimeFormatter FORMAT = DateTimeFormatter.ISO_LOCAL_DATE_TIME;

    private final String adminId;
    private final LocalDateTime timestamp;
    private final String action;

    /** Package-private: only classes in the admin package (Admin, AdminService) can create logs. */
    ActivityLog(String adminId, String action) {
        this(adminId, LocalDateTime.now().withNano(0), action);
    }

    ActivityLog(String adminId, LocalDateTime timestamp, String action) {
        this.adminId = adminId;
        this.timestamp = timestamp;
        this.action = FileHandler.clean(action);
    }

    public String getAdminId() {
        return adminId;
    }

    public String getTimestamp() {
        return timestamp.format(FORMAT);
    }

    public String getAction() {
        return action;
    }

    LocalDateTime timestampValue() {
        return timestamp;
    }

    String toFileString() {
        return FileHandler.join(adminId, timestamp.format(FORMAT), action);
    }

    static ActivityLog fromFileString(String line) {
        String[] p = FileHandler.split(line);
        return new ActivityLog(p[0], LocalDateTime.parse(p[1], FORMAT), p[2]);
    }
}
