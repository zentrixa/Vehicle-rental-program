package com.vehiclerental.customer;

import java.util.Arrays;
import java.util.List;

/**
 * MEMBER 1 - A paid / loyal member with extra benefits.
 *
 * Polymorphism (method overriding / runtime polymorphism):
 *  - getDiscountRate() returns 10 % instead of 0 %.
 *  - authenticate() accepts the username OR the email address, a different
 *    authentication mechanism from RegularCustomer.
 */
public class PremiumCustomer extends Customer {

    public static final String TIER = "PREMIUM";
    private static final double DISCOUNT = 0.10;

    public PremiumCustomer() {
        super();
    }

    public PremiumCustomer(String id, String username, String fullName, String email,
                           String phone, String rawPassword, String licenceNo) {
        super(id, username, fullName, email, phone, rawPassword, licenceNo);
    }

    @Override
    public double getDiscountRate() {
        return DISCOUNT;
    }

    @Override
    public int getMaxActiveBookings() {
        return 5;
    }

    @Override
    public String getMembershipTier() {
        return TIER;
    }

    @Override
    public List<String> getPerks() {
        return Arrays.asList(
                "10% off every booking",
                "Book up to 5 vehicles at a time",
                "Sign in with username or email",
                "One free grace day on late returns");
    }

    /** Premium customers may sign in with either the username or the email address. */
    @Override
    public boolean authenticate(String identifier, String rawPassword) {
        if (identifier == null) {
            return false;
        }
        boolean emailMatches = identifier.trim().equalsIgnoreCase(getEmail());
        return super.authenticate(identifier, rawPassword) || (emailMatches && checkPassword(rawPassword));
    }
}
