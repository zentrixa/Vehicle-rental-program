package com.vehiclerental.customer;

import java.time.LocalDate;
import java.util.List;

import com.vehiclerental.common.FileHandler;
import com.vehiclerental.common.User;
import com.vehiclerental.common.ValidationException;

/**
 * MEMBER 1 - Component 01: User (Customer) Management
 *
 * A customer of the rental platform. Abstract because every real customer is either a
 * RegularCustomer or a PremiumCustomer.
 *
 * Lecture concepts:
 *  - Inheritance: Customer extends the shared User class (gets username, email, password ...).
 *  - Encapsulation: licence number and loyalty points are private with validated setters.
 *  - Abstraction: getDiscountRate(), getMaxActiveBookings(), getMembershipTier() and getPerks()
 *    are abstract - each customer type must give its own answer.
 *  - static members: a static counter and a static factory method fromFileString().
 *
 * File format (customers.txt):
 * TIER|id|username|fullName|email|phone|passwordHash|licenceNo|joinedDate|loyaltyPoints
 */
public abstract class Customer extends User {

    /** Sri Lankan driving licence: one capital letter followed by 7 digits (e.g. B1234567). */
    public static final String LICENCE_PATTERN = "[A-Z]\\d{7}";

    /** static variable - shared by all Customer objects, counts objects created while the app runs. */
    private static int objectsCreated = 0;

    private String licenceNo;
    private int loyaltyPoints;

    /** Default constructor (used by fromFileString). */
    protected Customer() {
        super();
        objectsCreated++;
    }

    /** Overloaded constructor (used for a new registration). */
    protected Customer(String id, String username, String fullName, String email,
                       String phone, String rawPassword, String licenceNo) {
        super(id, username, fullName, email, phone, rawPassword);
        setLicenceNo(licenceNo);
        this.loyaltyPoints = 0;
        objectsCreated++;
    }

    // ------------------------------------------------------------------ abstract methods

    /** Discount given on every booking, e.g. 0.10 = 10 %. */
    public abstract double getDiscountRate();

    /** How many vehicles this customer may have booked at the same time. */
    public abstract int getMaxActiveBookings();

    /** REGULAR or PREMIUM. */
    public abstract String getMembershipTier();

    /** Benefits shown on the profile page. */
    public abstract List<String> getPerks();

    // ------------------------------------------------------------------ overridden methods

    @Override
    public String getRole() {
        return "CUSTOMER";
    }

    @Override
    public String toFileString() {
        return FileHandler.join(getMembershipTier(), getId(), getUsername(), getFullName(), getEmail(),
                getPhone(), getPasswordHash(), licenceNo, getJoinedDate(), loyaltyPoints);
    }

    // ------------------------------------------------------------------ behaviour

    /** Points earned after a completed rental (called by the booking module). */
    public void addLoyaltyPoints(int points) {
        if (points < 0) {
            throw new ValidationException("Points cannot be negative");
        }
        this.loyaltyPoints += points;
    }

    /**
     * Copies the shared data of this customer into another customer object.
     * Used when a customer is upgraded/downgraded (Regular <-> Premium).
     */
    protected void copyTo(Customer target) {
        target.setId(getId());
        target.setUsername(getUsername());
        target.setFullName(getFullName());
        target.setEmail(getEmail());
        target.setPhone(getPhone());
        target.setPasswordHash(getPasswordHash());
        target.setJoinedDate(getJoinedDate());
        target.licenceNo = this.licenceNo;
        target.loyaltyPoints = this.loyaltyPoints;
    }

    /**
     * static factory method: reads one line of customers.txt and creates the correct
     * child object (RegularCustomer or PremiumCustomer).
     */
    public static Customer fromFileString(String line) {
        String[] p = FileHandler.split(line);
        Customer c = "PREMIUM".equals(p[0]) ? new PremiumCustomer() : new RegularCustomer();
        c.setId(p[1]);
        c.setUsername(p[2]);
        c.setFullName(p[3]);
        c.setEmail(p[4]);
        c.setPhone(p[5]);
        c.setPasswordHash(p[6]);
        c.licenceNo = p[7];
        c.setJoinedDate(LocalDate.parse(p[8]));
        c.loyaltyPoints = Integer.parseInt(p[9]);
        return c;
    }

    // ------------------------------------------------------------------ getters & setters

    public String getLicenceNo() {
        return licenceNo;
    }

    public void setLicenceNo(String licenceNo) {
        String value = licenceNo == null ? "" : licenceNo.trim().toUpperCase();
        if (!value.matches(LICENCE_PATTERN)) {
            throw new ValidationException("Driving licence number must be 1 letter followed by 7 digits (e.g. B1234567)");
        }
        this.licenceNo = value;
    }

    public int getLoyaltyPoints() {
        return loyaltyPoints;
    }

    public static int getObjectsCreated() {
        return objectsCreated;
    }
}
