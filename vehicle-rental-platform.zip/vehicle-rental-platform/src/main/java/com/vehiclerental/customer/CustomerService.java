package com.vehiclerental.customer;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.vehiclerental.common.FileHandler;
import com.vehiclerental.common.IdGenerator;
import com.vehiclerental.common.RequestData;
import com.vehiclerental.common.ResourceNotFoundException;
import com.vehiclerental.common.ValidationException;

/**
 * MEMBER 1 - Business logic + file handling for customers (customers.txt).
 *
 * Lecture concepts:
 *  - ArrayList&lt;Customer&gt; (Lecture 08) keeps all customers in memory; every change is saved to file.
 *  - Polymorphism: the list holds RegularCustomer AND PremiumCustomer objects through the
 *    parent type Customer; c.authenticate(...) runs the correct child version.
 *  - Single Responsibility (SOLID): this class only handles customer rules, the controller only
 *    handles HTTP and the Customer classes only hold data.
 *  - Custom exceptions for invalid input / missing customers.
 */
@Service
public class CustomerService {

    private static final String FILE = "customers.txt";
    private final ArrayList<Customer> customers = new ArrayList<>();

    public CustomerService() {
        for (String line : FileHandler.readLines(FILE)) {
            try {
                customers.add(Customer.fromFileString(line));
            } catch (RuntimeException e) {
                System.err.println("Skipping bad customer line: " + line);
            }
        }
    }

    // ------------------------------------------------------------------ CREATE

    public synchronized Customer register(RequestData data) {
        String tier = data.getString("membershipTier", RegularCustomer.TIER).toUpperCase();
        String username = data.getString("username");
        String email = data.getString("email");
        String licence = data.getString("licenceNo").toUpperCase();
        ensureUnique(null, username, email, licence);

        String id = IdGenerator.next("CUS", customers);
        Customer customer;
        if (PremiumCustomer.TIER.equals(tier)) {
            customer = new PremiumCustomer(id, username, data.getString("fullName"), email,
                    data.getString("phone"), data.getString("password"), licence);
        } else {
            customer = new RegularCustomer(id, username, data.getString("fullName"), email,
                    data.getString("phone"), data.getString("password"), licence);
        }
        customers.add(customer);
        save();
        return customer;
    }

    // ------------------------------------------------------------------ READ

    public synchronized List<Customer> getAll() {
        return new ArrayList<>(customers);
    }

    public synchronized Customer findById(String id) {
        for (Customer c : customers) {
            if (c.getId().equalsIgnoreCase(id)) {
                return c;
            }
        }
        throw new ResourceNotFoundException("Customer", id);
    }

    /** Search by id, username, name, email or licence number (partial match). */
    public synchronized List<Customer> search(String query, String tier) {
        ArrayList<Customer> result = new ArrayList<>();
        String q = query == null ? "" : query.trim().toLowerCase();
        for (Customer c : customers) {
            boolean textMatch = q.isEmpty()
                    || c.getId().toLowerCase().contains(q)
                    || c.getUsername().toLowerCase().contains(q)
                    || c.getFullName().toLowerCase().contains(q)
                    || c.getEmail().contains(q)
                    || c.getLicenceNo().toLowerCase().contains(q);
            boolean tierMatch = tier == null || tier.isEmpty() || c.getMembershipTier().equalsIgnoreCase(tier);
            if (textMatch && tierMatch) {
                result.add(c);
            }
        }
        return result;
    }

    /** Login - polymorphism decides which authentication rules are used. */
    public synchronized Customer login(String identifier, String password) {
        for (Customer c : customers) {
            if (c.authenticate(identifier, password)) {
                return c;
            }
        }
        throw new ValidationException("Incorrect username or password");
    }

    // ------------------------------------------------------------------ UPDATE

    public synchronized Customer update(String id, RequestData data) {
        Customer c = findById(id);
        String email = data.getString("email", c.getEmail());
        String licence = data.getString("licenceNo", c.getLicenceNo()).toUpperCase();
        ensureUnique(id, c.getUsername(), email, licence);

        c.setFullName(data.getString("fullName", c.getFullName()));
        c.setEmail(email);
        c.setPhone(data.getString("phone", c.getPhone()));
        c.setLicenceNo(licence);
        if (data.has("newPassword")) {
            if (!c.checkPassword(data.getString("currentPassword", ""))) {
                throw new ValidationException("Current password is incorrect");
            }
            c.setPassword(data.getString("newPassword"));
        }

        String tier = data.getString("membershipTier", c.getMembershipTier()).toUpperCase();
        if (!tier.equals(c.getMembershipTier())) {
            c = changeTier(c, tier);
        }
        save();
        return c;
    }

    /**
     * Upgrading/downgrading changes the CLASS of the object (Regular -> Premium),
     * so a new child object is created and the data is copied across.
     */
    private Customer changeTier(Customer old, String tier) {
        Customer replacement = PremiumCustomer.TIER.equals(tier) ? new PremiumCustomer() : new RegularCustomer();
        old.copyTo(replacement);
        customers.set(customers.indexOf(old), replacement);
        return replacement;
    }

    /** Used by the Booking module when a rental is completed. */
    public synchronized void addLoyaltyPoints(String customerId, int points) {
        findById(customerId).addLoyaltyPoints(points);
        save();
    }

    // ------------------------------------------------------------------ DELETE

    public synchronized void delete(String id) {
        Customer c = findById(id);
        customers.remove(c);
        save();
    }

    // ------------------------------------------------------------------ helpers

    private void ensureUnique(String ignoreId, String username, String email, String licence) {
        for (Customer c : customers) {
            if (c.getId().equals(ignoreId)) {
                continue;
            }
            if (c.getUsername().equalsIgnoreCase(username)) {
                throw new ValidationException("Username '" + username + "' is already taken");
            }
            if (c.getEmail().equalsIgnoreCase(email)) {
                throw new ValidationException("An account with this email already exists");
            }
            if (c.getLicenceNo().equalsIgnoreCase(licence)) {
                throw new ValidationException("This driving licence is already registered");
            }
        }
    }

    private void save() {
        FileHandler.writeAll(FILE, customers);
    }
}
