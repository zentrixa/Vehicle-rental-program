package com.vehiclerental.customer;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.vehiclerental.common.RequestData;

/**
 * MEMBER 1 - REST endpoints used by the customer pages (register, login, profile, list).
 *
 *  POST   /api/customers            register        (Create)
 *  POST   /api/customers/login      login
 *  GET    /api/customers?q=&tier=   search / list   (Read)
 *  GET    /api/customers/{id}       one customer    (Read)
 *  PUT    /api/customers/{id}       update profile  (Update)
 *  DELETE /api/customers/{id}       delete account  (Delete)
 *
 * The controller depends on CustomerService (association). Spring passes the service
 * object into the constructor (dependency injection - the "D" in SOLID).
 */
@RestController
@RequestMapping("/api/customers")
public class CustomerController {

    private final CustomerService customerService;

    public CustomerController(CustomerService customerService) {
        this.customerService = customerService;
    }

    @PostMapping
    public ResponseEntity<Customer> register(@RequestBody Map<String, Object> body) {
        Customer created = customerService.register(new RequestData(body));
        return ResponseEntity.status(HttpStatus.CREATED).body(created);
    }

    @PostMapping("/login")
    public ResponseEntity<Customer> login(@RequestBody Map<String, Object> body) {
        RequestData data = new RequestData(body);
        return ResponseEntity.ok(customerService.login(data.getString("identifier"), data.getString("password")));
    }

    @GetMapping
    public ResponseEntity<List<Customer>> search(@RequestParam(value = "q", required = false) String q,
                                                 @RequestParam(value = "tier", required = false) String tier) {
        return ResponseEntity.ok(customerService.search(q, tier));
    }

    @GetMapping("/{id}")
    public ResponseEntity<Customer> getOne(@PathVariable("id") String id) {
        return ResponseEntity.ok(customerService.findById(id));
    }

    @PutMapping("/{id}")
    public ResponseEntity<Customer> update(@PathVariable("id") String id, @RequestBody Map<String, Object> body) {
        return ResponseEntity.ok(customerService.update(id, new RequestData(body)));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Map<String, Object>> delete(@PathVariable("id") String id) {
        customerService.delete(id);
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("message", "Customer " + id + " deleted");
        return ResponseEntity.ok(result);
    }
}
