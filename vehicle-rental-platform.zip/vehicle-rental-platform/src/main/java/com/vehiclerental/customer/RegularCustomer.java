package com.vehiclerental.customer;

import java.util.Arrays;
import java.util.List;

/**
 * MEMBER 1 - A standard (free) customer.
 *
 * Inheritance: RegularCustomer IS-A Customer IS-A User.
 * Polymorphism: overrides the abstract methods with "regular" rules and keeps the
 * default User.authenticate() (username + password only).
 */
public class RegularCustomer extends Customer {

    public static final String TIER = "REGULAR";

    public RegularCustomer() {
        super();
    }

    public RegularCustomer(String id, String username, String fullName, String email,
                           String phone, String rawPassword, String licenceNo) {
        super(id, username, fullName, email, phone, rawPassword, licenceNo);
    }

    @Override
    public double getDiscountRate() {
        return 0.0;
    }

    @Override
    public int getMaxActiveBookings() {
        return 2;
    }

    @Override
    public String getMembershipTier() {
        return TIER;
    }

    @Override
    public List<String> getPerks() {
        return Arrays.asList(
                "Book up to 2 vehicles at a time",
                "Earn 10 loyalty points per rental day",
                "Late returns charged at 1.5x the daily rate");
    }

    /**
     * Regular customers can ONLY sign in with their username (not email).
     * This is the parent version, called through super to show method reuse.
     */
    @Override
    public boolean authenticate(String identifier, String rawPassword) {
        return super.authenticate(identifier, rawPassword);
    }
}
