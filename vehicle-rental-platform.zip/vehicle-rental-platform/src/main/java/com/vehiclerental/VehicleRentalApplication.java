package com.vehiclerental;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import com.vehiclerental.common.FileHandler;

/**
 * Entry point of the Vehicle Rental Service Platform.
 *
 * Running this class starts an embedded web server on http://localhost:8080.
 * Spring scans every sub package (customer, vehicle, booking, admin, branch, review)
 * and creates one object of each @Service and @RestController class.
 *
 * IMPORTANT: open the website at http://localhost:8080 - do not open the .html files directly
 * (the pages need this server to load vehicles, bookings and so on).
 *
 * Shared kickoff file - set up jointly by all six members.
 */
@SpringBootApplication
public class VehicleRentalApplication {

    public static void main(String[] args) {
        ConfigurableApplicationContext context = SpringApplication.run(VehicleRentalApplication.class, args);
        String port = context.getEnvironment().getProperty("local.server.port", "8080");
        System.out.println();
        System.out.println("==============================================================");
        System.out.println("  Vehicle Rental is running.  Open:  http://localhost:" + port);
        System.out.println("  Staff sign in:  http://localhost:" + port + "/admin/login.html  (admin / admin123)");
        System.out.println("  Data folder:    " + FileHandler.getDataFolderPath());
        System.out.println("==============================================================");
        System.out.println();
    }
}
