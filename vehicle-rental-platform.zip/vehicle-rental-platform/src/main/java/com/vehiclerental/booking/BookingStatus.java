package com.vehiclerental.booking;

/**
 * MEMBER 3 - Life cycle of a booking: ACTIVE -> RETURNED, or ACTIVE -> CANCELLED.
 */
public enum BookingStatus {
    ACTIVE,
    RETURNED,
    CANCELLED
}
