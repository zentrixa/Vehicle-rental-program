package com.vehiclerental.booking;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

import com.vehiclerental.common.FileHandler;
import com.vehiclerental.common.ValidationException;

/**
 * MEMBER 3 - Component 03: Booking &amp; Return Management
 *
 * One rental of one vehicle by one customer.
 *
 * Lecture concepts:
 *  - Inheritance: Booking extends the abstract RentalTransaction and overrides calculateTotal().
 *  - Encapsulation: dates and money values can only change through methods that check the rules
 *    (markReturned() cannot be called twice, the due date cannot be before the start date ...).
 *  - Association: a booking stores the ids of a Customer and a Vehicle (it "uses" them),
 *    plus a copy of their names so old bookings still show correctly if a vehicle is later removed.
 *
 * File format (bookings.txt):
 * id|createdDate|customerId|customerName|customerTier|vehicleId|vehicleName|plateNumber|dailyRate|
 * startDate|dueDate|returnDate|baseCost|lateFee|status
 */
public class Booking extends RentalTransaction {

    private String customerId;
    private String customerName;
    private String customerTier;
    private String vehicleId;
    private String vehicleName;
    private String plateNumber;
    private double dailyRate;
    private LocalDate startDate;
    private LocalDate dueDate;
    private LocalDate returnDate;     // null while the booking is active
    private double baseCost;
    private double lateFee;
    private BookingStatus status;

    /** Default constructor (used when reading the file). */
    public Booking() {
        super();
        this.status = BookingStatus.ACTIVE;
    }

    /** Overloaded constructor for a brand-new booking. */
    public Booking(String id, String customerId, String customerName, String customerTier,
                   String vehicleId, String vehicleName, String plateNumber, double dailyRate,
                   LocalDate startDate, LocalDate dueDate, double baseCost) {
        super(id);
        if (dueDate.isBefore(startDate)) {
            throw new ValidationException("Return date cannot be before the pick-up date");
        }
        this.customerId = customerId;
        this.customerName = customerName;
        this.customerTier = customerTier;
        this.vehicleId = vehicleId;
        this.vehicleName = vehicleName;
        this.plateNumber = plateNumber;
        this.dailyRate = dailyRate;
        this.startDate = startDate;
        this.dueDate = dueDate;
        this.baseCost = baseCost;
        this.lateFee = 0;
        this.status = BookingStatus.ACTIVE;
    }

    // ------------------------------------------------------------------ overridden abstract methods

    @Override
    public double calculateTotal() {
        return Math.round((baseCost + lateFee) * 100.0) / 100.0;
    }

    @Override
    public String getSummary() {
        return customerName + " rented " + vehicleName + " from " + startDate + " to " + dueDate;
    }

    @Override
    public String toFileString() {
        return FileHandler.join(getId(), getCreatedDate(), customerId, customerName, customerTier, vehicleId,
                vehicleName, plateNumber, dailyRate, startDate, dueDate,
                returnDate == null ? "" : returnDate, baseCost, lateFee, status.name());
    }

    public static Booking fromFileString(String line) {
        String[] p = FileHandler.split(line);
        Booking b = new Booking();
        b.setId(p[0]);
        b.setCreatedDate(LocalDate.parse(p[1]));
        b.customerId = p[2];
        b.customerName = p[3];
        b.customerTier = p[4];
        b.vehicleId = p[5];
        b.vehicleName = p[6];
        b.plateNumber = p[7];
        b.dailyRate = Double.parseDouble(p[8]);
        b.startDate = LocalDate.parse(p[9]);
        b.dueDate = LocalDate.parse(p[10]);
        b.returnDate = p[11].isEmpty() ? null : LocalDate.parse(p[11]);
        b.baseCost = Double.parseDouble(p[12]);
        b.lateFee = Double.parseDouble(p[13]);
        b.status = BookingStatus.valueOf(p[14]);
        return b;
    }

    // ------------------------------------------------------------------ behaviour

    /** Number of days the vehicle is booked for (pick-up day counts as day 1). */
    public int getRentalDays() {
        return (int) ChronoUnit.DAYS.between(startDate, dueDate) + 1;
    }

    /** Days late compared with a given return date (method used by the fine calculators). */
    public int getDaysLate(LocalDate actualReturn) {
        long late = ChronoUnit.DAYS.between(dueDate, actualReturn);
        return (int) Math.max(0, late);
    }

    /** Days late if the vehicle were returned today (overloaded - no parameter). */
    public int getDaysLate() {
        if (status == BookingStatus.ACTIVE) {
            return getDaysLate(LocalDate.now());
        }
        return returnDate == null ? 0 : getDaysLate(returnDate);     // cancelled bookings were never returned
    }

    public boolean isOverdue() {
        return status == BookingStatus.ACTIVE && LocalDate.now().isAfter(dueDate);
    }

    /** Days remaining until the due date (negative when overdue). */
    public long getDaysUntilDue() {
        return ChronoUnit.DAYS.between(LocalDate.now(), dueDate);
    }

    /** True when this booking overlaps the given date range (used for availability). */
    public boolean overlaps(LocalDate from, LocalDate to) {
        return status == BookingStatus.ACTIVE && !to.isBefore(startDate) && !from.isAfter(dueDate);
    }

    /** Records the return. The fine is calculated outside by a FineCalculator. */
    public void markReturned(LocalDate actualReturn, double fine) {
        if (status != BookingStatus.ACTIVE) {
            throw new ValidationException("Booking " + getId() + " is already " + status.name().toLowerCase());
        }
        if (actualReturn.isBefore(startDate)) {
            throw new ValidationException("Return date cannot be before the pick-up date");
        }
        this.returnDate = actualReturn;
        this.lateFee = fine;
        this.status = BookingStatus.RETURNED;
    }

    public void cancel() {
        if (status != BookingStatus.ACTIVE) {
            throw new ValidationException("Only active bookings can be cancelled");
        }
        this.status = BookingStatus.CANCELLED;
    }

    // ------------------------------------------------------------------ getters

    public String getCustomerId() {
        return customerId;
    }

    public String getCustomerName() {
        return customerName;
    }

    public String getCustomerTier() {
        return customerTier;
    }

    public String getVehicleId() {
        return vehicleId;
    }

    public String getVehicleName() {
        return vehicleName;
    }

    public String getPlateNumber() {
        return plateNumber;
    }

    public double getDailyRate() {
        return dailyRate;
    }

    public LocalDate getStartDate() {
        return startDate;
    }

    public LocalDate getDueDate() {
        return dueDate;
    }

    public LocalDate getReturnDate() {
        return returnDate;
    }

    public double getBaseCost() {
        return baseCost;
    }

    public double getLateFee() {
        return lateFee;
    }

    public double getTotal() {
        return calculateTotal();
    }

    public BookingStatus getStatus() {
        return status;
    }
}
