package com.vehiclerental.booking;

import java.time.LocalDate;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.vehiclerental.common.RequestData;

/**
 * MEMBER 3 - REST endpoints used by the booking pages.
 *
 *  POST   /api/bookings                           book a vehicle            (Create)
 *  GET    /api/bookings/quote?...                 price before booking      (Read)
 *  GET    /api/bookings?status=&customerId=&q=    list / search bookings    (Read)
 *  GET    /api/bookings/{id}                      one booking               (Read)
 *  GET    /api/bookings/{id}/fine?returnDate=     late fee preview          (Read)
 *  GET    /api/bookings/stats                     numbers for dashboards    (Read)
 *  PUT    /api/bookings/{id}/return               return vehicle + fine     (Update)
 *  PUT    /api/bookings/{id}/cancel               cancel booking            (Update)
 *  DELETE /api/bookings/{id}                      remove completed booking  (Delete)
 */
@RestController
@RequestMapping("/api/bookings")
public class BookingController {

    private final BookingService bookingService;

    public BookingController(BookingService bookingService) {
        this.bookingService = bookingService;
    }

    @PostMapping
    public ResponseEntity<Booking> create(@RequestBody Map<String, Object> body) {
        return ResponseEntity.status(HttpStatus.CREATED).body(bookingService.create(new RequestData(body)));
    }

    @GetMapping("/quote")
    public ResponseEntity<Map<String, Object>> quote(@RequestParam("customerId") String customerId,
                                                     @RequestParam("vehicleId") String vehicleId,
                                                     @RequestParam("startDate") String startDate,
                                                     @RequestParam("dueDate") String dueDate) {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("startDate", startDate);
        body.put("dueDate", dueDate);
        RequestData data = new RequestData(body);       // reuse the date validation
        return ResponseEntity.ok(bookingService.quote(customerId, vehicleId, data.getDate("startDate"), data.getDate("dueDate")));
    }

    @GetMapping
    public ResponseEntity<List<Booking>> search(@RequestParam(value = "status", required = false) String status,
                                                @RequestParam(value = "customerId", required = false) String customerId,
                                                @RequestParam(value = "q", required = false) String q) {
        return ResponseEntity.ok(bookingService.search(status, customerId, q));
    }

    @GetMapping("/stats")
    public ResponseEntity<Map<String, Object>> stats() {
        return ResponseEntity.ok(bookingService.getStats());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Booking> getOne(@PathVariable("id") String id) {
        return ResponseEntity.ok(bookingService.findById(id));
    }

    @GetMapping("/{id}/fine")
    public ResponseEntity<Map<String, Object>> finePreview(@PathVariable("id") String id,
                                                           @RequestParam(value = "returnDate", required = false) String returnDate) {
        LocalDate date = (returnDate == null || returnDate.isEmpty()) ? LocalDate.now() : LocalDate.parse(returnDate);
        return ResponseEntity.ok(bookingService.finePreview(id, date));
    }

    @PutMapping("/{id}/return")
    public ResponseEntity<Booking> returnVehicle(@PathVariable("id") String id, @RequestBody Map<String, Object> body) {
        return ResponseEntity.ok(bookingService.returnVehicle(id, new RequestData(body)));
    }

    @PutMapping("/{id}/cancel")
    public ResponseEntity<Booking> cancel(@PathVariable("id") String id) {
        return ResponseEntity.ok(bookingService.cancel(id));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Map<String, Object>> delete(@PathVariable("id") String id) {
        bookingService.delete(id);
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("message", "Booking " + id + " deleted");
        return ResponseEntity.ok(result);
    }
}
