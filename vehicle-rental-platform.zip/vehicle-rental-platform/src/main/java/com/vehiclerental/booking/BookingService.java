package com.vehiclerental.booking;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.vehiclerental.common.FileHandler;
import com.vehiclerental.common.IdGenerator;
import com.vehiclerental.common.RequestData;
import com.vehiclerental.common.ResourceNotFoundException;
import com.vehiclerental.common.ValidationException;
import com.vehiclerental.customer.Customer;
import com.vehiclerental.customer.CustomerService;
import com.vehiclerental.customer.PremiumCustomer;
import com.vehiclerental.vehicle.Vehicle;
import com.vehiclerental.vehicle.VehicleService;
import com.vehiclerental.vehicle.VehicleStatus;

/**
 * MEMBER 3 - Business logic + file handling for bookings (bookings.txt).
 *
 * Lecture concepts:
 *  - Implements the AvailabilityChecker interface (abstraction).
 *  - Association: uses CustomerService (Member 1) and VehicleService (Member 2), received through
 *    the constructor (dependency injection).
 *  - Polymorphism:
 *      * vehicle.calculateRentalCost(days, discount) runs the Car / Van / Motorcycle pricing rule.
 *      * customer.getDiscountRate() / getMaxActiveBookings() run the Regular / Premium rule.
 *      * a FineCalculator variable holds either a RegularFineCalculator or a PremiumFineCalculator.
 *  - Custom exception VehicleNotAvailableException.
 */
@Service
public class BookingService implements AvailabilityChecker {

    private static final String FILE = "bookings.txt";
    private static final int MAX_RENTAL_DAYS = 30;
    private static final int POINTS_PER_DAY = 10;

    private final ArrayList<Booking> bookings = new ArrayList<>();
    private final CustomerService customerService;
    private final VehicleService vehicleService;

    public BookingService(CustomerService customerService, VehicleService vehicleService) {
        this.customerService = customerService;
        this.vehicleService = vehicleService;
        for (String line : FileHandler.readLines(FILE)) {
            try {
                bookings.add(Booking.fromFileString(line));
            } catch (RuntimeException e) {
                System.err.println("Skipping bad booking line: " + line);
            }
        }
    }

    // ------------------------------------------------------------------ AvailabilityChecker

    @Override
    public synchronized boolean isVehicleAvailable(String vehicleId, LocalDate start, LocalDate end) {
        Vehicle vehicle = vehicleService.findById(vehicleId);
        if (vehicle.getStatus() != VehicleStatus.AVAILABLE) {
            return false;
        }
        for (Booking b : bookings) {
            if (b.getVehicleId().equals(vehicleId) && b.overlaps(start, end)) {
                return false;
            }
        }
        return true;
    }

    // ------------------------------------------------------------------ CREATE

    public synchronized Booking create(RequestData data) {
        Customer customer = customerService.findById(data.getString("customerId"));
        Vehicle vehicle = vehicleService.findById(data.getString("vehicleId"));
        LocalDate start = data.getDate("startDate");
        LocalDate due = data.getDate("dueDate");

        validateDates(start, due);
        if (countActive(customer.getId()) >= customer.getMaxActiveBookings()) {
            throw new ValidationException(customer.getMembershipTier().charAt(0)
                    + customer.getMembershipTier().substring(1).toLowerCase()
                    + " members can have " + customer.getMaxActiveBookings()
                    + " active bookings at a time. Return a vehicle first.");
        }
        if (!isVehicleAvailable(vehicle.getId(), start, due)) {
            throw new VehicleNotAvailableException(vehicle.getDisplayName());
        }

        int days = (int) java.time.temporal.ChronoUnit.DAYS.between(start, due) + 1;
        double cost = vehicle.calculateRentalCost(days, customer.getDiscountRate());   // polymorphism x2

        Booking booking = new Booking(IdGenerator.next("BKG", bookings), customer.getId(), customer.getFullName(),
                customer.getMembershipTier(), vehicle.getId(), vehicle.getDisplayName(), vehicle.getPlateNumber(),
                vehicle.getDailyRate(), start, due, cost);
        bookings.add(booking);
        vehicleService.updateStatus(vehicle.getId(), VehicleStatus.RENTED);
        save();
        return booking;
    }

    /** Shows the price before the customer confirms (no booking is saved). */
    public synchronized Map<String, Object> quote(String customerId, String vehicleId, LocalDate start, LocalDate due) {
        validateDates(start, due);
        Customer customer = customerService.findById(customerId);
        Vehicle vehicle = vehicleService.findById(vehicleId);
        int days = (int) java.time.temporal.ChronoUnit.DAYS.between(start, due) + 1;
        Map<String, Object> map = new LinkedHashMap<>();
        map.put("days", days);
        map.put("standardCost", vehicle.calculateRentalCost(days));
        map.put("discountRate", customer.getDiscountRate());
        map.put("finalCost", vehicle.calculateRentalCost(days, customer.getDiscountRate()));
        map.put("available", isVehicleAvailable(vehicleId, start, due));
        map.put("finePolicy", fineCalculatorFor(customer.getMembershipTier()).getPolicyDescription());
        return map;
    }

    // ------------------------------------------------------------------ READ

    public synchronized List<Booking> search(String status, String customerId, String q) {
        ArrayList<Booking> result = new ArrayList<>();
        String text = q == null ? "" : q.trim().toLowerCase();
        for (Booking b : bookings) {
            if (status != null && !status.isEmpty()) {
                boolean wantOverdue = status.equalsIgnoreCase("OVERDUE");
                if (wantOverdue ? !b.isOverdue() : !b.getStatus().name().equalsIgnoreCase(status)) {
                    continue;
                }
            }
            if (customerId != null && !customerId.isEmpty() && !b.getCustomerId().equalsIgnoreCase(customerId)) {
                continue;
            }
            if (!text.isEmpty() && !(b.getId() + " " + b.getCustomerName() + " " + b.getVehicleName() + " "
                    + b.getPlateNumber()).toLowerCase().contains(text)) {
                continue;
            }
            result.add(b);
        }
        return result;
    }

    public synchronized Booking findById(String id) {
        for (Booking b : bookings) {
            if (b.getId().equalsIgnoreCase(id)) {
                return b;
            }
        }
        throw new ResourceNotFoundException("Booking", id);
    }

    /** Used by the review module: has this customer completed a rental of this vehicle? */
    public synchronized Booking findCompletedRental(String customerId, String vehicleId) {
        for (Booking b : bookings) {
            if (b.getCustomerId().equals(customerId) && b.getVehicleId().equals(vehicleId)
                    && b.getStatus() == BookingStatus.RETURNED) {
                return b;
            }
        }
        return null;
    }

    /** Fine preview for the return page. */
    public synchronized Map<String, Object> finePreview(String id, LocalDate returnDate) {
        Booking b = findById(id);
        FineCalculator calculator = fineCalculatorFor(b.getCustomerTier());
        int daysLate = b.getDaysLate(returnDate);
        double fine = calculator.calculateFine(daysLate, b.getDailyRate());
        Map<String, Object> map = new LinkedHashMap<>();
        map.put("bookingId", b.getId());
        map.put("daysLate", daysLate);
        map.put("lateFee", fine);
        map.put("baseCost", b.getBaseCost());
        map.put("total", Math.round((b.getBaseCost() + fine) * 100.0) / 100.0);
        map.put("policy", calculator.getPolicyDescription());
        return map;
    }

    // ------------------------------------------------------------------ UPDATE (return / cancel)

    public synchronized Booking returnVehicle(String id, RequestData data) {
        Booking b = findById(id);
        LocalDate returnDate = data.has("returnDate") ? data.getDate("returnDate") : LocalDate.now();
        FineCalculator calculator = fineCalculatorFor(b.getCustomerTier());      // polymorphism
        double fine = calculator.calculateFine(b.getDaysLate(returnDate), b.getDailyRate());

        b.markReturned(returnDate, fine);
        vehicleService.updateStatus(b.getVehicleId(), VehicleStatus.AVAILABLE);
        vehicleService.addMileage(b.getVehicleId(), data.getInt("kmDriven", 0));
        try {
            customerService.addLoyaltyPoints(b.getCustomerId(), b.getRentalDays() * POINTS_PER_DAY);
        } catch (ResourceNotFoundException ignored) {
            // customer account was deleted - booking is still returned
        }
        save();
        return b;
    }

    public synchronized Booking cancel(String id) {
        Booking b = findById(id);
        b.cancel();
        vehicleService.updateStatus(b.getVehicleId(), VehicleStatus.AVAILABLE);
        save();
        return b;
    }

    // ------------------------------------------------------------------ DELETE

    /** Completed (returned or cancelled) transactions can be removed. */
    public synchronized void delete(String id) {
        Booking b = findById(id);
        if (b.getStatus() == BookingStatus.ACTIVE) {
            throw new ValidationException("Active bookings cannot be deleted. Return or cancel it first.");
        }
        bookings.remove(b);
        save();
    }

    // ------------------------------------------------------------------ statistics

    public synchronized Map<String, Object> getStats() {
        int active = 0;
        int overdue = 0;
        int returned = 0;
        double revenue = 0;
        double fines = 0;
        for (Booking b : bookings) {
            if (b.getStatus() == BookingStatus.ACTIVE) {
                active++;
                if (b.isOverdue()) {
                    overdue++;
                }
            }
            if (b.getStatus() == BookingStatus.RETURNED) {
                returned++;
                revenue += b.calculateTotal();
                fines += b.getLateFee();
            }
        }
        Map<String, Object> map = new LinkedHashMap<>();
        map.put("total", bookings.size());
        map.put("active", active);
        map.put("overdue", overdue);
        map.put("returned", returned);
        map.put("revenue", Math.round(revenue * 100.0) / 100.0);
        map.put("lateFees", Math.round(fines * 100.0) / 100.0);
        return map;
    }

    // ------------------------------------------------------------------ helpers

    /** Chooses the fine rule for a customer tier - returns the interface type. */
    private FineCalculator fineCalculatorFor(String tier) {
        if (PremiumCustomer.TIER.equalsIgnoreCase(tier)) {
            return new PremiumFineCalculator();
        }
        return new RegularFineCalculator();
    }

    private void validateDates(LocalDate start, LocalDate due) {
        if (start.isBefore(LocalDate.now())) {
            throw new ValidationException("Pick-up date cannot be in the past");
        }
        if (due.isBefore(start)) {
            throw new ValidationException("Return date cannot be before the pick-up date");
        }
        if (java.time.temporal.ChronoUnit.DAYS.between(start, due) + 1 > MAX_RENTAL_DAYS) {
            throw new ValidationException("A single booking can be at most " + MAX_RENTAL_DAYS + " days");
        }
    }

    private int countActive(String customerId) {
        int count = 0;
        for (Booking b : bookings) {
            if (b.getCustomerId().equals(customerId) && b.getStatus() == BookingStatus.ACTIVE) {
                count++;
            }
        }
        return count;
    }

    private void save() {
        FileHandler.writeAll(FILE, bookings);
    }
}
