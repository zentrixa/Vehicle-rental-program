package com.vehiclerental.booking;

import java.time.LocalDate;

import com.vehiclerental.common.FileStorable;

/**
 * MEMBER 3 - Abstract parent of every money-related record of the rental business.
 *
 * Lecture concepts:
 *  - Abstract class: holds what ALL transactions have (id, created date) and declares
 *    calculateTotal() without a body, because each transaction type totals differently.
 *  - Booking extends this class (inheritance). A future "Invoice" or "DamageCharge" class could
 *    extend it too without changing existing code (Open/Closed principle).
 */
public abstract class RentalTransaction implements FileStorable {

    private String id;
    private LocalDate createdDate;

    protected RentalTransaction() {
        this.createdDate = LocalDate.now();
    }

    protected RentalTransaction(String id) {
        this();
        this.id = id;
    }

    /** Final amount the customer must pay for this transaction. */
    public abstract double calculateTotal();

    /** One-line human readable summary. */
    public abstract String getSummary();

    @Override
    public String getId() {
        return id;
    }

    protected void setId(String id) {
        this.id = id;
    }

    public LocalDate getCreatedDate() {
        return createdDate;
    }

    protected void setCreatedDate(LocalDate createdDate) {
        this.createdDate = createdDate;
    }
}
