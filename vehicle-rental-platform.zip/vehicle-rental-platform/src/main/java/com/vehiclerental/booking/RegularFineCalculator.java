package com.vehiclerental.booking;

/**
 * MEMBER 3 - Fine rule for regular customers: 1.5 x the daily rate for each late day.
 */
public class RegularFineCalculator implements FineCalculator {

    private static final double MULTIPLIER = 1.5;

    @Override
    public double calculateFine(int daysLate, double dailyRate) {
        if (daysLate <= 0) {
            return 0;
        }
        return Math.round(daysLate * dailyRate * MULTIPLIER * 100.0) / 100.0;
    }

    @Override
    public String getPolicyDescription() {
        return "Regular members pay 1.5x the daily rate for every late day.";
    }
}
