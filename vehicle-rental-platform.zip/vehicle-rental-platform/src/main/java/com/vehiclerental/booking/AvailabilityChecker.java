package com.vehiclerental.booking;

import java.time.LocalDate;

/**
 * MEMBER 3 - Abstraction of "can this vehicle be booked for these dates?".
 *
 * The booking page and createBooking() only need the answer (true/false); HOW it is
 * worked out (vehicle status + overlapping bookings) is hidden inside BookingService.
 */
public interface AvailabilityChecker {

    boolean isVehicleAvailable(String vehicleId, LocalDate start, LocalDate end);
}
