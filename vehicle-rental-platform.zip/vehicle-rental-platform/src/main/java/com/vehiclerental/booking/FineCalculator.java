package com.vehiclerental.booking;

/**
 * MEMBER 3 - Interface for late-return fine rules (Lecture 05 - interfaces).
 *
 * Two classes implement it in different ways:
 *   RegularFineCalculator - 1.5 x daily rate for every late day
 *   PremiumFineCalculator - first late day free, then 1.0 x daily rate
 *
 * BookingService only talks to the FineCalculator type, so it does not care which rule is used
 * (polymorphism + Dependency Inversion principle).
 */
public interface FineCalculator {

    /** @return the fine in rupees for returning a vehicle late. */
    double calculateFine(int daysLate, double dailyRate);

    /** @return a sentence describing the rule, shown on the return page. */
    String getPolicyDescription();
}
