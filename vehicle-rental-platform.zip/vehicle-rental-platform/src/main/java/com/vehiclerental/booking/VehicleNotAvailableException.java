package com.vehiclerental.booking;

import com.vehiclerental.common.AppException;

/**
 * MEMBER 3 - Custom exception thrown when someone tries to book a vehicle that is
 * already rented or under maintenance for the chosen dates. HTTP 409 Conflict.
 */
public class VehicleNotAvailableException extends AppException {

    public VehicleNotAvailableException(String vehicleName) {
        super(vehicleName + " is not available for the selected dates. Try different dates or another vehicle.");
    }

    @Override
    public int getStatusCode() {
        return 409;
    }
}
