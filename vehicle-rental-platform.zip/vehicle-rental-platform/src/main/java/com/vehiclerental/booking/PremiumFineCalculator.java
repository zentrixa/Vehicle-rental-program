package com.vehiclerental.booking;

/**
 * MEMBER 3 - Fine rule for premium customers: the first late day is a free grace day,
 * after that the normal daily rate is charged (no penalty multiplier).
 */
public class PremiumFineCalculator implements FineCalculator {

    private static final int GRACE_DAYS = 1;

    @Override
    public double calculateFine(int daysLate, double dailyRate) {
        int chargeableDays = daysLate - GRACE_DAYS;
        if (chargeableDays <= 0) {
            return 0;
        }
        return Math.round(chargeableDays * dailyRate * 100.0) / 100.0;
    }

    @Override
    public String getPolicyDescription() {
        return "Premium members get 1 free grace day, then pay the normal daily rate per late day.";
    }
}
