package com.vehiclerental.common;

/**
 * Thrown when user input is missing or invalid (for example an empty name or a bad email).
 * Results in HTTP 400 Bad Request.
 */
public class ValidationException extends AppException {

    public ValidationException(String message) {
        super(message);
    }

    @Override
    public int getStatusCode() {
        return 400;
    }
}
