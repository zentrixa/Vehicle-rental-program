package com.vehiclerental.common;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeParseException;
import java.util.HashMap;
import java.util.Map;

/**
 * Wraps the JSON form data that the browser sends (a Map of field name -> value)
 * and gives safe, validated access to each field.
 *
 * Lecture concepts:
 *  - Encapsulation: the map is private and final; only these methods can read it.
 *  - Method overloading (compile-time polymorphism): getString(key) vs getString(key, default),
 *    getDouble(key) vs getDouble(key, default) ... same name, different parameter lists.
 *  - Custom exceptions: a missing or invalid value throws ValidationException.
 *
 * Shared kickoff file - set up jointly by all six members.
 */
public class RequestData {

    private final Map<String, Object> values;

    public RequestData(Map<String, Object> values) {
        this.values = values == null ? new HashMap<>() : values;
    }

    public boolean has(String key) {
        Object v = values.get(key);
        return v != null && !String.valueOf(v).trim().isEmpty();
    }

    /** True when the form sent this field at all, even if it is empty (used to clear a value). */
    public boolean contains(String key) {
        return values.containsKey(key);
    }

    /** Required text field. */
    public String getString(String key) {
        if (!has(key)) {
            throw new ValidationException(label(key) + " is required");
        }
        return String.valueOf(values.get(key)).trim();
    }

    /** Optional text field (overloaded). */
    public String getString(String key, String defaultValue) {
        return has(key) ? String.valueOf(values.get(key)).trim() : defaultValue;
    }

    /** Required number. */
    public double getDouble(String key) {
        String text = getString(key);
        try {
            return Double.parseDouble(text);
        } catch (NumberFormatException e) {
            throw new ValidationException(label(key) + " must be a number");
        }
    }

    /** Optional number (overloaded). */
    public double getDouble(String key, double defaultValue) {
        return has(key) ? getDouble(key) : defaultValue;
    }

    /** Required whole number. */
    public int getInt(String key) {
        return (int) Math.round(getDouble(key));
    }

    /** Optional whole number (overloaded). */
    public int getInt(String key, int defaultValue) {
        return has(key) ? getInt(key) : defaultValue;
    }

    /** Optional true/false value. Accepts true/false, yes/no, on/off. */
    public boolean getBoolean(String key, boolean defaultValue) {
        if (!has(key)) {
            return defaultValue;
        }
        String v = String.valueOf(values.get(key)).trim().toLowerCase();
        return v.equals("true") || v.equals("yes") || v.equals("on") || v.equals("1");
    }

    /** Required date in yyyy-MM-dd format. */
    public LocalDate getDate(String key) {
        String text = getString(key);
        try {
            return LocalDate.parse(text);
        } catch (DateTimeParseException e) {
            throw new ValidationException(label(key) + " must be a valid date (yyyy-mm-dd)");
        }
    }

    /** Required time in HH:mm format. */
    public LocalTime getTime(String key) {
        String text = getString(key);
        try {
            return LocalTime.parse(text);
        } catch (DateTimeParseException e) {
            throw new ValidationException(label(key) + " must be a valid time (hh:mm)");
        }
    }

    /** Turns "plateNumber" into "Plate number" for friendly error messages. */
    private String label(String key) {
        String spaced = key.replaceAll("([A-Z])", " $1").toLowerCase();
        return Character.toUpperCase(spaced.charAt(0)) + spaced.substring(1);
    }
}
