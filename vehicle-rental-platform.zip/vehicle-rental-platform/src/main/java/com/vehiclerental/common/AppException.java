package com.vehiclerental.common;

/**
 * Base class for all custom exceptions in the project (Lecture 06 - custom exceptions).
 *
 * It is abstract (Lecture 05): every child exception must say which HTTP status
 * code it represents. GlobalExceptionHandler uses that number to build the response.
 *
 * Shared kickoff file - set up jointly by all six members.
 */
public abstract class AppException extends RuntimeException {

    protected AppException(String message) {
        super(message);
    }

    /** @return HTTP status code to send to the browser (400, 404, 409 ...). */
    public abstract int getStatusCode();
}
