package com.vehiclerental.common;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;

/**
 * Utility class that reads and writes the plain text data files
 * (customers.txt, vehicles.txt, bookings.txt, admins.txt, branches.txt, reviews.txt).
 *
 * Lecture concepts:
 *  - static members (Lecture 05): every method is static, so we call
 *    FileHandler.readLines("vehicles.txt") without creating an object.
 *  - static block: runs once when the class is first loaded, finds (or creates) the data folder.
 *
 * Works on every computer:
 *  - Files are always read and written as UTF-8 (Windows would otherwise use a different encoding).
 *  - If a data file is missing (for example a fresh clone, or the app was started from another folder),
 *    it is restored from the demo copy inside the project (src/main/resources/seed-data/).
 *  - Exception handling (Lecture 06): try / catch / finally around file operations.
 *  - ArrayList with generics (Lecture 08): lines are returned as ArrayList&lt;String&gt;.
 *
 * Shared kickoff file - set up jointly by all six members.
 */
public final class FileHandler {

    /** Folder (relative to the project root) where all .txt files are kept. */
    public static final String DATA_DIR = "data";

    /** Demo copies of the data files, packaged inside the application. */
    private static final String SEED_FOLDER = "/seed-data/";

    /** The data folder actually used (decided once, in the static block). */
    private static final File DATA_FOLDER;

    // static block - executed only once, when the class is loaded
    static {
        DATA_FOLDER = findDataFolder();
        if (!DATA_FOLDER.exists()) {
            DATA_FOLDER.mkdirs();
        }
    }

    /**
     * Normally ./data. If IntelliJ was opened one folder too high (the folder that CONTAINS the project),
     * ./vehicle-rental-platform/data is used instead, so the same files are found either way.
     * A different folder can also be chosen with -Dapp.data.dir=...
     */
    private static File findDataFolder() {
        String custom = System.getProperty("app.data.dir");
        if (custom != null && !custom.trim().isEmpty()) {
            return new File(custom.trim());
        }
        File normal = new File(DATA_DIR);
        if (normal.exists() || new File("pom.xml").exists()) {
            return normal;
        }
        File nested = new File("vehicle-rental-platform", DATA_DIR);
        return nested.exists() ? nested : normal;
    }

    /** Full path of the data folder - printed when the application starts. */
    public static String getDataFolderPath() {
        return DATA_FOLDER.getAbsolutePath();
    }

    /** Copies the packaged demo file into the data folder when the real file does not exist yet. */
    private static void restoreFromSeed(String fileName, File target) {
        try (InputStream in = FileHandler.class.getResourceAsStream(SEED_FOLDER + fileName)) {
            if (in == null) {
                return;                          // no demo copy for this file
            }
            Files.copy(in, target.toPath());
            System.out.println("Created " + target.getAbsolutePath() + " from the demo data");
        } catch (IOException e) {
            System.err.println("Could not create " + fileName + " from the demo data: " + e.getMessage());
        }
    }

    // private constructor: nobody should create a FileHandler object
    private FileHandler() {
    }

    /**
     * Reads every non-empty line of a data file.
     * Uses a classic try / catch / finally so the reader is always closed.
     */
    public static ArrayList<String> readLines(String fileName) {
        ArrayList<String> lines = new ArrayList<>();
        File file = new File(DATA_FOLDER, fileName);
        if (!file.exists()) {
            restoreFromSeed(fileName, file);
        }
        if (!file.exists()) {
            return lines;               // no file and no demo copy -> empty list
        }

        BufferedReader reader = null;
        try {
            reader = new BufferedReader(new FileReader(file, StandardCharsets.UTF_8));
            String line;
            while ((line = reader.readLine()) != null) {
                if (!line.trim().isEmpty() && !line.startsWith("#")) {
                    lines.add(line);
                }
            }
        } catch (IOException e) {
            System.err.println("Could not read " + fileName + ": " + e.getMessage());
        } finally {
            try {
                if (reader != null) {
                    reader.close();
                }
            } catch (IOException ignored) {
                // nothing else we can do here
            }
        }
        return lines;
    }

    /**
     * Overwrites a data file with the given objects (one object per line).
     * Accepts any list of FileStorable objects - this works for every module (polymorphism).
     */
    public static void writeAll(String fileName, List<? extends FileStorable> items) {
        ArrayList<String> lines = new ArrayList<>();
        for (FileStorable item : items) {
            lines.add(item.toFileString());
        }
        writeLines(fileName, lines);
    }

    /** Overwrites a data file with plain text lines (try-with-resources version). */
    public static void writeLines(String fileName, List<String> lines) {
        File file = new File(DATA_FOLDER, fileName);
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file, StandardCharsets.UTF_8, false))) {
            for (String line : lines) {
                writer.write(line);
                writer.newLine();
            }
        } catch (IOException e) {
            throw new IllegalStateException("Could not save " + fileName + ": " + e.getMessage());
        }
    }

    /** Adds a single line to the end of a file without touching the other lines. */
    public static void appendLine(String fileName, String line) {
        File file = new File(DATA_FOLDER, fileName);
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file, StandardCharsets.UTF_8, true))) {
            writer.write(line);
            writer.newLine();
        } catch (IOException e) {
            throw new IllegalStateException("Could not save " + fileName + ": " + e.getMessage());
        }
    }

    /** Splits one line of a data file into its fields. */
    public static String[] split(String line) {
        return line.split("\\|", -1);
    }

    /**
     * Cleans user text before it is stored: removes the field separator and line breaks
     * so one object always stays on one line.
     */
    public static String clean(String value) {
        if (value == null) {
            return "";
        }
        return value.replace("|", "/").replace("\r", " ").replace("\n", " ").trim();
    }

    /** Joins fields with the separator - small helper used by every toFileString(). */
    public static String join(Object... fields) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < fields.length; i++) {
            if (i > 0) {
                sb.append(FileStorable.SEPARATOR);
            }
            sb.append(fields[i] == null ? "" : clean(String.valueOf(fields[i])));
        }
        return sb.toString();
    }
}
