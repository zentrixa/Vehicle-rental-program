package com.vehiclerental.common;

import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.http.ResponseEntity;
import org.springframework.web.ErrorResponse;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

/**
 * Catches exceptions thrown by ANY controller and turns them into a JSON message
 * such as {"error": "Plate number is required"}.
 *
 * Because every custom exception extends AppException, one method handles all of
 * them (polymorphism: ex.getStatusCode() runs the child class version).
 *
 * Shared kickoff file - set up jointly by all six members.
 */
@RestControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(AppException.class)
    public ResponseEntity<Map<String, Object>> handleAppException(AppException ex) {
        return ResponseEntity.status(ex.getStatusCode()).body(body(ex.getMessage(), ex.getStatusCode()));
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<Map<String, Object>> handleUnexpected(Exception ex) throws Exception {
        if (ex instanceof ErrorResponse) {
            // Spring's own HTTP errors (missing page = 404, wrong method = 405 ...): let Spring answer them normally
            throw ex;
        }
        ex.printStackTrace();
        return ResponseEntity.status(500).body(body("Something went wrong on the server: " + ex.getMessage(), 500));
    }

    private Map<String, Object> body(String message, int status) {
        Map<String, Object> map = new LinkedHashMap<>();
        map.put("error", message);
        map.put("status", status);
        return map;
    }
}
