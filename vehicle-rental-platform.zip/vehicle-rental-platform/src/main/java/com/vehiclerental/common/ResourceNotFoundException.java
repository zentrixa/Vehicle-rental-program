package com.vehiclerental.common;

/**
 * Thrown when an object with the requested id does not exist.
 * Results in HTTP 404 Not Found.
 */
public class ResourceNotFoundException extends AppException {

    public ResourceNotFoundException(String what, String id) {
        super(what + " " + id + " was not found");
    }

    @Override
    public int getStatusCode() {
        return 404;
    }
}
