package com.vehiclerental.common;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * Shared abstract base class for every person who can log in to the system.
 *
 *            User (abstract)
 *           /               \
 *     Customer (M1)        Admin (M4)
 *      /       \
 * Regular    Premium
 *
 * Lecture concepts:
 *  - Abstraction / abstract class (Lecture 05): a "User" on its own is incomplete,
 *    so it cannot be created with new User(). getRole() is abstract.
 *  - Encapsulation (Lecture 02): all fields are private, validated setters protect them.
 *    The password is only stored as a SHA-256 hash and has no public getter for JSON (@JsonIgnore).
 *  - Constructors: a default constructor and an overloaded constructor.
 *  - Inheritance (Lecture 04): Customer and Admin reuse these fields and methods.
 *
 * Shared kickoff file - set up jointly by all six members.
 */
public abstract class User implements FileStorable {

    private String id;
    private String username;
    private String fullName;
    private String email;
    private String phone;
    private String passwordHash;
    private LocalDate joinedDate;

    /** Default constructor - used when an object is rebuilt from a file line. */
    protected User() {
        this.joinedDate = LocalDate.now();
    }

    /** Overloaded constructor - used when a new user registers. */
    protected User(String id, String username, String fullName, String email, String phone, String rawPassword) {
        this();                       // call the default constructor first (constructor chaining)
        this.id = id;
        setUsername(username);
        setFullName(fullName);
        setEmail(email);
        setPhone(phone);
        setPassword(rawPassword);
    }

    // ------------------------------------------------------------------ abstract methods

    /** Each child class says what kind of user it is (CUSTOMER, SUPER_ADMIN, STAFF ...). */
    public abstract String getRole();

    // ------------------------------------------------------------------ behaviour

    /**
     * Default login check: identifier must equal the username and the password must match.
     * Child classes OVERRIDE this to provide different authentication rules (runtime polymorphism).
     */
    public boolean authenticate(String identifier, String rawPassword) {
        return identifier != null
                && identifier.trim().equalsIgnoreCase(username)
                && checkPassword(rawPassword);
    }

    /** Compares a typed password with the stored hash. */
    public boolean checkPassword(String rawPassword) {
        return rawPassword != null && hash(rawPassword).equals(passwordHash);
    }

    /** Turns a plain password into a SHA-256 hex string. Static: does not need an object. */
    protected static String hash(String raw) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] bytes = digest.digest(raw.getBytes(StandardCharsets.UTF_8));
            StringBuilder hex = new StringBuilder();
            for (byte b : bytes) {
                hex.append(String.format("%02x", b));
            }
            return hex.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException("SHA-256 not available", e);
        }
    }

    // ------------------------------------------------------------------ getters & setters

    @Override
    public String getId() {
        return id;
    }

    protected void setId(String id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        if (username == null || !username.trim().matches("[A-Za-z0-9_.]{3,20}")) {
            throw new ValidationException("Username must be 3-20 letters, numbers, dots or underscores");
        }
        this.username = username.trim();
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        if (fullName == null || fullName.trim().length() < 2) {
            throw new ValidationException("Full name must have at least 2 characters");
        }
        this.fullName = fullName.trim();
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        if (email == null || !email.trim().matches("^[\\w.+-]+@[\\w-]+(\\.[\\w-]+)+$")) {
            throw new ValidationException("Enter a valid email address, for example name@mail.com");
        }
        this.email = email.trim().toLowerCase();
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        String digits = phone == null ? "" : phone.replaceAll("[\\s-]", "");
        if (!digits.matches("0\\d{9}")) {
            throw new ValidationException("Phone number must have 10 digits and start with 0");
        }
        this.phone = digits;
    }

    /** New password - validated and stored as a hash. */
    public void setPassword(String rawPassword) {
        if (rawPassword == null || rawPassword.length() < 6) {
            throw new ValidationException("Password must have at least 6 characters");
        }
        this.passwordHash = hash(rawPassword);
    }

    /** Hidden from JSON so the hash is never sent to the browser. */
    @JsonIgnore
    public String getPasswordHash() {
        return passwordHash;
    }

    /** Used only when loading from a file (the value is already a hash). */
    protected void setPasswordHash(String passwordHash) {
        this.passwordHash = passwordHash;
    }

    public LocalDate getJoinedDate() {
        return joinedDate;
    }

    protected void setJoinedDate(LocalDate joinedDate) {
        this.joinedDate = joinedDate;
    }

    @Override
    public String toString() {
        return getRole() + " " + username + " (" + fullName + ")";
    }
}
