package com.vehiclerental.common;

import java.util.List;

/**
 * Creates readable ids such as CUS-001, VEH-012, BKG-104.
 * A static utility (Lecture 05) shared by all modules.
 *
 * Shared kickoff file - set up jointly by all six members.
 */
public final class IdGenerator {

    private IdGenerator() {
    }

    /**
     * Finds the largest number already used with this prefix and returns the next one.
     *
     * @param prefix   e.g. "VEH"
     * @param existing objects that already exist (any FileStorable)
     */
    public static String next(String prefix, List<? extends FileStorable> existing) {
        int max = 0;
        for (FileStorable item : existing) {
            String id = item.getId();
            if (id != null && id.startsWith(prefix + "-")) {
                try {
                    int number = Integer.parseInt(id.substring(prefix.length() + 1));
                    max = Math.max(max, number);
                } catch (NumberFormatException ignored) {
                    // id does not end with a number - skip it
                }
            }
        }
        return String.format("%s-%03d", prefix, max + 1);
    }
}
