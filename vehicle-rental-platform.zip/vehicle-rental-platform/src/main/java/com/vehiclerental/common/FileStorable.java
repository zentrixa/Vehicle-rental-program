package com.vehiclerental.common;

/**
 * Interface (Lecture 05) - a contract that says WHAT a class must do, not HOW.
 *
 * Every entity that is saved to a .txt file (Customer, Vehicle, Booking, Admin,
 * Branch, Review) implements this interface, so FileHandler and the services can
 * treat all of them the same way when writing to disk.
 */
public interface FileStorable {

    /** Character used to separate fields in one line of a data file. */
    String SEPARATOR = "|";

    /** @return the unique id of the object (for example CUS-001). */
    String getId();

    /** @return one line of text that represents this object inside its .txt file. */
    String toFileString();
}
