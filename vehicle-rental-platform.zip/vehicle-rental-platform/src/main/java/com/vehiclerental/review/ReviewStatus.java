package com.vehiclerental.review;

/**
 * MEMBER 6 - Moderation state of a review.
 *  VISIBLE - shown to everyone
 *  FLAGGED - waiting for an admin to check it (still hidden from customers)
 *  HIDDEN  - removed from public view by an admin
 */
public enum ReviewStatus {
    VISIBLE,
    FLAGGED,
    HIDDEN
}
