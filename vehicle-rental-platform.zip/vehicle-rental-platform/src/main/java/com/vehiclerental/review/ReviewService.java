package com.vehiclerental.review;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.vehiclerental.admin.AdminPrivileges;
import com.vehiclerental.admin.AdminService;
import com.vehiclerental.booking.Booking;
import com.vehiclerental.booking.BookingService;
import com.vehiclerental.common.FileHandler;
import com.vehiclerental.common.IdGenerator;
import com.vehiclerental.common.RequestData;
import com.vehiclerental.common.ResourceNotFoundException;
import com.vehiclerental.common.ValidationException;
import com.vehiclerental.customer.Customer;
import com.vehiclerental.customer.CustomerService;
import com.vehiclerental.vehicle.Vehicle;
import com.vehiclerental.vehicle.VehicleService;

/**
 * MEMBER 6 - Business logic + file handling for reviews (reviews.txt).
 *
 * Lecture concepts:
 *  - Association with other modules: CustomerService, VehicleService, BookingService and AdminService.
 *  - Polymorphism: a new review becomes a VerifiedReview when the customer has a returned booking
 *    for that vehicle, otherwise a PublicReview - the rest of the code just uses the Review type.
 *  - Interface type: moderators are checked through the AdminPrivileges interface.
 *  - static helper ContentModerator.findIssue() flags inappropriate text automatically.
 */
@Service
public class ReviewService {

    private static final String FILE = "reviews.txt";

    private final ArrayList<Review> reviews = new ArrayList<>();
    private final CustomerService customerService;
    private final VehicleService vehicleService;
    private final BookingService bookingService;
    private final AdminService adminService;

    public ReviewService(CustomerService customerService, VehicleService vehicleService,
                         BookingService bookingService, AdminService adminService) {
        this.customerService = customerService;
        this.vehicleService = vehicleService;
        this.bookingService = bookingService;
        this.adminService = adminService;
        for (String line : FileHandler.readLines(FILE)) {
            try {
                reviews.add(Review.fromFileString(line));
            } catch (RuntimeException e) {
                System.err.println("Skipping bad review line: " + line);
            }
        }
    }

    // ------------------------------------------------------------------ CREATE

    public synchronized Review create(RequestData d) {
        Customer customer = customerService.findById(d.getString("customerId"));
        Vehicle vehicle = vehicleService.findById(d.getString("vehicleId"));
        for (Review r : reviews) {
            if (r.getCustomerId().equals(customer.getId()) && r.getVehicleId().equals(vehicle.getId())) {
                throw new ValidationException("You already reviewed this vehicle. Edit your existing review instead.");
            }
        }

        String id = IdGenerator.next("REV", reviews);
        Booking completed = bookingService.findCompletedRental(customer.getId(), vehicle.getId());
        Review review;
        if (completed != null) {
            review = new VerifiedReview(id, vehicle.getId(), vehicle.getDisplayName(), customer.getId(),
                    customer.getFullName(), d.getInt("rating"), d.getString("title"), d.getString("comment"),
                    completed.getId());
        } else {
            review = new PublicReview(id, vehicle.getId(), vehicle.getDisplayName(), customer.getId(),
                    customer.getFullName(), d.getInt("rating"), d.getString("title"), d.getString("comment"));
        }
        autoModerate(review);
        reviews.add(review);
        save();
        return review;
    }

    // ------------------------------------------------------------------ READ

    /** Reviews visible to customers (optionally for one vehicle). */
    public synchronized List<Map<String, Object>> getPublicView(String vehicleId, String customerId) {
        ArrayList<Map<String, Object>> list = new ArrayList<>();
        for (Review r : newestFirst()) {
            boolean ownReview = customerId != null && r.getCustomerId().equals(customerId);
            if (!r.isVisible() && !ownReview) {
                continue;                       // customers only see their own hidden/flagged reviews
            }
            if (vehicleId != null && !vehicleId.isEmpty() && !r.getVehicleId().equals(vehicleId)) {
                continue;
            }
            Map<String, Object> view = r.displayForCustomer();        // polymorphic call
            if (ownReview) {
                view.put("status", r.getStatus().name());
            }
            list.add(view);
        }
        return list;
    }

    /** Full information for the moderation panel. */
    public synchronized List<Map<String, Object>> getAdminView(String status, String q) {
        ArrayList<Map<String, Object>> list = new ArrayList<>();
        String text = q == null ? "" : q.trim().toLowerCase();
        for (Review r : newestFirst()) {
            if (status != null && !status.isEmpty() && !r.getStatus().name().equalsIgnoreCase(status)) {
                continue;
            }
            if (!text.isEmpty() && !(r.getTitle() + " " + r.getComment() + " " + r.getCustomerName() + " "
                    + r.getVehicleName()).toLowerCase().contains(text)) {
                continue;
            }
            list.add(r.displayForAdmin());                            // polymorphic call
        }
        return list;
    }

    public synchronized Review findById(String id) {
        for (Review r : reviews) {
            if (r.getId().equalsIgnoreCase(id)) {
                return r;
            }
        }
        throw new ResourceNotFoundException("Review", id);
    }

    /** Average rating, weighted average (polymorphic weights) and star distribution. */
    public synchronized Map<String, Object> summary(String vehicleId) {
        int count = 0;
        double sum = 0;
        double weightedSum = 0;
        double weights = 0;
        int verified = 0;
        int[] stars = new int[6];
        for (Review r : reviews) {
            if (!r.isVisible() || (vehicleId != null && !vehicleId.isEmpty() && !r.getVehicleId().equals(vehicleId))) {
                continue;
            }
            count++;
            sum += r.getRating();
            weightedSum += r.getRating() * r.getWeight();
            weights += r.getWeight();
            stars[r.getRating()]++;
            if (r instanceof VerifiedReview) {
                verified++;
            }
        }
        Map<String, Object> map = new LinkedHashMap<>();
        map.put("count", count);
        map.put("verifiedCount", verified);
        map.put("average", count == 0 ? 0 : Math.round(sum / count * 10) / 10.0);
        map.put("weightedAverage", weights == 0 ? 0 : Math.round(weightedSum / weights * 10) / 10.0);
        Map<String, Integer> distribution = new LinkedHashMap<>();
        for (int s = 5; s >= 1; s--) {
            distribution.put(String.valueOf(s), stars[s]);
        }
        map.put("distribution", distribution);
        int flagged = 0;
        for (Review r : reviews) {
            if (r.getStatus() == ReviewStatus.FLAGGED) {
                flagged++;
            }
        }
        map.put("flaggedCount", flagged);
        return map;
    }

    // ------------------------------------------------------------------ UPDATE

    /** Only the customer who wrote the review can edit it. */
    public synchronized Review update(String id, RequestData d) {
        Review r = findById(id);
        if (!r.getCustomerId().equals(d.getString("customerId"))) {
            throw new ValidationException("You can only edit your own reviews");
        }
        r.edit(d.getInt("rating", r.getRating()), d.getString("title", r.getTitle()), d.getString("comment", r.getComment()));
        if (r.getStatus() == ReviewStatus.FLAGGED || r.getStatus() == ReviewStatus.VISIBLE) {
            r.moderate(ReviewStatus.VISIBLE, "");
            autoModerate(r);                               // check the new text again
        }
        save();
        return r;
    }

    /** Admin moderation: show, flag or hide. */
    public synchronized Review moderate(String id, RequestData d) {
        AdminPrivileges moderator = adminService.findById(d.getString("adminId"));   // interface type
        if (!moderator.canModerateReviews()) {
            throw new ValidationException("Your role cannot moderate reviews");
        }
        Review r = findById(id);
        ReviewStatus status;
        try {
            status = ReviewStatus.valueOf(d.getString("status").toUpperCase());
        } catch (IllegalArgumentException e) {
            throw new ValidationException("Status must be VISIBLE, FLAGGED or HIDDEN");
        }
        r.moderate(status, d.getString("reason", "Hidden by a moderator"));
        save();
        return r;
    }

    // ------------------------------------------------------------------ DELETE

    /** The author OR an admin with the moderation permission can delete a review. */
    public synchronized void delete(String id, String customerId, String adminId) {
        Review r = findById(id);
        boolean isOwner = customerId != null && customerId.equals(r.getCustomerId());
        boolean isModerator = false;
        if (adminId != null && !adminId.isEmpty()) {
            AdminPrivileges admin = adminService.findById(adminId);
            isModerator = admin.canModerateReviews();
        }
        if (!isOwner && !isModerator) {
            throw new ValidationException("Only the author or a moderator can delete this review");
        }
        reviews.remove(r);
        save();
    }

    // ------------------------------------------------------------------ helpers

    private void autoModerate(Review r) {
        String issue = ContentModerator.findIssue(r.getTitle() + " " + r.getComment());
        if (issue != null) {
            r.moderate(ReviewStatus.FLAGGED, issue);
        }
    }

    private List<Review> newestFirst() {
        ArrayList<Review> copy = new ArrayList<>(reviews);
        copy.sort((a, b) -> b.getId().compareTo(a.getId()));
        return copy;
    }

    private void save() {
        FileHandler.writeAll(FILE, reviews);
    }
}
