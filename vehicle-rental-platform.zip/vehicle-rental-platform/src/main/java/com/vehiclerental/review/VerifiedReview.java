package com.vehiclerental.review;

import java.util.Map;

/**
 * MEMBER 6 - A review written by a customer who actually rented and returned this vehicle.
 *
 * Polymorphism:
 *  - getWeight() returns 1.5, so verified opinions count more in the weighted rating.
 *  - displayForCustomer() / displayForAdmin() are OVERRIDDEN: they call the parent version
 *    with super and then add the verified-rental details.
 */
public class VerifiedReview extends Review {

    public static final String TYPE = "VERIFIED";

    private String bookingId;

    public VerifiedReview() {
        super();
        this.bookingId = "";
    }

    public VerifiedReview(String id, String vehicleId, String vehicleName, String customerId, String customerName,
                          int rating, String title, String comment, String bookingId) {
        super(id, vehicleId, vehicleName, customerId, customerName, rating, title, comment);
        this.bookingId = bookingId;
    }

    @Override
    public String getType() {
        return TYPE;
    }

    @Override
    public String getBadge() {
        return "Verified rental";
    }

    @Override
    public double getWeight() {
        return 1.5;
    }

    @Override
    public Map<String, Object> displayForCustomer() {
        Map<String, Object> map = super.displayForCustomer();
        map.put("verifiedNote", "Rented this vehicle through Vehicle Rental");
        return map;
    }

    @Override
    public Map<String, Object> displayForAdmin() {
        Map<String, Object> map = super.displayForAdmin();
        map.put("bookingId", bookingId);
        return map;
    }

    @Override
    protected String extraFileField() {
        return bookingId;
    }

    @Override
    protected void readExtraField(String value) {
        this.bookingId = value;
    }

    public String getBookingId() {
        return bookingId;
    }
}
