package com.vehiclerental.review;

import java.time.LocalDate;
import java.util.LinkedHashMap;
import java.util.Map;

import com.vehiclerental.common.FileHandler;
import com.vehiclerental.common.FileStorable;
import com.vehiclerental.common.ValidationException;

/**
 * MEMBER 6 - Component 06: Feedback and Review Management
 *
 *            Review (abstract)
 *            /              \
 *     PublicReview      VerifiedReview
 *
 * Lecture concepts:
 *  - Encapsulation: rating (1-5), title and comment are validated in setters; status can only
 *    change through moderate().
 *  - Abstraction: getType(), getBadge() and getWeight() are abstract.
 *  - Inheritance: both review types reuse all fields and methods here.
 *  - Polymorphism:
 *      * displayForCustomer() and displayForAdmin() - two different "views" of the same object
 *        (admins see ids, status and flag reasons; customers only see public information).
 *      * the child classes override these display methods to add their own details.
 *      * getWeight() - verified reviews count more in the weighted average rating.
 *
 * File format (reviews.txt):
 * TYPE|id|vehicleId|vehicleName|customerId|customerName|rating|title|comment|createdDate|editedDate|status|flagReason|bookingId
 */
public abstract class Review implements FileStorable {

    private String id;
    private String vehicleId;
    private String vehicleName;
    private String customerId;
    private String customerName;
    private int rating;
    private String title;
    private String comment;
    private LocalDate createdDate;
    private LocalDate editedDate;
    private ReviewStatus status;
    private String flagReason;

    protected Review() {
        this.createdDate = LocalDate.now();
        this.status = ReviewStatus.VISIBLE;
        this.flagReason = "";
    }

    protected Review(String id, String vehicleId, String vehicleName, String customerId, String customerName,
                     int rating, String title, String comment) {
        this();
        this.id = id;
        this.vehicleId = vehicleId;
        this.vehicleName = vehicleName;
        this.customerId = customerId;
        this.customerName = customerName;
        setRating(rating);
        setTitle(title);
        setComment(comment);
    }

    // ------------------------------------------------------------------ abstract methods

    /** PUBLIC or VERIFIED. */
    public abstract String getType();

    /** Label shown next to the review. */
    public abstract String getBadge();

    /** How much this review counts in the weighted average rating. */
    public abstract double getWeight();

    /** Extra value written at the end of the file line (booking id for verified reviews). */
    protected abstract String extraFileField();

    protected abstract void readExtraField(String value);

    // ------------------------------------------------------------------ polymorphic display methods

    /** What a normal customer sees: no ids, short name, only public info. */
    public Map<String, Object> displayForCustomer() {
        Map<String, Object> map = new LinkedHashMap<>();
        map.put("id", id);
        map.put("type", getType());
        map.put("badge", getBadge());
        map.put("vehicleId", vehicleId);
        map.put("vehicleName", vehicleName);
        map.put("author", shortName());
        map.put("customerId", customerId);       // needed so the author can find their own review to edit
        map.put("rating", rating);
        map.put("title", title);
        map.put("comment", comment);
        map.put("date", createdDate.toString());
        map.put("edited", editedDate != null);
        return map;
    }

    /** What an admin sees: everything, including moderation data. */
    public Map<String, Object> displayForAdmin() {
        Map<String, Object> map = displayForCustomer();
        map.put("author", customerName);
        map.put("customerId", customerId);
        map.put("status", status.name());
        map.put("flagReason", flagReason);
        map.put("weight", getWeight());
        map.put("editedDate", editedDate == null ? null : editedDate.toString());
        return map;
    }

    // ------------------------------------------------------------------ behaviour

    /** "Nimal Perera" -> "Nimal P." (privacy for the public view). */
    protected String shortName() {
        String[] parts = customerName.trim().split("\\s+");
        if (parts.length == 1) {
            return parts[0];
        }
        return parts[0] + " " + parts[parts.length - 1].charAt(0) + ".";
    }

    public void edit(int rating, String title, String comment) {
        setRating(rating);
        setTitle(title);
        setComment(comment);
        this.editedDate = LocalDate.now();
    }

    /** Changes the moderation state (used by admins and by the automatic checker). */
    public void moderate(ReviewStatus newStatus, String reason) {
        this.status = newStatus;
        this.flagReason = newStatus == ReviewStatus.VISIBLE ? "" : FileHandler.clean(reason);
    }

    public boolean isVisible() {
        return status == ReviewStatus.VISIBLE;
    }

    @Override
    public String toFileString() {
        return FileHandler.join(getType(), id, vehicleId, vehicleName, customerId, customerName, rating, title,
                comment, createdDate, editedDate == null ? "" : editedDate, status.name(), flagReason, extraFileField());
    }

    public static Review fromFileString(String line) {
        String[] p = FileHandler.split(line);
        Review r = VerifiedReview.TYPE.equals(p[0]) ? new VerifiedReview() : new PublicReview();
        r.id = p[1];
        r.vehicleId = p[2];
        r.vehicleName = p[3];
        r.customerId = p[4];
        r.customerName = p[5];
        r.rating = Integer.parseInt(p[6]);
        r.title = p[7];
        r.comment = p[8];
        r.createdDate = LocalDate.parse(p[9]);
        r.editedDate = p[10].isEmpty() ? null : LocalDate.parse(p[10]);
        r.status = ReviewStatus.valueOf(p[11]);
        r.flagReason = p[12];
        r.readExtraField(p[13]);
        return r;
    }

    // ------------------------------------------------------------------ getters & setters

    @Override
    public String getId() {
        return id;
    }

    public String getVehicleId() {
        return vehicleId;
    }

    public String getVehicleName() {
        return vehicleName;
    }

    public String getCustomerId() {
        return customerId;
    }

    public String getCustomerName() {
        return customerName;
    }

    public int getRating() {
        return rating;
    }

    public void setRating(int rating) {
        if (rating < 1 || rating > 5) {
            throw new ValidationException("Rating must be between 1 and 5 stars");
        }
        this.rating = rating;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        if (title == null || title.trim().length() < 3 || title.trim().length() > 80) {
            throw new ValidationException("Title must be between 3 and 80 characters");
        }
        this.title = title.trim();
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        if (comment == null || comment.trim().length() < 10 || comment.trim().length() > 1000) {
            throw new ValidationException("Review text must be between 10 and 1000 characters");
        }
        this.comment = comment.trim();
    }

    public LocalDate getCreatedDate() {
        return createdDate;
    }

    public LocalDate getEditedDate() {
        return editedDate;
    }

    public ReviewStatus getStatus() {
        return status;
    }

    public String getFlagReason() {
        return flagReason;
    }
}
