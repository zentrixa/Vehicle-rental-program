package com.vehiclerental.review;

import java.util.Arrays;
import java.util.List;

/**
 * MEMBER 6 - Very small automatic checker for review text.
 *
 * Everything is static (Lecture 05): the word list is shared by the whole program and the
 * method is called as ContentModerator.findIssue(text) without creating an object.
 */
public final class ContentModerator {

    private static final List<String> BLOCKED_WORDS = Arrays.asList(
            "idiot", "stupid", "scam", "fraud", "useless", "hate", "damn", "trash");

    private static final int MAX_CAPITALS_PERCENT = 70;

    private ContentModerator() {
    }

    /**
     * @return a reason when the text looks inappropriate, or null when it is fine.
     */
    public static String findIssue(String text) {
        if (text == null || text.isEmpty()) {
            return null;
        }
        String lower = text.toLowerCase();
        for (String word : BLOCKED_WORDS) {
            if (lower.matches(".*\\b" + word + "\\b.*")) {
                return "Contains blocked word \"" + word + "\"";
            }
        }
        if (lower.matches(".*(https?://|www\\.).*")) {
            return "Contains a link";
        }
        int letters = 0;
        int capitals = 0;
        for (char c : text.toCharArray()) {
            if (Character.isLetter(c)) {
                letters++;
                if (Character.isUpperCase(c)) {
                    capitals++;
                }
            }
        }
        if (letters >= 12 && capitals * 100 / letters > MAX_CAPITALS_PERCENT) {
            return "Written mostly in capital letters";
        }
        return null;
    }
}
