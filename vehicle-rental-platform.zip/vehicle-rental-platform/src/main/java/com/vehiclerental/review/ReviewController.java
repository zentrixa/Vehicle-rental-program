package com.vehiclerental.review;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.vehiclerental.common.RequestData;

/**
 * MEMBER 6 - REST endpoints used by the review pages.
 *
 *  POST   /api/reviews                               submit review         (Create)
 *  GET    /api/reviews?vehicleId=&customerId=        public view           (Read - customer display)
 *  GET    /api/reviews/admin?status=&q=              moderation view       (Read - admin display)
 *  GET    /api/reviews/summary?vehicleId=            rating summary        (Read)
 *  PUT    /api/reviews/{id}                          edit own review       (Update)
 *  PATCH  /api/reviews/{id}/status                   moderate              (Update)
 *  DELETE /api/reviews/{id}?customerId=|adminId=     delete review         (Delete)
 */
@RestController
@RequestMapping("/api/reviews")
public class ReviewController {

    private final ReviewService reviewService;

    public ReviewController(ReviewService reviewService) {
        this.reviewService = reviewService;
    }

    @PostMapping
    public ResponseEntity<Map<String, Object>> create(@RequestBody Map<String, Object> body) {
        Review review = reviewService.create(new RequestData(body));
        Map<String, Object> view = review.displayForCustomer();
        view.put("status", review.getStatus().name());
        view.put("flagReason", review.getFlagReason());
        return ResponseEntity.status(HttpStatus.CREATED).body(view);
    }

    @GetMapping
    public ResponseEntity<List<Map<String, Object>>> publicView(
            @RequestParam(value = "vehicleId", required = false) String vehicleId,
            @RequestParam(value = "customerId", required = false) String customerId) {
        return ResponseEntity.ok(reviewService.getPublicView(vehicleId, customerId));
    }

    @GetMapping("/admin")
    public ResponseEntity<List<Map<String, Object>>> adminView(
            @RequestParam(value = "status", required = false) String status,
            @RequestParam(value = "q", required = false) String q) {
        return ResponseEntity.ok(reviewService.getAdminView(status, q));
    }

    @GetMapping("/summary")
    public ResponseEntity<Map<String, Object>> summary(@RequestParam(value = "vehicleId", required = false) String vehicleId) {
        return ResponseEntity.ok(reviewService.summary(vehicleId));
    }

    @PutMapping("/{id}")
    public ResponseEntity<Map<String, Object>> update(@PathVariable("id") String id, @RequestBody Map<String, Object> body) {
        Review review = reviewService.update(id, new RequestData(body));
        Map<String, Object> view = review.displayForCustomer();
        view.put("status", review.getStatus().name());
        view.put("flagReason", review.getFlagReason());
        return ResponseEntity.ok(view);
    }

    @PatchMapping("/{id}/status")
    public ResponseEntity<Map<String, Object>> moderate(@PathVariable("id") String id, @RequestBody Map<String, Object> body) {
        return ResponseEntity.ok(reviewService.moderate(id, new RequestData(body)).displayForAdmin());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Map<String, Object>> delete(@PathVariable("id") String id,
                                                      @RequestParam(value = "customerId", required = false) String customerId,
                                                      @RequestParam(value = "adminId", required = false) String adminId) {
        reviewService.delete(id, customerId, adminId);
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("message", "Review " + id + " deleted");
        return ResponseEntity.ok(result);
    }
}
