package com.vehiclerental.review;

/**
 * MEMBER 6 - A review from a signed-in customer who has NOT yet completed a rental of this vehicle.
 * Counts normally (weight 1.0) in the average rating.
 */
public class PublicReview extends Review {

    public static final String TYPE = "PUBLIC";

    public PublicReview() {
        super();
    }

    public PublicReview(String id, String vehicleId, String vehicleName, String customerId, String customerName,
                        int rating, String title, String comment) {
        super(id, vehicleId, vehicleName, customerId, customerName, rating, title, comment);
    }

    @Override
    public String getType() {
        return TYPE;
    }

    @Override
    public String getBadge() {
        return "Customer review";
    }

    @Override
    public double getWeight() {
        return 1.0;
    }

    @Override
    protected String extraFileField() {
        return "";
    }

    @Override
    protected void readExtraField(String value) {
        // public reviews have no extra data
    }
}
