/* Contact page (kickoff file, owned by the whole team).
   Shows live branch phone numbers and opening status from the Branch module (Member 5). */

(function () {
  "use strict";

  const $ = (id) => document.getElementById(id);

  async function loadBranches() {
    try {
      const branches = await api.get("/api/branches");
      const open = branches.filter((b) => b.openNow);
      $("openNow").textContent = open.length + " of " + branches.length + " right now";
      $("branchPhones").innerHTML = branches.map((b) =>
        "<li><span><strong>" + ui.escape(b.name) + '</strong><br><span class="small muted">' + ui.escape(b.operatingHours) + " &middot; " +
        (b.openNow ? '<span style="color:var(--go)">open now</span>' : "closed") + "</span></span>" +
        '<a href="tel:' + b.phone + '">' + ui.escape(b.phone) + "</a></li>").join("");
      const allDay = branches.filter((b) => b.operatingHours === "Open 24 hours").map((b) => b.name);
      if (allDay.length) $("faq24").textContent = allDay.join(", ") + (allDay.length === 1 ? " is" : " are") + " open 24 hours.";
    } catch (e) {
      $("openNow").textContent = "Branch list unavailable";
    }
  }

  function setupForm() {
    const form = $("contactForm");
    const s = Session.get();
    if (s && s.kind === "customer") $("cName").value = s.name;
    form.addEventListener("submit", (e) => {
      e.preventDefault();
      const d = ui.formData(form);
      if (!d.name || !d.email || d.message.length < 10) {
        toast("Fill in your name, email and a message of at least 10 characters", "error");
        return;
      }
      const body = d.message + "\n\n" + d.name + " (" + d.email + ")";
      location.href = "mailto:hello@vehiclerental.lk?subject=" + encodeURIComponent(d.topic) + "&body=" + encodeURIComponent(body);
      toast("Your email app is opening with the message", "success");
    });
  }

  document.addEventListener("DOMContentLoaded", () => {
    loadBranches();
    setupForm();
  });
})();
