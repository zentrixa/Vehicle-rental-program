/* =====================================================================
   MEMBER 5 - Branch Management (front end)
   Pages: register.html (Create), list.html (Read/search; staff can Delete), edit.html (Update/Delete)
   Talks to BranchController: /api/branches
   ===================================================================== */

(function () {
  "use strict";

  const $ = (id) => document.getElementById(id);
  const API = "/api/branches";
  let allBranches = [];
  let vehicleCounts = {};

  const hhmm = (t) => String(t || "00:00").slice(0, 5);
  const minutes = (t) => { const p = hhmm(t).split(":"); return Number(p[0]) * 60 + Number(p[1]); };

  /** Same rule as Branch.isOpenAt() in Java, so the badge can update every minute without a server call. */
  function isOpen(b, date) {
    const open = minutes(b.openingTime);
    const close = minutes(b.closingTime);
    if (open === close) return true;
    const now = (date || new Date()).getHours() * 60 + (date || new Date()).getMinutes();
    return now >= open && now < close;
  }

  function hoursBar(b) {
    const open = minutes(b.openingTime);
    const close = minutes(b.closingTime);
    const left = open === close ? 0 : (open / 1440) * 100;
    const width = open === close ? 100 : ((close - open) / 1440) * 100;
    const now = new Date();
    const nowPct = ((now.getHours() * 60 + now.getMinutes()) / 1440) * 100;
    return '<div><div class="hours-bar" title="' + ui.escape(b.operatingHours) + '"><div class="open" style="left:' + left + "%;width:" + width + '%"></div>' +
      '<div class="now" style="left:' + nowPct + '%"></div></div><div class="hours-scale"><span>00</span><span>06</span><span>12</span><span>18</span><span>24</span></div></div>';
  }

  function branchCard(b, i, manage, isPreview) {
    const parent = b.type === "SUB" ? allBranches.find((p) => p.id === b.parentBranchId) : null;
    const count = vehicleCounts[b.id] || 0;
    const open = isOpen(b);
    return '<article class="branch-card" id="' + b.id + '" data-id="' + b.id + '" style="animation-delay:' + i * 60 + 'ms">' +
      '<div class="bc-head ' + (b.type === "SUB" ? "sub" : "") + '"><span class="type">' + (b.type === "MAIN" ? "Main branch" : "Sub branch") + "</span>" +
      '<span class="badge ' + (open ? "badge-go" : "badge-stop") + '" data-open-badge>' + (open ? "Open now" : "Closed") + "</span>" +
      "<h3>" + ui.escape(b.name) + '</h3><div class="small">' + ui.escape(b.city) + (b.managerName ? " &middot; Manager " + ui.escape(b.managerName) : "") + "</div></div>" +
      '<div class="bc-body">' +
      '<div class="bc-line">' + ui.icons.pin + "<span>" + ui.escape(b.address) + "</span></div>" +
      '<div class="bc-line">' + ui.icons.phone + "<span>" + ui.escape(b.phone) + " &middot; " + ui.escape(b.email) + "</span></div>" +
      '<div class="bc-line">' + ui.icons.clock + "<span>" + ui.escape(b.operatingHours) + "</span></div>" +
      hoursBar(b) +
      '<p class="bc-info">' + ui.escape(b.displayInfo) + (parent ? " (" + ui.escape(parent.name) + ")" : "") + "</p>" +
      '<div class="services">' + b.services.map((s) => "<span>" + ui.escape(s) + "</span>").join("") + "</div>" +
      '<div class="bc-foot"><div class="capacity"><strong>' + count + "</strong> of " + b.vehicleCapacity + ' vehicles stationed<div class="due-bar"><span style="width:' +
      Math.min(100, (count / b.vehicleCapacity) * 100) + '%"></span></div></div>' +
      (isPreview ? "" : '<div class="actions">' +
      (manage ? '<a class="btn btn-ghost btn-sm" href="/branches/edit.html?id=' + b.id + '">Edit</a><button class="btn btn-ghost btn-sm" data-delete style="color:var(--stop)">Delete</button>'
              : '<a class="btn btn-ghost btn-sm" href="/vehicles/search.html?branch=' + b.id + '">Vehicles</a>') + "</div>") +
      "</div></div></article>";
  }

  async function loadVehicleCounts() {
    try {
      const vehicles = await api.get("/api/vehicles");
      vehicleCounts = {};
      vehicles.forEach((v) => { vehicleCounts[v.branchId] = (vehicleCounts[v.branchId] || 0) + 1; });
    } catch (e) { vehicleCounts = {}; }
  }

  // ================================================================ list page
  const filter = { q: "", city: "", type: "" };
  let manage = false;

  async function loadList() {
    let list = await api.get(api.url(API, filter));
    if ($("openOnly").checked) list = list.filter((b) => isOpen(b));
    $("branchGrid").innerHTML = list.length ? list.map((b, i) => branchCard(b, i, manage)).join("")
      : '<div class="empty" style="grid-column:1/-1"><h3>No branches found</h3><p>Try another city or clear the search.</p></div>';
    if (location.hash) {
      const el = document.querySelector(location.hash);
      if (el) { el.classList.add("focus"); el.scrollIntoView({ behavior: "smooth", block: "center" }); }
    }
  }

  /** Every 30 seconds: move the "now" needle and re-check open/closed. */
  function tick() {
    const now = new Date();
    const pct = ((now.getHours() * 60 + now.getMinutes()) / 1440) * 100;
    document.querySelectorAll(".branch-card").forEach((card) => {
      const b = allBranches.find((x) => x.id === card.dataset.id);
      if (!b) return;
      const needle = card.querySelector(".now");
      if (needle) needle.style.left = pct + "%";
      const badge = card.querySelector("[data-open-badge]");
      const open = isOpen(b, now);
      badge.className = "badge " + (open ? "badge-go" : "badge-stop");
      badge.textContent = open ? "Open now" : "Closed";
    });
  }

  async function initList() {
    manage = Session.isAdmin() && Session.can("Manage branches");
    if (!Session.isAdmin()) document.body.dataset.area = "";
    if (manage) $("adminActions").classList.remove("hidden");
    if (Session.isAdmin()) document.body.dataset.nav = "admin";

    const [branches, cities] = await Promise.all([api.get(API), api.get(API + "/cities"), loadVehicleCounts()]);
    allBranches = branches;
    const openCount = branches.filter((b) => isOpen(b)).length;
    $("branchSummary").textContent = branches.length + " locations in " + cities.length + " cities. " + openCount + " are open right now.";
    $("cityChips").insertAdjacentHTML("beforeend", cities.map((c) => '<button class="chip" data-city="' + ui.escape(c) + '">' + ui.escape(c) + "</button>").join(""));

    await loadList();
    setInterval(tick, 30000);

    $("branchSearch").addEventListener("input", ui.debounce((e) => { filter.q = e.target.value; loadList(); }, 250));
    $("typeFilter").addEventListener("change", (e) => { filter.type = e.target.value; loadList(); });
    $("openOnly").addEventListener("change", loadList);
    $("cityChips").addEventListener("click", (e) => {
      const chip = e.target.closest(".chip");
      if (!chip) return;
      document.querySelectorAll("#cityChips .chip").forEach((c) => c.classList.toggle("on", c === chip));
      filter.city = chip.dataset.city;
      loadList();
    });
    $("branchGrid").addEventListener("click", async (e) => {
      if (!e.target.closest("[data-delete]")) return;
      const card = e.target.closest(".branch-card");
      const b = allBranches.find((x) => x.id === card.dataset.id);
      const ok = await confirmDialog({ title: "Close " + b.name + "?", message: "The branch will be removed from branches.txt.", confirmText: "Delete branch", danger: true });
      if (!ok) return;
      try {
        await api.del(API + "/" + b.id);
        Session.logAdminAction("Removed branch " + b.id + " (" + b.name + ")");
        card.classList.add("leaving");
        allBranches = allBranches.filter((x) => x.id !== b.id);
        setTimeout(loadList, 400);
        toast(b.name + " removed", "success");
      } catch (err) { toast(err.message, "error"); }
    });
  }

  // ================================================================ register / edit (shared form)
  function setupForm(form, type) {
    const apply = (t) => {
      form.querySelectorAll(".main-only").forEach((el) => { el.classList.toggle("hidden", t !== "MAIN"); el.querySelectorAll("input,select").forEach((i) => { i.disabled = t !== "MAIN"; }); });
      form.querySelectorAll(".sub-only").forEach((el) => { el.classList.toggle("hidden", t !== "SUB"); el.querySelectorAll("input,select").forEach((i) => { i.disabled = t !== "SUB"; }); });
    };
    apply(type);
    form.querySelectorAll('input[name="type"][type="radio"]').forEach((r) => r.addEventListener("change", () => {
      apply(r.value);
      $("vehicleCapacity").value = r.value === "MAIN" ? 60 : 15;
      preview(form);
    }));
    $("allDay").addEventListener("change", (e) => {
      if (e.target.checked) { $("openingTime").value = "00:00"; $("closingTime").value = "00:00"; }
      else { $("openingTime").value = "08:00"; $("closingTime").value = "18:00"; }
      $("openingTime").disabled = $("closingTime").disabled = e.target.checked;
      preview(form);
    });
    form.addEventListener("input", () => preview(form));
  }

  function formValues(form) {
    const d = ui.formData(form);
    d.openingTime = $("openingTime").value;
    d.closingTime = $("closingTime").value;
    return d;
  }

  function preview(form) {
    const d = formValues(form);
    const type = d.type || "MAIN";
    const fake = {
      id: "preview", type, name: d.name || "Branch name", city: d.city || "City", address: d.address || "Street address", phone: d.phone || "-",
      email: d.email || "-", managerName: d.managerName, openingTime: d.openingTime || "08:00", closingTime: d.closingTime || "18:00",
      vehicleCapacity: Number(d.vehicleCapacity) || 1, parentBranchId: d.parentBranchId,
      operatingHours: d.openingTime === d.closingTime ? "Open 24 hours" : (d.openingTime || "08:00") + " - " + (d.closingTime || "18:00"),
      services: type === "MAIN" ? ["Pick-up & drop-off", "Long-term rentals", "Airport delivery"].concat(d.hasServiceCenter ? ["Service & repair workshop"] : []) : ["Pick-up & drop-off", "Short-term rentals"],
      displayInfo: type === "MAIN" ? "Main branch with space for " + (d.vehicleCapacity || 0) + " vehicles." : "Pick-up point for up to " + (d.vehicleCapacity || 0) + " vehicles."
    };
    $("branchPreview").innerHTML = branchCard(fake, 0, false, true);
  }

  async function fillParents(excludeId) {
    const mains = allBranches.filter((b) => b.type === "MAIN" && b.id !== excludeId);
    $("parentBranchId").innerHTML = mains.map((b) => '<option value="' + b.id + '">' + ui.escape(b.name) + " (" + ui.escape(b.city) + ")</option>").join("");
  }

  async function initRegister() {
    if (!Session.requireAdmin()) return;
    allBranches = await api.get(API);
    await fillParents();
    const form = $("branchForm");
    setupForm(form, "MAIN");
    preview(form);
    form.addEventListener("submit", async (e) => {
      e.preventDefault();
      try {
        const b = await ui.busy($("saveBranch"), () => api.post(API, formValues(form)));
        Session.logAdminAction("Added branch " + b.id + " (" + b.name + ")");
        toast(b.name + " added", "success");
        setTimeout(() => { location.href = "/branches/list.html?manage=1#" + b.id; }, 700);
      } catch (err) { toast(err.message, "error"); ui.showFieldError(form, err.message); }
    });
  }

  async function initEdit() {
    if (!Session.requireAdmin()) return;
    const id = ui.param("id");
    allBranches = await api.get(API);
    let b = allBranches.find((x) => x.id === id);
    if (!b) { toast("Branch " + id + " was not found", "error"); return; }
    await fillParents(b.id);
    const form = $("branchForm");
    $("typeHidden").value = b.type;
    $("typeBadge").textContent = (b.type === "MAIN" ? "Main branch " : "Sub branch ") + b.id;
    $("editTitle").textContent = "Edit " + b.name;
    setupForm(form, b.type);
    ui.fillForm(form, b);
    if (hhmm(b.openingTime) === hhmm(b.closingTime)) { $("allDay").checked = true; $("openingTime").disabled = $("closingTime").disabled = true; }
    preview(form);

    form.addEventListener("submit", async (e) => {
      e.preventDefault();
      try {
        b = await ui.busy($("saveBranch"), () => api.put(API + "/" + b.id, formValues(form)));
        Session.logAdminAction("Updated branch " + b.id + " (" + b.name + ")");
        toast("Branch saved", "success");
        preview(form);
      } catch (err) { toast(err.message, "error"); ui.showFieldError(form, err.message); }
    });
    $("deleteBranch").addEventListener("click", async () => {
      const ok = await confirmDialog({ title: "Close " + b.name + "?", message: "The branch will be removed. A main branch with sub branches cannot be removed.", confirmText: "Delete branch", danger: true });
      if (!ok) return;
      try {
        await api.del(API + "/" + b.id);
        Session.logAdminAction("Removed branch " + b.id + " (" + b.name + ")");
        toast("Branch removed", "success");
        setTimeout(() => { location.href = "/branches/list.html?manage=1"; }, 700);
      } catch (err) { toast(err.message, "error"); }
    });
  }

  document.addEventListener("DOMContentLoaded", () => {
    const page = document.body.dataset.page;
    if (page === "list") initList();
    if (page === "register") initRegister();
    if (page === "edit") initEdit();
  });
})();
