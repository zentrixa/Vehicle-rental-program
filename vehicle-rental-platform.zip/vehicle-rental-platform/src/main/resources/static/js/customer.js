/* =====================================================================
   MEMBER 1 - Customer Management (front end)
   Pages: register.html (Create), login.html, profile.html (Read/Update/Delete),
          list.html (admin Read/Update/Delete)
   Talks to CustomerController: /api/customers
   ===================================================================== */

(function () {
  "use strict";

  const $ = (id) => document.getElementById(id);
  const API = "/api/customers";

  // ================================================================ register page
  function initRegister() {
    const form = $("registerForm");
    const tierParam = ui.param("tier");
    if (tierParam) {
      const radio = form.querySelector('input[value="' + tierParam.toUpperCase() + '"]');
      if (radio) radio.checked = true;
    }

    // live preview of the member card while typing
    const card = $("licenceCard");
    function preview() {
      const d = ui.formData(form);
      $("lcName").textContent = d.fullName || "Your name";
      $("lcLicence").textContent = (d.licenceNo || "-").toUpperCase();
      $("lcUser").textContent = d.username || "-";
      $("lcPhone").textContent = d.phone || "-";
      const premium = d.membershipTier === "PREMIUM";
      $("lcTier").textContent = premium ? "Premium" : "Regular";
      $("lcDiscount").textContent = premium ? "10%" : "0%";
      card.classList.toggle("premium", premium);
    }
    form.addEventListener("input", preview);
    form.querySelectorAll('input[name="membershipTier"]').forEach((r) => r.addEventListener("change", () => {
      card.classList.remove("bump"); void card.offsetWidth; card.classList.add("bump");
    }));
    preview();

    // password strength meter
    $("password").addEventListener("input", (e) => {
      const v = e.target.value;
      let score = 0;
      if (v.length >= 6) score++;
      if (v.length >= 10) score++;
      if (/[A-Z]/.test(v) && /[a-z]/.test(v)) score++;
      if (/\d/.test(v)) score++;
      if (/[^A-Za-z0-9]/.test(v)) score++;
      const colours = ["#d9443b", "#d9443b", "#f6b91a", "#f6b91a", "#0f9d7a", "#0f9d7a"];
      const words = ["Too short", "Weak", "Okay", "Good", "Strong", "Very strong"];
      $("strengthBar").style.width = (score / 5) * 100 + "%";
      $("strengthBar").style.background = colours[score];
      $("strengthText").textContent = v ? words[score] : "At least 6 characters";
    });

    form.addEventListener("submit", async (e) => {
      e.preventDefault();
      const data = ui.formData(form);
      if (data.password !== $("confirm").value) {
        toast("The two passwords do not match", "error");
        $("confirm").closest(".field").classList.add("invalid");
        return;
      }
      $("confirm").closest(".field").classList.remove("invalid");
      try {
        const customer = await ui.busy($("registerBtn"), () => api.post(API, data));
        Session.setCustomer(customer);
        toast("Welcome to Vehicle Rental, " + customer.fullName.split(" ")[0] + ". Your account is ready.", "success");
        setTimeout(() => { location.href = "/customers/profile.html"; }, 900);
      } catch (err) {
        toast(err.message, "error");
        ui.showFieldError(form, err.message);
      }
    });
  }

  // ================================================================ login page
  function initLogin() {
    if (Session.isCustomer()) { location.href = "/customers/profile.html"; return; }
    const form = $("loginForm");
    $("pwToggle").addEventListener("click", () => {
      const pw = $("password");
      pw.type = pw.type === "password" ? "text" : "password";
      $("pwToggle").textContent = pw.type === "password" ? "Show" : "Hide";
    });
    form.addEventListener("submit", async (e) => {
      e.preventDefault();
      try {
        const customer = await ui.busy($("loginBtn"), () => api.post(API + "/login", ui.formData(form)));
        Session.setCustomer(customer);
        toast("Signed in as " + customer.fullName, "success");
        const next = ui.param("next");
        setTimeout(() => { location.href = next && next.startsWith("/") ? next : "/customers/profile.html"; }, 500);
      } catch (err) {
        form.classList.remove("shake"); void form.offsetWidth; form.classList.add("shake");
        toast(err.message, "error");
      }
    });
  }

  // ================================================================ profile page
  let me = null;

  function renderMember(c) {
    me = c;
    $("profileTitle").textContent = "Hello, " + c.fullName.split(" ")[0];
    $("profileSub").textContent = (c.membershipTier === "PREMIUM" ? "Premium" : "Regular") + " member with " + c.loyaltyPoints + " loyalty points.";
    $("joined").textContent = "Member since " + ui.date(c.joinedDate);
    $("mcName").textContent = c.fullName;
    $("mcId").textContent = c.id;
    $("mcLicence").textContent = c.licenceNo;
    $("mcTier").textContent = c.membershipTier === "PREMIUM" ? "Premium" : "Regular";
    $("mcDiscount").textContent = Math.round(c.discountRate * 100) + "%";
    ui.countUp($("mcPoints"), c.loyaltyPoints);
    $("memberCard").classList.toggle("premium", c.membershipTier === "PREMIUM");
    $("perkList").innerHTML = c.perks.map((p) => "<li>" + ui.icons.check + "<span>" + ui.escape(p) + "</span></li>").join("");
    const premium = c.membershipTier === "PREMIUM";
    $("tierSwitch").innerHTML = premium
      ? '<button class="btn btn-ghost btn-sm" data-tier="REGULAR">Switch to Regular</button>'
      : '<button class="btn btn-sm" data-tier="PREMIUM">Upgrade to Premium</button>';
    ui.fillForm($("profileForm"), c);
    Session.setCustomer(c);
  }

  async function initProfile() {
    const s = Session.requireCustomer();
    if (!s) return;
    try {
      renderMember(await api.get(API + "/" + s.id));
    } catch (err) {
      toast(err.message, "error");
      if (err.status === 404) { Session.clear(); location.href = "/customers/login.html"; }
      return;
    }

    $("profileForm").addEventListener("submit", async (e) => {
      e.preventDefault();
      const btn = e.target.querySelector("button[type=submit]");
      try {
        renderMember(await ui.busy(btn, () => api.put(API + "/" + me.id, ui.formData(e.target))));
        toast("Profile saved", "success");
      } catch (err) { toast(err.message, "error"); ui.showFieldError(e.target, err.message); }
    });

    $("passwordForm").addEventListener("submit", async (e) => {
      e.preventDefault();
      const btn = e.target.querySelector("button[type=submit]");
      try {
        await ui.busy(btn, () => api.put(API + "/" + me.id, ui.formData(e.target)));
        e.target.reset();
        toast("Password updated", "success");
      } catch (err) { toast(err.message, "error"); }
    });

    $("tierSwitch").addEventListener("click", async (e) => {
      const btn = e.target.closest("[data-tier]");
      if (!btn) return;
      const toPremium = btn.dataset.tier === "PREMIUM";
      const ok = await confirmDialog({
        title: toPremium ? "Upgrade to Premium?" : "Switch to Regular?",
        message: toPremium ? "You will get 10% off every booking, up to 5 active bookings and a free grace day on late returns."
                           : "You will lose the 10% discount and the free grace day.",
        confirmText: toPremium ? "Upgrade" : "Switch"
      });
      if (!ok) return;
      try {
        renderMember(await api.put(API + "/" + me.id, { membershipTier: btn.dataset.tier }));
        const card = $("memberCard");
        card.classList.remove("bump"); void card.offsetWidth; card.classList.add("bump");
        toast(toPremium ? "You are now a Premium member" : "You are now a Regular member", "success");
      } catch (err) { toast(err.message, "error"); }
    });

    $("deleteAccount").addEventListener("click", async () => {
      const ok = await confirmDialog({ title: "Delete your account?", message: "This cannot be undone. You will be signed out.", confirmText: "Delete account", danger: true });
      if (!ok) return;
      try {
        await api.del(API + "/" + me.id);
        Session.clear();
        toast("Your account was deleted", "success");
        setTimeout(() => { location.href = "/"; }, 900);
      } catch (err) { toast(err.message, "error"); }
    });
  }

  // ================================================================ admin list page
  let tierFilter = "";

  async function loadCustomers() {
    const rows = $("customerRows");
    try {
      const list = await api.get(api.url(API, { q: $("customerSearch").value, tier: tierFilter }));
      if (!list.length) {
        rows.innerHTML = '<tr><td colspan="7"><div class="empty" style="border:0">No customers match this search.</div></td></tr>';
        return;
      }
      rows.innerHTML = list.map((c) =>
        '<tr data-id="' + c.id + '">' +
        '<td><div class="cust-cell"><span class="avatar ' + (c.membershipTier === "PREMIUM" ? "premium" : "") + '">' + ui.initials(c.fullName) + "</span>" +
        "<div><strong>" + ui.escape(c.fullName) + '</strong><div class="small muted">' + c.id + " &middot; @" + ui.escape(c.username) + "</div></div></div></td>" +
        "<td>" + ui.escape(c.email) + '<div class="small muted">' + ui.escape(c.phone) + "</div></td>" +
        "<td>" + ui.escape(c.licenceNo) + "</td>" +
        "<td>" + (c.membershipTier === "PREMIUM" ? '<span class="badge badge-dark">Premium</span>' : '<span class="badge">Regular</span>') + "</td>" +
        "<td>" + c.loyaltyPoints + "</td>" +
        "<td>" + ui.date(c.joinedDate) + "</td>" +
        '<td><div class="actions"><button class="btn btn-ghost btn-sm" data-edit>Edit</button>' +
        '<button class="btn btn-ghost btn-sm" data-delete style="color:var(--stop)">Delete</button></div></td></tr>'
      ).join("");
      rows.querySelectorAll("tr").forEach((tr) => { tr.__data = list.find((c) => c.id === tr.dataset.id); });
    } catch (err) {
      rows.innerHTML = '<tr><td colspan="7">' + ui.escape(err.message) + "</td></tr>";
    }
  }

  async function loadCustomerStats() {
    const all = await api.get(API);
    ui.countUp($("cTotal"), all.length);
    ui.countUp($("cPremium"), all.filter((c) => c.membershipTier === "PREMIUM").length);
    ui.countUp($("cRegular"), all.filter((c) => c.membershipTier === "REGULAR").length);
    ui.countUp($("cPoints"), all.reduce((s, c) => s + c.loyaltyPoints, 0));
  }

  function editCustomer(c) {
    const m = openModal(
      "<h3>Edit " + ui.escape(c.fullName) + '</h3><p class="small muted">' + c.id + "</p>" +
      '<form id="editCustomerForm" class="form-grid" novalidate>' +
      '<div class="field full"><label>Full name</label><input name="fullName"></div>' +
      '<div class="field"><label>Email</label><input name="email"></div>' +
      '<div class="field"><label>Phone</label><input name="phone"></div>' +
      '<div class="field"><label>Licence</label><input name="licenceNo"></div>' +
      '<div class="field"><label>Membership tier</label><select name="membershipTier"><option value="REGULAR">Regular</option><option value="PREMIUM">Premium</option></select></div>' +
      '<div class="form-actions full"><button type="button" class="btn btn-ghost" data-close>Cancel</button><button class="btn btn-dark" type="submit">Save</button></div></form>'
    );
    const form = m.el.querySelector("form");
    ui.fillForm(form, c);
    form.addEventListener("submit", async (e) => {
      e.preventDefault();
      try {
        await api.put(API + "/" + c.id, ui.formData(form));
        Session.logAdminAction("Updated customer " + c.id + " (" + c.fullName + ")");
        m.close();
        toast("Customer updated", "success");
        await loadCustomers();
        const row = document.querySelector('tr[data-id="' + c.id + '"]');
        if (row) row.classList.add("arriving");
        loadCustomerStats();
      } catch (err) { toast(err.message, "error"); ui.showFieldError(form, err.message); }
    });
  }

  function initList() {
    if (!Session.requireAdmin()) return;
    loadCustomers();
    loadCustomerStats();
    $("customerSearch").addEventListener("input", ui.debounce(loadCustomers, 250));
    $("tierChips").addEventListener("click", (e) => {
      const chip = e.target.closest(".chip");
      if (!chip) return;
      document.querySelectorAll("#tierChips .chip").forEach((c) => c.classList.toggle("on", c === chip));
      tierFilter = chip.dataset.tier;
      loadCustomers();
    });
    $("customerRows").addEventListener("click", async (e) => {
      const tr = e.target.closest("tr");
      if (!tr || !tr.__data) return;
      const c = tr.__data;
      if (e.target.closest("[data-edit]")) editCustomer(c);
      if (e.target.closest("[data-delete]")) {
        const ok = await confirmDialog({ title: "Delete " + c.fullName + "?", message: "The account " + c.id + " will be removed from customers.txt.", confirmText: "Delete", danger: true });
        if (!ok) return;
        try {
          await api.del(API + "/" + c.id);
          Session.logAdminAction("Deleted customer " + c.id + " (" + c.fullName + ")");
          tr.classList.add("leaving");
          setTimeout(() => { loadCustomers(); loadCustomerStats(); }, 400);
          toast("Customer deleted", "success");
        } catch (err) { toast(err.message, "error"); }
      }
    });
  }

  // ================================================================ start
  document.addEventListener("DOMContentLoaded", () => {
    const page = document.body.dataset.page;
    if (page === "register") initRegister();
    if (page === "login") initLogin();
    if (page === "profile") initProfile();
    if (page === "list") initList();
  });
})();
