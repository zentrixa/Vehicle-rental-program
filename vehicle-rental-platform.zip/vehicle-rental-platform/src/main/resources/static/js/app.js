/* =====================================================================
   Vehicle Rental - shared front-end library (kickoff file, owned by the whole team)

   Every page loads this file first. It provides:
     api        - small wrapper around fetch() for the REST endpoints
     Session    - who is signed in (customer or admin), kept in localStorage
     toast()    - pop-up messages
     confirmDialog() - "Are you sure?" dialog that returns a Promise
     ui         - helpers: money, dates, stars, licence plates, vehicle drawings, count-up ...
   It also draws the shared header, admin bar and footer on every page.
   ===================================================================== */

(function () {
  "use strict";

  // ------------------------------------------------------------------ API helper
  async function request(method, url, body) {
    const options = { method, headers: {} };
    if (body !== undefined) {
      options.headers["Content-Type"] = "application/json";
      options.body = JSON.stringify(body);
    }
    let response;
    try {
      response = await fetch(url, options);
    } catch (e) {
      throw new Error("Cannot reach the server. Check that the application is running.");
    }
    const text = await response.text();
    let data = null;
    try { data = text ? JSON.parse(text) : null; } catch (e) { data = text; }
    if (!response.ok) {
      const message = data && data.error ? data.error : "Request failed (" + response.status + ")";
      const err = new Error(message);
      err.status = response.status;
      throw err;
    }
    return data;
  }

  const api = {
    get: (url) => request("GET", url),
    post: (url, body) => request("POST", url, body || {}),
    put: (url, body) => request("PUT", url, body || {}),
    patch: (url, body) => request("PATCH", url, body || {}),
    del: (url) => request("DELETE", url),
    /** Builds "/api/x?a=1&b=2" while skipping empty values. */
    url(path, params) {
      const qs = new URLSearchParams();
      Object.entries(params || {}).forEach(([k, v]) => { if (v !== undefined && v !== null && v !== "") qs.append(k, v); });
      const s = qs.toString();
      return s ? path + "?" + s : path;
    }
  };

  // ------------------------------------------------------------------ Session (localStorage)
  const KEY = "vehiclerental.session";
  const Session = {
    get() {
      try { return JSON.parse(localStorage.getItem(KEY)) || null; } catch (e) { return null; }
    },
    set(value) {
      try { localStorage.setItem(KEY, JSON.stringify(value)); } catch (e) { /* storage blocked */ }
    },
    setCustomer(c) {
      this.set({ kind: "customer", id: c.id, name: c.fullName, username: c.username, tier: c.membershipTier });
    },
    setAdmin(a) {
      this.set({ kind: "admin", id: a.id, name: a.fullName, username: a.username, role: a.role, roleLabel: a.roleLabel, permissions: a.permissions });
    },
    clear() {
      try { localStorage.removeItem(KEY); } catch (e) { /* ignore */ }
    },
    isCustomer() { const s = this.get(); return !!s && s.kind === "customer"; },
    isAdmin() { const s = this.get(); return !!s && s.kind === "admin"; },
    can(permission) { const s = this.get(); return !!s && s.kind === "admin" && (s.permissions || []).includes(permission); },
    /** Sends the visitor to the customer sign-in page and comes back afterwards. */
    requireCustomer() {
      if (this.isCustomer()) return this.get();
      location.href = "/customers/login.html?next=" + encodeURIComponent(location.pathname + location.search);
      return null;
    },
    requireAdmin() {
      if (this.isAdmin()) return this.get();
      location.href = "/admin/login.html?next=" + encodeURIComponent(location.pathname + location.search);
      return null;
    },
    /** Records an admin action in the activity log (Member 4). Failures are ignored. */
    logAdminAction(action) {
      const s = this.get();
      if (!s || s.kind !== "admin") return;
      api.post("/api/admins/" + s.id + "/logs", { action }).catch(() => {});
    }
  };

  // ------------------------------------------------------------------ toast + dialogs
  function toast(message, type) {
    let box = document.querySelector(".toasts");
    if (!box) {
      box = document.createElement("div");
      box.className = "toasts";
      box.setAttribute("role", "status");
      box.setAttribute("aria-live", "polite");
      document.body.appendChild(box);
    }
    const el = document.createElement("div");
    el.className = "toast " + (type || "");
    el.innerHTML = '<div style="flex:1">' + escapeHtml(message) + "</div>";
    box.appendChild(el);
    setTimeout(() => { el.classList.add("out"); setTimeout(() => el.remove(), 320); }, type === "error" ? 5200 : 3400);
  }

  function confirmDialog(opts) {
    const o = Object.assign({ title: "Are you sure?", message: "", confirmText: "Confirm", cancelText: "Cancel", danger: false }, opts);
    return new Promise((resolve) => {
      const back = document.createElement("div");
      back.className = "modal-backdrop";
      back.innerHTML =
        '<div class="modal" role="dialog" aria-modal="true">' +
        "<h3>" + escapeHtml(o.title) + "</h3>" +
        '<p class="muted">' + escapeHtml(o.message) + "</p>" +
        '<div class="form-actions">' +
        '<button class="btn btn-ghost" data-act="no">' + escapeHtml(o.cancelText) + "</button>" +
        '<button class="btn ' + (o.danger ? "btn-danger" : "btn-dark") + '" data-act="yes">' + escapeHtml(o.confirmText) + "</button>" +
        "</div></div>";
      document.body.appendChild(back);
      const close = (v) => { back.remove(); document.removeEventListener("keydown", onKey); resolve(v); };
      const onKey = (e) => { if (e.key === "Escape") close(false); };
      document.addEventListener("keydown", onKey);
      back.addEventListener("click", (e) => {
        if (e.target === back) close(false);
        const act = e.target.closest("[data-act]");
        if (act) close(act.dataset.act === "yes");
      });
      back.querySelector('[data-act="yes"]').focus();
    });
  }

  /** Opens a modal with custom HTML. Returns { el, close }. */
  function openModal(html, wide) {
    const back = document.createElement("div");
    back.className = "modal-backdrop";
    back.innerHTML = '<div class="modal' + (wide ? " wide" : "") + '" role="dialog" aria-modal="true">' + html + "</div>";
    document.body.appendChild(back);
    const close = () => { back.remove(); document.removeEventListener("keydown", onKey); };
    const onKey = (e) => { if (e.key === "Escape") close(); };
    document.addEventListener("keydown", onKey);
    back.addEventListener("click", (e) => { if (e.target === back || e.target.closest("[data-close]")) close(); });
    return { el: back.querySelector(".modal"), close };
  }

  // ------------------------------------------------------------------ ui helpers
  function escapeHtml(value) {
    return String(value === undefined || value === null ? "" : value)
      .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#39;");
  }

  const icons = {
    search: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>',
    star: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2.8l2.8 5.9 6.4.8-4.7 4.4 1.2 6.4L12 17.2 6.3 20.3l1.2-6.4L2.8 9.5l6.4-.8z"/></svg>',
    edit: '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 20h4L19 9l-4-4L4 16z"/><path d="m14 6 4 4"/></svg>',
    trash: '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/></svg>',
    pin: '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 21s-7-6.2-7-11.5A7 7 0 0 1 19 9.5C19 14.8 12 21 12 21z"/><circle cx="12" cy="9.5" r="2.5"/></svg>',
    clock: '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>',
    phone: '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2"/></svg>',
    check: '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="m5 12 5 5L20 7"/></svg>',
    eye: '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/></svg>',
    flag: '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 21V4h11l-1.5 4L16 12H5"/></svg>',
    plus: '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg>'
  };

  const colourMap = {
    white: "#f4f5f7", "pearl white": "#f6f3ea", silver: "#c4cad3", grey: "#8b94a3", gray: "#8b94a3", graphite: "#4a5160",
    "sleet grey": "#9aa3ad", black: "#2a2f38", "matte black": "#30343c", red: "#d6453b", "racing red": "#d22f2f",
    blue: "#2f63c7", "midnight blue": "#22346b", "sky blue": "#6fb2e8", cyan: "#21a6c2", green: "#2f9a62", yellow: "#f2c230",
    orange: "#ee8a2a", brown: "#7a5236", maroon: "#7d2430"
  };
  function colourHex(name) {
    const key = String(name || "").toLowerCase().trim();
    if (colourMap[key]) return colourMap[key];
    const found = Object.keys(colourMap).find((k) => key.includes(k));
    return found ? colourMap[found] : "#c4cad3";
  }

  /** Simple original side-view drawings for each vehicle type (SVG). */
  function vehicleArt(type, colour) {
    const c = colourHex(colour);
    const glass = "#9fb4c8";
    const tyre = '<circle r="14" fill="#1d232d"/><circle r="6.5" fill="#c8ced8"/><circle r="2" fill="#1d232d"/>';
    const t = String(type || "").toUpperCase();
    if (t === "VAN") {
      return '<svg viewBox="0 0 200 92" aria-hidden="true">' +
        '<ellipse cx="100" cy="86" rx="88" ry="4" fill="rgba(20,27,38,.18)"/>' +
        '<path d="M12 68V26q0-11 12-11h120q12 0 20 11l20 22q8 4 8 13v7q0 4-4 4H16q-4 0-4-4z" fill="' + c + '" stroke="rgba(20,27,38,.35)" stroke-width="1.2"/>' +
        '<path d="M140 22h6q7 0 12 7l15 19h-33z" fill="' + glass + '"/>' +
        '<rect x="24" y="22" width="30" height="20" rx="3" fill="' + glass + '"/><rect x="60" y="22" width="30" height="20" rx="3" fill="' + glass + '"/><rect x="96" y="22" width="36" height="20" rx="3" fill="' + glass + '"/>' +
        '<path d="M12 54h180" stroke="rgba(20,27,38,.18)" stroke-width="2"/><rect x="180" y="52" width="10" height="5" rx="2" fill="#f6b91a"/>' +
        '<g transform="translate(48 72)">' + tyre + '</g><g transform="translate(158 72)">' + tyre + "</g></svg>";
    }
    if (t === "MOTORCYCLE") {
      return '<svg viewBox="0 0 200 92" aria-hidden="true">' +
        '<ellipse cx="100" cy="88" rx="80" ry="3.5" fill="rgba(20,27,38,.18)"/>' +
        '<g fill="none" stroke="#1d232d" stroke-width="7"><circle cx="48" cy="66" r="19"/><circle cx="154" cy="66" r="19"/></g>' +
        '<g fill="#c8ced8"><circle cx="48" cy="66" r="6"/><circle cx="154" cy="66" r="6"/></g>' +
        '<path d="M48 66l30-26h40l36 26" fill="none" stroke="#3a4250" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/>' +
        '<path d="M140 34l14 32" stroke="#3a4250" stroke-width="5" stroke-linecap="round"/>' +
        '<path d="M84 40q4-14 22-14h16q10 0 14 8l-6 8H90z" fill="' + c + '" stroke="rgba(20,27,38,.35)" stroke-width="1.2"/>' +
        '<path d="M56 38q14-6 30 0l-4 6H58z" fill="#2a2f38"/>' +
        '<path d="M134 26l10-6h10" stroke="#2a2f38" stroke-width="4" stroke-linecap="round" fill="none"/>' +
        '<circle cx="152" cy="34" r="4" fill="#f6b91a"/><path d="M90 50h26l-6 10H96z" fill="#5b6472"/></svg>';
    }
    return '<svg viewBox="0 0 200 92" aria-hidden="true">' +
      '<ellipse cx="100" cy="86" rx="90" ry="4" fill="rgba(20,27,38,.18)"/>' +
      '<path d="M10 64q0-12 14-15l34-6q14-19 38-20h32q18 1 32 18l22 6q10 3 10 13v6q0 4-4 4H14q-4 0-4-4z" fill="' + c + '" stroke="rgba(20,27,38,.35)" stroke-width="1.2"/>' +
      '<path d="M66 44q12-15 30-15h16v15z" fill="' + glass + '"/><path d="M118 29h10q14 1 24 15h-34z" fill="' + glass + '"/>' +
      '<path d="M22 56h170" stroke="rgba(20,27,38,.14)" stroke-width="2"/><rect x="182" y="52" width="10" height="5" rx="2" fill="#f6b91a"/><rect x="10" y="54" width="7" height="5" rx="2" fill="#d9443b"/>' +
      '<g transform="translate(50 72)">' + tyre + '</g><g transform="translate(154 72)">' + tyre + "</g></svg>";
  }

  /** Photo of the vehicle when it has one (v.imageUrl), otherwise the SVG drawing. */
  function vehicleMedia(v) {
    if (v && v.imageUrl) {
      return '<img class="media-img" src="' + escapeHtml(v.imageUrl) + '" alt="' + escapeHtml((v.brand || "") + " " + (v.model || "")) +
        '" loading="lazy" onerror="this.replaceWith(document.createRange().createContextualFragment(ui.vehicleArt(\'' + escapeHtml(v.type) + '\', \'' + escapeHtml(v.colour) + '\')))">';
    }
    return vehicleArt(v ? v.type : "CAR", v ? v.colour : "");
  }

  const ui = {
    vehicleMedia,
    icons,
    escape: escapeHtml,
    vehicleArt,
    colourHex,
    money(value) {
      const n = Number(value || 0);
      return "Rs. " + n.toLocaleString("en-LK", { minimumFractionDigits: 0, maximumFractionDigits: 2 });
    },
    date(value) {
      if (!value) return "-";
      const d = new Date(value + (String(value).length === 10 ? "T00:00:00" : ""));
      if (isNaN(d)) return value;
      return d.toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" });
    },
    today() {
      const d = new Date();
      d.setMinutes(d.getMinutes() - d.getTimezoneOffset());
      return d.toISOString().slice(0, 10);
    },
    addDays(iso, days) {
      const d = new Date(iso + "T00:00:00");
      d.setDate(d.getDate() + days);
      d.setMinutes(d.getMinutes() - d.getTimezoneOffset());
      return d.toISOString().slice(0, 10);
    },
    timeAgo(iso) {
      const then = new Date(iso);
      const secs = Math.round((Date.now() - then.getTime()) / 1000);
      if (isNaN(secs)) return iso;
      if (secs < 60) return "just now";
      if (secs < 3600) return Math.floor(secs / 60) + " min ago";
      if (secs < 86400) return Math.floor(secs / 3600) + " h ago";
      if (secs < 86400 * 7) return Math.floor(secs / 86400) + " d ago";
      return then.toLocaleDateString("en-GB", { day: "numeric", month: "short" });
    },
    initials(name) {
      return String(name || "?").split(/\s+/).filter(Boolean).slice(0, 2).map((p) => p[0].toUpperCase()).join("");
    },
    plate(text) {
      return '<span class="plate"><span>' + escapeHtml(text) + "</span></span>";
    },
    stars(rating) {
      let html = '<span class="stars" aria-label="' + rating + ' out of 5 stars">';
      for (let i = 1; i <= 5; i++) html += '<span class="' + (i <= Math.round(rating) ? "" : "off") + '">' + icons.star + "</span>";
      return html + "</span>";
    },
    vehicleStatusBadge(status) {
      const map = { AVAILABLE: ["badge-go", "Available"], RENTED: ["badge-amber", "On rent"], MAINTENANCE: ["badge-stop", "In maintenance"] };
      const m = map[status] || ["", status];
      return '<span class="badge ' + m[0] + '">' + m[1] + "</span>";
    },
    typeLabel(type) {
      return { CAR: "Car", VAN: "Van", MOTORCYCLE: "Motorcycle" }[type] || type;
    },
    /** Animated number from 0 (or current) to value. */
    countUp(el, value, opts) {
      const o = Object.assign({ duration: 1100, decimals: 0, prefix: "", suffix: "" }, opts);
      const start = Number(el.dataset.current || 0);
      const end = Number(value || 0);
      const t0 = performance.now();
      const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
      function frame(now) {
        const p = reduce ? 1 : Math.min(1, (now - t0) / o.duration);
        const eased = 1 - Math.pow(1 - p, 3);
        const v = start + (end - start) * eased;
        el.textContent = o.prefix + v.toLocaleString("en-LK", { minimumFractionDigits: o.decimals, maximumFractionDigits: o.decimals }) + o.suffix;
        if (p < 1) requestAnimationFrame(frame);
        else el.dataset.current = end;
      }
      requestAnimationFrame(frame);
    },
    debounce(fn, ms) {
      let t;
      return function () { const args = arguments; clearTimeout(t); t = setTimeout(() => fn.apply(this, args), ms || 250); };
    },
    param(name) {
      return new URLSearchParams(location.search).get(name);
    },
    /** Reads all named inputs of a form into a plain object. Checkboxes become true/false. */
    formData(form) {
      const data = {};
      form.querySelectorAll("input[name], select[name], textarea[name]").forEach((el) => {
        if (el.disabled) return;                      // hidden/disabled sections are not sent
        if (el.type === "radio") { if (el.checked) data[el.name] = el.value; return; }
        if (el.type === "checkbox") { data[el.name] = el.checked; return; }
        data[el.name] = el.value.trim();
      });
      return data;
    },
    fillForm(form, obj) {
      Object.entries(obj || {}).forEach(([k, v]) => {
        const els = form.querySelectorAll('[name="' + k + '"]');
        els.forEach((el) => {
          if (el.type === "checkbox") el.checked = !!v;
          else if (el.type === "radio") el.checked = String(el.value) === String(v);
          else if (v !== null && v !== undefined) el.value = typeof v === "string" && /^\d\d:\d\d:\d\d$/.test(v) ? v.slice(0, 5) : v;
        });
      });
    },
    /** Shows a spinner in a button while a promise runs. */
    async busy(button, work) {
      const original = button.innerHTML;
      button.disabled = true;
      button.innerHTML = '<span class="spinner"></span> Working';
      try { return await work(); } finally { button.disabled = false; button.innerHTML = original; }
    },
    /** Highlights a field that the server says is wrong (matches by words in the message). */
    showFieldError(form, message) {
      form.querySelectorAll(".field.invalid").forEach((f) => f.classList.remove("invalid"));
      const lower = String(message).toLowerCase();
      let matched = null;
      form.querySelectorAll(".field").forEach((f) => {
        const label = f.querySelector("label");
        if (!matched && label && lower.startsWith(label.textContent.toLowerCase().replace(/\s*\(.*\)/, "").trim().split(" ")[0])) matched = f;
      });
      if (matched) {
        matched.classList.add("invalid");
        const input = matched.querySelector("input,select,textarea");
        if (input) input.focus();
      }
    },
    /** Fade-in for elements with .reveal when they scroll into view. */
    reveal(root) {
      const els = (root || document).querySelectorAll(".reveal:not(.in)");
      if (!("IntersectionObserver" in window)) { els.forEach((e) => e.classList.add("in")); return; }
      const io = new IntersectionObserver((entries) => {
        entries.forEach((en) => { if (en.isIntersecting) { en.target.classList.add("in"); io.unobserve(en.target); } });
      }, { threshold: 0.12 });
      els.forEach((e) => io.observe(e));
    },
    /** Calls fn now and every ms milliseconds while the tab is visible. */
    poll(fn, ms) {
      fn();
      return setInterval(() => { if (!document.hidden) fn(); }, ms);
    }
  };

  // ------------------------------------------------------------------ shared header / footer
  const BRAND_ICON = '<svg class="brand-icon" viewBox="0 0 64 46" aria-hidden="true"><path fill="currentColor" fill-rule="evenodd" d="M14 8Q16 3 22 3H42Q48 3 50 8L55 20Q60 21 60 27V40Q60 43 57 43H53Q50 43 50 40V38H14V40Q14 43 11 43H7Q4 43 4 40V27Q4 21 9 20ZM15 19H49L45 9Q44 7 41 7H23Q20 7 19 9ZM13 24.5A3.5 3.5 0 1 0 13 31.5A3.5 3.5 0 1 0 13 24.5ZM51 24.5A3.5 3.5 0 1 0 51 31.5A3.5 3.5 0 1 0 51 24.5ZM24 29H40V33H24Z"/></svg>';
  const brandHtml = '<a class="brand" href="/">' + BRAND_ICON + '<span class="brand-text"><strong>VEHICLE RENTAL</strong><small>Drive Your Freedom</small></span></a>';

  function renderHeader() {
    const host = document.getElementById("site-header");
    if (!host) return;
    const s = Session.get();
    const section = document.body.dataset.nav || "";
    const link = (href, label, key) => '<a href="' + href + '" class="' + (section === key ? "active" : "") + '">' + label + "</a>";

    let account;
    if (s && s.kind === "customer") {
      account =
        '<div class="account"><button class="account-btn" aria-haspopup="true"><span class="avatar">' + ui.initials(s.name) + "</span>" +
        "<span>" + escapeHtml(s.name.split(" ")[0]) + "</span></button>" +
        '<div class="account-menu"><div class="who"><strong>' + escapeHtml(s.name) + '</strong><div class="small muted">' +
        (s.tier === "PREMIUM" ? "Premium member" : "Regular member") + "</div></div>" +
        '<a href="/bookings/book.html">Book a vehicle</a><a href="/customers/profile.html">My profile</a><a href="/bookings/list.html">My bookings</a>' +
        '<a href="/reviews/submit.html">Write a review</a><button data-signout>Sign out</button></div></div>';
    } else if (s && s.kind === "admin") {
      account =
        '<div class="account"><button class="account-btn" aria-haspopup="true"><span class="avatar">' + ui.initials(s.name) + "</span>" +
        "<span>" + escapeHtml(s.name.split(" ")[0]) + "</span></button>" +
        '<div class="account-menu"><div class="who"><strong>' + escapeHtml(s.name) + '</strong><div class="small muted">' +
        escapeHtml(s.roleLabel || "Staff") + "</div></div>" +
        '<a href="/admin/dashboard.html">Dashboard</a><a href="/admin/register.html?id=' + s.id + '">My staff profile</a>' +
        "<button data-signout>Sign out</button></div></div>";
    } else {
      account = '<a href="/customers/login.html" class="' + (section === "login" ? "active" : "") + '">Sign in</a>' +
        '<a href="/customers/register.html" class="btn btn-sm">Register</a>';
    }

    host.className = "site-header";
    host.innerHTML =
      '<div class="wrap bar">' + brandHtml +
      '<button class="menu-toggle" aria-label="Open menu">&#9776;</button>' +
      '<nav class="nav">' +
      link("/", "Home", "home") +
      link("/vehicles/cars.html", "Cars", "cars") +
      link("/vehicles/vans.html", "Vans", "vans") +
      link("/vehicles/motorcycles.html", "Motorcycles", "motorcycles") +
      link("/branches/list.html", "Branches", "branches") +
      link("/reviews/view.html", "Reviews", "reviews") +
      link("/contact.html", "Contact", "contact") +
      (s && s.kind === "admin" ? link("/admin/dashboard.html", "Dashboard", "admin") : "") +
      '<span class="nav-sep" aria-hidden="true"></span>' +
      account +
      "</nav></div>" +
      (s && s.kind === "admin" && document.body.dataset.area === "admin" ? adminBar() : "");

    host.querySelector(".menu-toggle").addEventListener("click", () => host.querySelector(".nav").classList.toggle("open"));
    const acc = host.querySelector(".account");
    if (acc) {
      acc.querySelector(".account-btn").addEventListener("click", (e) => { e.stopPropagation(); acc.classList.toggle("open"); });
      document.addEventListener("click", () => acc.classList.remove("open"));
    }
    const out = host.querySelector("[data-signout]");
    if (out) out.addEventListener("click", () => {
      const wasAdmin = Session.isAdmin();
      if (wasAdmin) Session.logAdminAction("Signed out");
      Session.clear();
      location.href = wasAdmin ? "/admin/login.html" : "/";
    });

    // transparent over the photo at the top, solid after scrolling
    const onScroll = () => host.classList.toggle("solid", window.scrollY > 30);
    window.addEventListener("scroll", onScroll, { passive: true });
    onScroll();
    // page bands leave room for the fixed header (it is taller when the admin bar shows)
    const setHeight = () => document.documentElement.style.setProperty("--header-h", host.offsetHeight + "px");
    setHeight();
    window.addEventListener("resize", setHeight);
  }

  function adminBar() {
    const page = document.body.dataset.admin || "";
    const items = [
      ["dashboard", "/admin/dashboard.html", "Overview"],
      ["vehicles", "/vehicles/list.html", "Vehicles"],
      ["bookings", "/bookings/list.html", "Bookings"],
      ["returns", "/bookings/return.html", "Returns"],
      ["customers", "/customers/list.html", "Customers"],
      ["branches", "/branches/list.html?manage=1", "Branches"],
      ["reviews", "/reviews/moderate.html", "Review moderation"],
      ["staff", "/admin/staff.html", "Staff"]
    ];
    return '<div class="admin-bar"><div class="wrap">' +
      items.map((i) => '<a href="' + i[1] + '" class="' + (page === i[0] ? "active" : "") + '">' + i[2] + "</a>").join("") +
      "</div></div>";
  }

  function renderFooter() {
    const host = document.getElementById("site-footer");
    if (!host) return;
    host.className = "site-footer";
    host.innerHTML =
      '<div class="footer-hero">' +
      // layered mountain silhouettes (recreated from the design board)
      '<svg class="footer-mountains" viewBox="0 0 1440 220" preserveAspectRatio="none" aria-hidden="true">' +
      '<path d="M0 150 L120 70 L210 120 L330 40 L470 130 L560 80 L700 150 L820 60 L960 140 L1080 70 L1210 130 L1330 50 L1440 110 V220 H0Z" fill="currentColor" opacity=".04"/>' +
      '<path d="M0 190 L160 120 L280 170 L420 100 L560 175 L700 120 L860 185 L1000 115 L1150 180 L1300 120 L1440 170 V220 H0Z" fill="currentColor" opacity=".05"/></svg>' +
      // the green curvy road
      '<svg class="footer-road" viewBox="0 0 520 200" preserveAspectRatio="none" aria-hidden="true">' +
      '<path d="M520 30 C420 40 330 60 300 100 C270 140 360 150 330 175 C310 195 260 200 230 205" fill="none" stroke="#34c77b" stroke-width="16" stroke-linecap="round" opacity=".55"/>' +
      '<path d="M520 30 C420 40 330 60 300 100 C270 140 360 150 330 175 C310 195 260 200 230 205" fill="none" stroke="#0d1f20" stroke-width="2" stroke-dasharray="10 12" opacity=".7"/></svg>' +
      '<div class="wrap">' + brandHtml.replace('<a class="brand"', '<a class="brand footer-brand"') +
      '<span class="footer-divider" aria-hidden="true"></span><p class="footer-tagline">Better Rides.<br>Brighter Journeys.</p></div></div>' +
      '<div class="wrap"><div class="footer-cols">' +
      "<div><h4>About us</h4><p>Cars, vans and motorcycles for rent across Sri Lanka. Book online, collect at a branch and drive.</p></div>" +
      '<div><h4>Rent</h4><a href="/vehicles/cars.html">Cars</a><a href="/vehicles/vans.html">Vans</a><a href="/vehicles/motorcycles.html">Motorcycles</a><a href="/vehicles/search.html">Search the whole fleet</a><a href="/bookings/book.html">Book a vehicle</a></div>' +
      '<div><h4>Your account</h4><a href="/customers/register.html">Register</a><a href="/customers/login.html">Sign in</a><a href="/bookings/list.html">My bookings</a><a href="/reviews/submit.html">Write a review</a></div>' +
      '<div><h4>Help</h4><a href="/contact.html">Contact us</a><a href="/branches/list.html">Find a branch</a><a href="/admin/login.html">Staff sign in</a></div>' +
      "</div>" +
      '<div class="legal"><span>WD25</span><span>Vehicle Rental is a fictional company built for coursework.</span></div></div>';
  }

  // expose globals
  window.api = api;
  window.Session = Session;
  window.toast = toast;
  window.confirmDialog = confirmDialog;
  window.openModal = openModal;
  window.ui = ui;

  document.addEventListener("DOMContentLoaded", () => {
    renderHeader();
    renderFooter();
    ui.reveal();
  });
})();
