/* =====================================================================
   MEMBER 6 - Feedback and Review Management (front end)
   Pages: submit.html (Create + edit/delete own), view.html (Read - customer display),
          moderate.html (admin display, Update status, Delete)
   Talks to ReviewController: /api/reviews
   ===================================================================== */

(function () {
  "use strict";

  const $ = (id) => document.getElementById(id);
  const API = "/api/reviews";
  const WORDS = ["", "Poor", "Below average", "Okay", "Good", "Excellent"];

  function reviewCard(r, i) {
    const statusNote = r.status && r.status !== "VISIBLE"
      ? '<div class="notice warn" style="margin-top:10px">Only you can see this review. It is ' + (r.status === "FLAGGED" ? "waiting for a moderator" : "hidden by a moderator") + ".</div>" : "";
    return '<article class="review-card ' + (r.type === "VERIFIED" ? "verified" : "") + '" style="animation-delay:' + Math.min(i, 10) * 50 + 'ms">' +
      '<div class="rc-head"><div>' + ui.stars(r.rating) + "<h4>" + ui.escape(r.title) + "</h4></div>" +
      (r.type === "VERIFIED" ? '<span class="badge badge-go">' + ui.escape(r.badge) + "</span>" : '<span class="badge">' + ui.escape(r.badge) + "</span>") + "</div>" +
      "<p>" + ui.escape(r.comment) + "</p>" + statusNote +
      '<div class="rc-meta"><strong>' + ui.escape(r.author) + "</strong><span>on " + ui.escape(r.vehicleName) + "</span><span>&middot; " + ui.date(r.date) + "</span>" +
      (r.edited ? "<span>&middot; edited</span>" : "") + (r.verifiedNote ? "<span>&middot; " + ui.escape(r.verifiedNote) + "</span>" : "") + "</div></article>";
  }

  // ================================================================ submit page
  let me = null;
  let vehicles = [];
  let returnedVehicles = {};
  let myReviews = [];
  let editing = null;
  let rating = 0;

  function setRating(v, animate) {
    rating = v;
    $("rating").value = v || "";
    document.querySelectorAll("#starInput button").forEach((b) => {
      const n = Number(b.dataset.v);
      b.classList.toggle("lit", n <= v);
      b.setAttribute("aria-checked", n === v ? "true" : "false");
      if (animate && n <= v) { b.classList.remove("pop"); void b.offsetWidth; setTimeout(() => b.classList.add("pop"), n * 40); }
    });
    $("starWord").textContent = v ? WORDS[v] : "Tap a star";
    preview();
  }

  function preview() {
    const v = vehicles.find((x) => x.id === $("vehicleId").value);
    const verified = v && returnedVehicles[v.id];
    $("reviewPreview").innerHTML =
      (v ? '<div class="art' + (v.imageUrl ? " photo" : "") + '">' + ui.vehicleMedia(v) + "</div>" : "") +
      '<div class="rc-head"><div>' + ui.stars(rating) + "<h4>" + ui.escape($("title").value || "Your headline") + "</h4></div>" +
      (verified ? '<span class="badge badge-go">Verified rental</span>' : '<span class="badge">Customer review</span>') + "</div>" +
      '<p class="small" style="margin-top:8px;color:var(--ink-2)">' + ui.escape($("comment").value || "Your review will appear here.") + "</p>" +
      '<div class="rc-meta"><strong>' + ui.escape(me ? me.name.split(" ")[0] + " " + (me.name.split(" ").slice(-1)[0] || "").charAt(0) + "." : "") + "</strong><span>on " +
      ui.escape(v ? v.displayName : "-") + "</span></div>";
    $("verifyNote").innerHTML = !v ? "" : verified
      ? '<div class="notice good">You returned this vehicle (booking ' + verified + '). Your review will show as a <strong>Verified rental</strong> and counts 1.5 times in the weighted rating.</div>'
      : '<div class="notice">You have not completed a rental of this vehicle yet, so this will be a public customer review.</div>';
  }

  function renderMine() {
    $("myCount").textContent = myReviews.length + (myReviews.length === 1 ? " review" : " reviews");
    $("myReviews").innerHTML = myReviews.length ? myReviews.map((r) =>
      '<div class="my-review">' + ui.stars(r.rating) + "<div><strong>" + ui.escape(r.title) + '</strong><div class="small muted">' + ui.escape(r.vehicleName) + " &middot; " + ui.date(r.date) +
      (r.status && r.status !== "VISIBLE" ? ' &middot; <span class="badge badge-amber">' + (r.status === "FLAGGED" ? "Waiting for moderator" : "Hidden") + "</span>" : "") + "</div></div>" +
      '<a class="btn btn-ghost btn-sm" href="/reviews/submit.html?edit=' + r.id + '">Edit</a></div>').join("")
      : '<p class="muted">You have not written any reviews yet.</p>';
  }

  async function initSubmit() {
    me = Session.requireCustomer();
    if (!me) return;
    const [vs, mine, returned] = await Promise.all([
      api.get("/api/vehicles"), api.get(api.url(API, { customerId: me.id })), api.get(api.url("/api/bookings", { customerId: me.id, status: "RETURNED" }))
    ]);
    vehicles = vs;
    myReviews = mine.filter((r) => r.customerId === me.id);
    returned.forEach((b) => { returnedVehicles[b.vehicleId] = b.id; });
    // vehicles the customer rented come first
    vehicles.sort((a, b) => (returnedVehicles[b.id] ? 1 : 0) - (returnedVehicles[a.id] ? 1 : 0));
    $("vehicleId").innerHTML = vehicles.map((v) => '<option value="' + v.id + '">' + ui.escape(v.displayName) + " - " + v.plateNumber + (returnedVehicles[v.id] ? "  (you rented this)" : "") + "</option>").join("");
    if (ui.param("vehicleId")) $("vehicleId").value = ui.param("vehicleId");
    renderMine();

    const editId = ui.param("edit");
    if (editId) {
      editing = myReviews.find((r) => r.id === editId);
      if (editing) {
        $("formTitle").textContent = "Edit your review";
        $("crumb").textContent = "Edit";
        $("vehicleId").value = editing.vehicleId;
        $("vehicleId").disabled = true;
        $("title").value = editing.title;
        $("comment").value = editing.comment;
        $("submitReview").textContent = "Save changes";
        $("deleteOwn").classList.remove("hidden");
        $("cancelEdit").classList.remove("hidden");
        setRating(editing.rating);
      }
    }

    document.querySelectorAll("#starInput button").forEach((b) => {
      b.addEventListener("click", () => setRating(Number(b.dataset.v), true));
      b.addEventListener("mouseenter", () => {
        const n = Number(b.dataset.v);
        document.querySelectorAll("#starInput button").forEach((x) => x.classList.toggle("lit", Number(x.dataset.v) <= n));
        $("starWord").textContent = WORDS[n];
      });
    });
    $("starInput").addEventListener("mouseleave", () => setRating(rating));
    $("comment").addEventListener("input", () => { $("charCount").textContent = $("comment").value.length; preview(); });
    $("title").addEventListener("input", preview);
    $("vehicleId").addEventListener("change", preview);
    $("charCount").textContent = $("comment").value.length;
    preview();

    $("reviewForm").addEventListener("submit", async (e) => {
      e.preventDefault();
      if (!rating) { toast("Choose a star rating first", "error"); return; }
      const body = { customerId: me.id, vehicleId: $("vehicleId").value, rating, title: $("title").value.trim(), comment: $("comment").value.trim() };
      try {
        const saved = await ui.busy($("submitReview"), () => editing ? api.put(API + "/" + editing.id, body) : api.post(API, body));
        if (saved.status === "FLAGGED") {
          toast("Saved, but held for a moderator: " + saved.flagReason, "error");
        } else {
          toast(editing ? "Review updated" : "Thanks! Your review is live", "success");
        }
        setTimeout(() => { location.href = "/reviews/view.html?vehicleId=" + saved.vehicleId; }, 1100);
      } catch (err) { toast(err.message, "error"); ui.showFieldError($("reviewForm"), err.message); }
    });

    $("deleteOwn").addEventListener("click", async () => {
      const ok = await confirmDialog({ title: "Delete this review?", message: "It will be removed from reviews.txt and the vehicle's rating.", confirmText: "Delete", danger: true });
      if (!ok) return;
      try {
        await api.del(api.url(API + "/" + editing.id, { customerId: me.id }));
        toast("Review deleted", "success");
        setTimeout(() => { location.href = "/reviews/submit.html"; }, 700);
      } catch (err) { toast(err.message, "error"); }
    });
  }

  // ================================================================ view page
  let all = [];
  let viewFilter = "all";

  async function loadView() {
    const vehicleId = $("vehicleFilter").value;
    const s = Session.get();
    const [list, summary] = await Promise.all([
      api.get(api.url(API, { vehicleId, customerId: s && s.kind === "customer" ? s.id : "" })),
      api.get(api.url(API + "/summary", { vehicleId }))
    ]);
    all = list;
    ui.countUp($("avgScore"), summary.average, { decimals: 1 });
    $("avgStars").innerHTML = ui.stars(summary.average);
    $("avgCount").textContent = summary.count + (summary.count === 1 ? " review" : " reviews") + ", " + summary.verifiedCount + " verified";
    ui.countUp($("weightedScore"), summary.weightedAverage, { decimals: 1 });
    const max = Math.max(1, ...Object.values(summary.distribution));
    $("distribution").innerHTML = Object.entries(summary.distribution).sort((a, b) => b[0] - a[0]).map(([star, n]) =>
      '<button class="dist-row" data-star="' + star + '" title="Show ' + star + '-star reviews"><span>' + star + ' star</span><span class="track"><span class="fill" data-w="' + (n / max) * 100 + '%"></span></span><b>' + n + "</b></button>").join("");
    requestAnimationFrame(() => document.querySelectorAll(".dist-row .fill").forEach((f) => { f.style.width = f.dataset.w; }));
    renderView();
  }

  function renderView() {
    const sort = $("reviewSort").value;
    let list = all.slice();
    if (viewFilter === "verified") list = list.filter((r) => r.type === "VERIFIED");
    else if (viewFilter === "low") list = list.filter((r) => r.rating <= 3);
    else if (/^\d$/.test(viewFilter)) list = list.filter((r) => r.rating === Number(viewFilter));
    if (sort === "high") list.sort((a, b) => b.rating - a.rating);
    if (sort === "low") list.sort((a, b) => a.rating - b.rating);
    $("reviewList").innerHTML = list.length ? list.map(reviewCard).join("")
      : '<div class="empty"><h3>No reviews here yet</h3><p>Rented this vehicle? <a href="/reviews/submit.html">Write the first review</a>.</p></div>';
  }

  async function initView() {
    const vs = await api.get("/api/vehicles");
    $("vehicleFilter").insertAdjacentHTML("beforeend", vs.map((v) => '<option value="' + v.id + '">' + ui.escape(v.displayName) + "</option>").join(""));
    if (ui.param("vehicleId")) $("vehicleFilter").value = ui.param("vehicleId");
    await loadView();
    $("vehicleFilter").addEventListener("change", loadView);
    $("reviewSort").addEventListener("change", renderView);
    const setFilter = (f) => {
      viewFilter = f;
      document.querySelectorAll("#reviewChips .chip").forEach((c) => c.classList.toggle("on", c.dataset.f === f));
      renderView();
    };
    $("reviewChips").addEventListener("click", (e) => { const c = e.target.closest(".chip"); if (c) setFilter(c.dataset.f); });
    $("distribution").addEventListener("click", (e) => { const r = e.target.closest(".dist-row"); if (r) setFilter(r.dataset.star); });
  }

  // ================================================================ moderation page
  const mod = { status: "FLAGGED", q: "" };

  async function loadModeration() {
    const [list, everything] = await Promise.all([api.get(api.url(API + "/admin", mod)), api.get(API + "/admin")]);
    const counts = { ALL: everything.length, VISIBLE: 0, FLAGGED: 0, HIDDEN: 0 };
    everything.forEach((r) => { counts[r.status]++; });
    document.querySelectorAll("[data-count]").forEach((el) => { el.textContent = counts[el.dataset.count]; });
    $("modList").innerHTML = list.length ? list.map((r, i) =>
      '<article class="mod-card ' + r.status + '" data-id="' + r.id + '" style="animation-delay:' + i * 40 + 'ms"><div>' +
      '<div class="rc-head"><div>' + ui.stars(r.rating) + "<h4>" + ui.escape(r.title) + "</h4></div><div>" +
      ({ VISIBLE: '<span class="badge badge-go">Published</span>', FLAGGED: '<span class="badge badge-amber">Flagged</span>', HIDDEN: '<span class="badge">Hidden</span>' }[r.status]) +
      " " + (r.type === "VERIFIED" ? '<span class="badge badge-info">Verified</span>' : "") + "</div></div>" +
      '<p style="margin:8px 0 0">' + ui.escape(r.comment) + "</p>" +
      (r.flagReason ? '<div class="notice warn flag-reason">' + ui.icons.flag + "<span>" + ui.escape(r.flagReason) + "</span></div>" : "") +
      '<div class="mod-facts"><span>Review <b>' + r.id + "</b></span><span>By <b>" + ui.escape(r.author) + "</b> (" + r.customerId + ")</span><span>Vehicle <b>" + ui.escape(r.vehicleName) +
      "</b></span><span>Posted <b>" + ui.date(r.date) + "</b></span><span>Weight <b>" + r.weight + "</b></span>" + (r.bookingId ? "<span>Booking <b>" + r.bookingId + "</b></span>" : "") + "</div></div>" +
      '<div class="mod-actions">' +
      (r.status !== "VISIBLE" ? '<button class="btn btn-go btn-sm" data-act="VISIBLE">Publish</button>' : "") +
      (r.status !== "HIDDEN" ? '<button class="btn btn-ghost btn-sm" data-act="HIDDEN">Hide</button>' : "") +
      (r.status === "VISIBLE" ? '<button class="btn btn-ghost btn-sm" data-act="FLAGGED">Flag</button>' : "") +
      '<button class="btn btn-ghost btn-sm" data-act="DELETE" style="color:var(--stop)">Delete</button></div></article>').join("")
      : '<div class="empty"><h3>' + (mod.status === "FLAGGED" ? "Nothing waiting for review" : "No reviews here") + "</h3><p>" +
        (mod.status === "FLAGGED" ? "The automatic checker has not flagged anything new." : "Try another filter.") + "</p></div>";
  }

  function askReason(title) {
    return new Promise((resolve) => {
      const m = openModal("<h3>" + ui.escape(title) + '</h3><div class="field"><label for="reasonText">Reason (shown to the author)</label><input id="reasonText" value="Does not follow the review guidelines"></div>' +
        '<div class="form-actions"><button class="btn btn-ghost" data-close>Cancel</button><button class="btn btn-dark" id="reasonOk">Continue</button></div>');
      m.el.querySelector("#reasonOk").addEventListener("click", () => { const v = m.el.querySelector("#reasonText").value; m.close(); resolve(v); });
      m.el.querySelector("[data-close]").addEventListener("click", () => resolve(null));
    });
  }

  function initModerate() {
    const s = Session.requireAdmin();
    if (!s) return;
    loadModeration();
    $("modSearch").addEventListener("input", ui.debounce((e) => { mod.q = e.target.value; loadModeration(); }, 250));
    $("modChips").addEventListener("click", (e) => {
      const chip = e.target.closest(".chip");
      if (!chip) return;
      document.querySelectorAll("#modChips .chip").forEach((c) => c.classList.toggle("on", c === chip));
      mod.status = chip.dataset.status;
      loadModeration();
    });
    $("modList").addEventListener("click", async (e) => {
      const btn = e.target.closest("[data-act]");
      if (!btn) return;
      const card = btn.closest(".mod-card");
      const id = card.dataset.id;
      const act = btn.dataset.act;
      try {
        if (act === "DELETE") {
          const ok = await confirmDialog({ title: "Delete review " + id + "?", message: "It will be removed permanently from reviews.txt.", confirmText: "Delete", danger: true });
          if (!ok) return;
          await api.del(api.url(API + "/" + id, { adminId: s.id }));
          Session.logAdminAction("Deleted review " + id);
          toast("Review deleted", "success");
        } else {
          let reason = "";
          if (act !== "VISIBLE") {
            reason = await askReason(act === "HIDDEN" ? "Hide this review?" : "Flag this review?");
            if (reason === null) return;
          }
          await api.patch(API + "/" + id + "/status", { adminId: s.id, status: act, reason });
          Session.logAdminAction({ VISIBLE: "Published", HIDDEN: "Hid", FLAGGED: "Flagged" }[act] + " review " + id);
          toast({ VISIBLE: "Review published", HIDDEN: "Review hidden", FLAGGED: "Review flagged" }[act], "success");
        }
        card.classList.add("leaving");
        setTimeout(loadModeration, 380);
      } catch (err) { toast(err.message, "error"); }
    });
  }

  document.addEventListener("DOMContentLoaded", () => {
    const page = document.body.dataset.page;
    if (page === "submit") initSubmit();
    if (page === "view") initView();
    if (page === "moderate") initModerate();
  });
})();
