/* Home page behaviour (kickoff file, owned by the whole team).
   Reads live data from every module's API, so the home page shows each member's work. */

(function () {
  "use strict";

  const $ = (id) => document.getElementById(id);

  // ---------------------------------------------------------------- hero search (location + dates)
  async function setupSearch() {
    const start = $("hsStart");
    const end = $("hsEnd");
    start.value = ui.today();
    start.min = ui.today();
    end.value = ui.addDays(ui.today(), 2);
    end.min = start.value;
    start.addEventListener("change", () => {
      end.min = start.value;
      if (end.value < start.value) end.value = ui.addDays(start.value, 1);
    });
    try {
      const branches = await api.get("/api/branches");
      $("hsBranch").insertAdjacentHTML("beforeend", branches.map((b) => '<option value="' + b.id + '">' + ui.escape(b.name) + "</option>").join(""));
    } catch (e) { /* branch module not available */ }
    $("heroSearch").addEventListener("submit", (e) => {
      e.preventDefault();
      location.href = api.url("/vehicles/search.html", { branch: $("hsBranch").value, start: start.value, end: end.value });
    });
  }

  // ---------------------------------------------------------------- live strip (polls every 15 s)
  async function refreshLive() {
    const [vehicles, branches, summary] = await Promise.allSettled([
      api.get("/api/vehicles/stats"), api.get("/api/branches"), api.get("/api/reviews/summary")
    ]);
    const set = (id, value, opts) => {
      const el = $(id);
      if (String(el.dataset.current) !== String(value)) {
        if (el.dataset.current !== undefined) {
          const box = el.parentElement;
          box.classList.remove("flash"); void box.offsetWidth; box.classList.add("flash");
        }
        ui.countUp(el, value, opts);
      }
    };
    if (vehicles.status === "fulfilled") {
      const v = vehicles.value;
      set("statAvailable", v.byStatus.AVAILABLE || 0);
      set("statRented", v.byStatus.RENTED || 0);
      $("catCars").textContent = (v.byType.CAR || 0) + " cars";
      $("catVans").textContent = (v.byType.VAN || 0) + " vans";
      $("catMotorcycles").textContent = (v.byType.MOTORCYCLE || 0) + " motorcycles";
      $("featRange").textContent = v.total + " vehicles: cars, vans & motorcycles";
    }
    if (branches.status === "fulfilled") {
      set("statOpen", branches.value.filter((b) => b.openNow).length);
      renderBranches(branches.value);
    }
    if (summary.status === "fulfilled") {
      set("statRating", summary.value.average, { decimals: 1 });
      $("reviewSummaryText").textContent = summary.value.count + " published reviews, " + summary.value.verifiedCount +
        " from verified rentals, average " + summary.value.average + " out of 5.";
    }
    $("boardTime").textContent = new Date().toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit", second: "2-digit" });
  }

  // ---------------------------------------------------------------- fleet preview (photos)
  async function loadFleet() {
    const box = $("homeFleet");
    try {
      const list = await api.get("/api/vehicles?status=AVAILABLE");
      if (!list.length) {
        box.innerHTML = '<div class="empty"><h3>Every vehicle is out on the road</h3><p>Check back soon or browse the full fleet.</p></div>';
        return;
      }
      // a mix of types: take cars, vans and bikes in turn
      const byType = { CAR: [], VAN: [], MOTORCYCLE: [] };
      list.forEach((v) => (byType[v.type] || []).push(v));
      const mixed = [];
      for (let i = 0; mixed.length < 8 && i < list.length; i++) {
        ["CAR", "VAN", "MOTORCYCLE"].forEach((t) => { if (byType[t][i] && mixed.length < 8) mixed.push(byType[t][i]); });
      }
      box.innerHTML = mixed.map((v, i) => vehicleCard(v, i)).join("");
    } catch (e) {
      box.innerHTML = '<div class="empty"><h3>Fleet is unavailable</h3><p>' + ui.escape(e.message) + "</p></div>";
    }
  }

  function vehicleCard(v, i) {
    return '<article class="vehicle-card" style="animation-delay:' + i * 70 + 'ms">' +
      '<div class="art' + (v.imageUrl ? " photo" : "") + '">' + ui.vehicleStatusBadge(v.status) + '<span class="type-tag">' + ui.typeLabel(v.type) + "</span>" + ui.vehicleMedia(v) + "</div>" +
      '<div class="body"><div class="meta"><h3>' + ui.escape(v.brand + " " + v.model) + "</h3>" + ui.plate(v.plateNumber) + "</div>" +
      '<div class="features">' + v.features.map((f) => "<span>" + ui.escape(f) + "</span>").join("") + "</div>" +
      '<div class="foot"><div class="price">' + ui.money(v.dailyRate) + " <small>per day</small></div>" +
      '<a class="btn btn-sm" href="/bookings/book.html?vehicleId=' + v.id + '">Book</a></div></div></article>';
  }

  // ---------------------------------------------------------------- branches
  function renderBranches(list) {
    $("homeBranches").innerHTML = list.map((b) =>
      '<a class="branch-mini" href="/branches/list.html#' + b.id + '">' +
      (b.openNow ? '<span class="badge badge-go">Open now</span>' : '<span class="badge badge-stop">Closed</span>') +
      "<h4>" + ui.escape(b.name) + '</h4><div class="small">' + ui.escape(b.city) + " &middot; " + ui.escape(b.operatingHours) + "</div></a>"
    ).join("");
  }

  // ---------------------------------------------------------------- reviews marquee (with vehicle photos)
  async function loadReviews() {
    try {
      const [list, vehicles] = await Promise.all([api.get("/api/reviews"), api.get("/api/vehicles")]);
      if (!list.length) { $("reviewMarquee").innerHTML = '<div class="wrap"><div class="empty">No reviews yet. Rent a vehicle and be the first.</div></div>'; return; }
      const byId = {};
      vehicles.forEach((v) => { byId[v.id] = v; });
      const cards = list.map((r) =>
        '<article class="quote-card"><div class="q-photo">' + ui.vehicleMedia(byId[r.vehicleId] || { type: "CAR" }) + '</div><div class="q-body">' + ui.stars(r.rating) +
        "<h4>" + ui.escape(r.title) + "</h4><p>" + ui.escape(r.comment) + "</p>" +
        '<div class="who"><span>' + ui.escape(r.author) + " on " + ui.escape(r.vehicleName) + "</span>" +
        (r.type === "VERIFIED" ? '<span class="badge badge-go">Verified</span>' : "") + "</div></div></article>"
      ).join("");
      $("reviewTrack").innerHTML = cards + cards;          // duplicated for a seamless loop
    } catch (e) {
      $("reviewMarquee").innerHTML = "";
    }
  }

  document.addEventListener("DOMContentLoaded", () => {
    setupSearch();
    loadFleet();
    loadReviews();
    ui.poll(refreshLive, 15000);
  });
})();
