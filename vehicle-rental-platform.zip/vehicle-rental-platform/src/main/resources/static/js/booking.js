/* =====================================================================
   MEMBER 3 - Booking & Return Management (front end)
   Pages: book.html (Create), return.html (Update: return + late fee),
          list.html (Read active/overdue/completed, cancel, Delete completed)
   Talks to BookingController: /api/bookings
   ===================================================================== */

(function () {
  "use strict";

  const $ = (id) => document.getElementById(id);
  const API = "/api/bookings";

  function daysBetween(a, b) {
    return Math.round((new Date(b + "T00:00:00") - new Date(a + "T00:00:00")) / 86400000);
  }

  function statusBadge(b) {
    if (b.overdue) return '<span class="badge badge-stop">Overdue ' + b.daysLate + (b.daysLate === 1 ? " day" : " days") + "</span>";
    return { ACTIVE: '<span class="badge badge-info">Active</span>', RETURNED: '<span class="badge badge-go">Returned</span>', CANCELLED: '<span class="badge">Cancelled</span>' }[b.status];
  }

  // ================================================================ book page
  let vehicles = [];
  let customerId = null;
  let vehicleVisible = null;

  async function initBook() {
    const s = Session.get();
    if (!s) { Session.requireCustomer(); return; }
    const form = $("bookForm");

    if (s.kind === "admin") {
      $("customerField").classList.remove("hidden");
      const customers = await api.get("/api/customers");
      $("customerId").innerHTML = customers.map((c) => '<option value="' + c.id + '">' + ui.escape(c.fullName) + " (" + c.id + ", " + c.membershipTier.toLowerCase() + ")</option>").join("");
      customerId = customers.length ? customers[0].id : null;
      $("customerId").addEventListener("change", (e) => { customerId = e.target.value; refreshQuote(); });
    } else {
      customerId = s.id;
    }

    vehicles = await api.get("/api/vehicles?status=AVAILABLE");
    const wanted = ui.param("vehicleId");
    if (wanted && !vehicles.some((v) => v.id === wanted)) {
      try { vehicles.unshift(await api.get("/api/vehicles/" + wanted)); } catch (e) { /* ignore */ }
    }
    $("vehicleId").innerHTML = vehicles.length
      ? vehicles.map((v) => '<option value="' + v.id + '">' + ui.escape(v.displayName) + " - " + v.plateNumber + " - " + ui.money(v.dailyRate) + "/day</option>").join("")
      : '<option value="">No vehicles are free right now</option>';
    if (wanted) $("vehicleId").value = wanted;

    const today = ui.today();
    $("startDate").min = today;
    $("startDate").value = ui.param("start") && ui.param("start") >= today ? ui.param("start") : today;
    $("dueDate").value = ui.param("end") && ui.param("end") >= $("startDate").value ? ui.param("end") : ui.addDays($("startDate").value, 2);
    $("dueDate").min = $("startDate").value;

    $("vehicleId").addEventListener("change", () => { showPicked(); refreshQuote(); });
    $("startDate").addEventListener("change", () => {
      $("dueDate").min = $("startDate").value;
      if ($("dueDate").value < $("startDate").value) $("dueDate").value = $("startDate").value;
      refreshQuote();
    });
    $("dueDate").addEventListener("change", refreshQuote);
    $("quickDays").addEventListener("click", (e) => {
      const chip = e.target.closest("[data-days]");
      if (!chip) return;
      $("dueDate").value = ui.addDays($("startDate").value, Number(chip.dataset.days) - 1);
      document.querySelectorAll("#quickDays .chip").forEach((c) => c.classList.toggle("on", c === chip));
      refreshQuote();
    });

    showPicked();
    refreshQuote();

    form.addEventListener("submit", async (e) => {
      e.preventDefault();
      if (!$("vehicleId").value) { toast("There is no vehicle to book", "error"); return; }
      try {
        const b = await ui.busy($("confirmBtn"), () => api.post(API, {
          customerId, vehicleId: $("vehicleId").value, startDate: $("startDate").value, dueDate: $("dueDate").value
        }));
        if (Session.isAdmin()) Session.logAdminAction("Created booking " + b.id + " for " + b.customerName + " (" + b.vehicleName + ")");
        const ticket = $("ticket");
        ticket.classList.add("booked");
        ticket.insertAdjacentHTML("beforeend", '<span class="stamp">BOOKED</span>');
        $("tResult").innerHTML = '<div class="notice good" style="margin-top:12px">Booking ' + b.id + " is confirmed. Collect it on " + ui.date(b.startDate) + ".</div>" +
          '<div class="form-actions" style="justify-content:flex-start"><a class="btn btn-dark btn-sm" href="/bookings/list.html">View bookings</a><a class="btn btn-ghost btn-sm" href="/bookings/book.html">Book another</a></div>';
        $("confirmBtn").disabled = true;
        toast("Booking " + b.id + " confirmed", "success");
      } catch (err) {
        toast(err.message, "error");
        refreshQuote();
      }
    });
  }

  function showPicked() {
    const v = vehicles.find((x) => x.id === $("vehicleId").value);
    if (!v) { $("pickedVehicle").innerHTML = ""; return; }
    $("pickedVehicle").innerHTML = '<div class="picked-card"><div class="v-art' + (v.imageUrl ? " photo" : "") + '">' + ui.vehicleMedia(v) + "</div><div><strong>" + ui.escape(v.displayName) +
      '</strong><div class="small muted">' + ui.escape(v.category) + '</div><div class="features">' + v.features.map((f) => "<span>" + ui.escape(f) + "</span>").join("") + "</div></div></div>";
    if (vehicleVisible !== v.id) {
      $("ticketArt").innerHTML = ui.vehicleMedia(v);
      $("ticketArt").classList.toggle("photo", !!v.imageUrl);
      vehicleVisible = v.id;
    }
    $("tVehicle").textContent = v.displayName;
    $("tPlate").innerHTML = ui.plate(v.plateNumber);
  }

  const refreshQuote = ui.debounce(async () => {
    const start = $("startDate").value;
    const end = $("dueDate").value;
    $("tStart").textContent = ui.date(start);
    $("tEnd").textContent = ui.date(end);
    if (!$("vehicleId").value || !customerId) return;
    try {
      const q = await api.get(api.url(API + "/quote", { customerId, vehicleId: $("vehicleId").value, startDate: start, dueDate: end }));
      $("tDays").textContent = q.days;
      $("tStandard").textContent = ui.money(q.standardCost);
      $("tDiscount").innerHTML = q.discountRate ? '<span class="discount-line">- ' + ui.money(q.standardCost - q.finalCost) + " (" + Math.round(q.discountRate * 100) + "%)</span>" : "None";
      ui.countUp($("tTotal"), q.finalCost, { prefix: "Rs. ", duration: 500 });
      $("tPolicy").textContent = "Late returns: " + q.finePolicy;
      $("availBadge").className = "badge " + (q.available ? "badge-go" : "badge-stop");
      $("availBadge").textContent = q.available ? "Available" : "Not available";
      $("confirmBtn").disabled = !q.available;
    } catch (err) {
      $("availBadge").className = "badge badge-stop";
      $("availBadge").textContent = "Check dates";
      $("tPolicy").textContent = err.message;
      $("confirmBtn").disabled = true;
    }
  }, 150);

  // ================================================================ return page
  let actives = [];
  let selected = null;

  async function loadActives() {
    actives = await api.get(api.url(API, { status: "ACTIVE", q: $("activeSearch").value }));
    actives.sort((a, b) => (b.overdue - a.overdue) || a.dueDate.localeCompare(b.dueDate));
    $("activeList").innerHTML = actives.length ? actives.map((b) =>
      '<button class="active-item ' + (b.overdue ? "overdue " : "") + (selected === b.id ? "selected" : "") + '" data-id="' + b.id + '">' +
      ui.plate(b.plateNumber) + "<div><strong>" + ui.escape(b.vehicleName) + '</strong><div class="small">' + b.id + " &middot; " + ui.escape(b.customerName) + " &middot; due " + ui.date(b.dueDate) + "</div></div>" +
      statusBadge(b) + "</button>").join("")
      : '<div class="empty"><h3>No vehicles are out on rent</h3><p>Active bookings will appear here.</p></div>';
  }

  function openReturn(id) {
    const b = actives.find((x) => x.id === id);
    if (!b) return;
    selected = id;
    document.querySelectorAll(".active-item").forEach((el) => el.classList.toggle("selected", el.dataset.id === id));
    $("returnPanel").innerHTML =
      '<div class="panel-head"><h3>' + b.id + "</h3>" + statusBadge(b) + "</div>" +
      '<dl class="kv"><dt>Customer</dt><dd>' + ui.escape(b.customerName) + " (" + b.customerTier.toLowerCase() + ")</dd>" +
      "<dt>Vehicle</dt><dd>" + ui.escape(b.vehicleName) + "</dd><dt>Booked</dt><dd>" + ui.date(b.startDate) + " to " + ui.date(b.dueDate) + "</dd>" +
      "<dt>Rental price</dt><dd>" + ui.money(b.baseCost) + "</dd></dl>" +
      '<form id="returnForm" class="form-grid" style="margin-top:16px" novalidate>' +
      '<div class="field"><label for="returnDate">Return date</label><input type="date" id="returnDate" name="returnDate" value="' + ui.today() + '" min="' + b.startDate + '"></div>' +
      '<div class="field"><label for="kmDriven">Km driven</label><input type="number" id="kmDriven" name="kmDriven" min="0" value="0"></div>' +
      '<div class="full fine-box" id="fineBox"></div>' +
      '<div class="full"><button class="btn btn-go" type="submit" style="width:100%" id="returnBtn">Confirm return</button></div></form>';
    const form = $("returnForm");
    const preview = async () => {
      try {
        const f = await api.get(api.url(API + "/" + b.id + "/fine", { returnDate: $("returnDate").value }));
        $("fineBox").classList.toggle("late", f.daysLate > 0);
        $("fineBox").innerHTML = (f.daysLate > 0 ? "<strong>" + f.daysLate + (f.daysLate === 1 ? " day" : " days") + " late.</strong> " : "<strong>On time.</strong> ") +
          '<span class="small">' + ui.escape(f.policy) + '</span><div style="display:flex;justify-content:space-between;align-items:baseline;margin-top:8px"><span>Late fee</span><span class="big" id="fineAmount"></span></div>' +
          '<div style="display:flex;justify-content:space-between"><span>Total to collect</span><strong>' + ui.money(f.total) + "</strong></div>";
        ui.countUp($("fineAmount"), f.lateFee, { prefix: "Rs. ", duration: 500 });
      } catch (err) { $("fineBox").textContent = err.message; }
    };
    $("returnDate").addEventListener("change", preview);
    preview();
    form.addEventListener("submit", async (e) => {
      e.preventDefault();
      try {
        const done = await ui.busy($("returnBtn"), () => api.put(API + "/" + b.id + "/return", ui.formData(form)));
        Session.logAdminAction("Returned booking " + done.id + " (" + done.vehicleName + ")" + (done.lateFee ? ", late fee " + ui.money(done.lateFee) : ""));
        $("returnPanel").innerHTML = '<div style="text-align:center;padding:10px 0"><span class="stamp">RETURNED</span><h3 style="margin-top:18px">' + ui.escape(done.vehicleName) +
          ' is back</h3><p class="muted">It is available for new bookings again.</p><dl class="kv" style="text-align:left"><dt>Rental</dt><dd>' + ui.money(done.baseCost) +
          "</dd><dt>Late fee</dt><dd>" + ui.money(done.lateFee) + "</dd><dt>Total paid</dt><dd>" + ui.money(done.total) + "</dd></dl></div>";
        toast(done.vehicleName + " returned", "success");
        selected = null;
        loadActives();
      } catch (err) { toast(err.message, "error"); }
    });
  }

  async function initReturn() {
    if (!Session.requireAdmin()) return;
    await loadActives();
    $("activeList").addEventListener("click", (e) => { const item = e.target.closest(".active-item"); if (item) openReturn(item.dataset.id); });
    $("activeSearch").addEventListener("input", ui.debounce(loadActives, 250));
    if (ui.param("id")) openReturn(ui.param("id"));
  }

  // ================================================================ list page
  const listFilter = { status: "", q: "" };
  let mine = false;

  function dueInfo(b) {
    if (b.status !== "ACTIVE") {
      return b.status === "RETURNED" ? "Returned " + ui.date(b.returnDate) + (b.lateFee ? " (late fee " + ui.money(b.lateFee) + ")" : "") : "Cancelled";
    }
    const total = Math.max(1, b.rentalDays);
    const used = Math.min(total, Math.max(0, daysBetween(b.startDate, ui.today()) + 1));
    const cls = b.overdue ? "late" : b.daysUntilDue <= 1 ? "warn" : "";
    const text = b.overdue ? "Overdue by " + b.daysLate + (b.daysLate === 1 ? " day" : " days")
      : b.daysUntilDue === 0 ? "Due back today" : b.daysUntilDue < 0 ? "Due" : "Due in " + b.daysUntilDue + (b.daysUntilDue === 1 ? " day" : " days");
    const pct = b.overdue ? 100 : daysBetween(b.startDate, ui.today()) < 0 ? 0 : (used / total) * 100;
    return text + '<div class="due-bar ' + cls + '"><span style="width:0" data-w="' + pct + '%"></span></div>';
  }

  async function loadBookings() {
    const s = Session.get();
    const params = Object.assign({}, listFilter, mine ? { customerId: s.id } : {});
    const list = await api.get(api.url(API, params));
    list.sort((a, b) => b.id.localeCompare(a.id));
    const box = $("bookingList");
    if (!list.length) {
      box.innerHTML = '<div class="empty"><h3>No bookings here</h3><p>' + (mine ? 'You have no bookings with this status. <a href="/bookings/book.html">Book a vehicle</a>.' : "Try another filter.") + "</p></div>";
      return;
    }
    box.innerHTML = list.map((b, i) =>
      '<div class="booking-row ' + (b.overdue ? "overdue" : "") + '" data-id="' + b.id + '" style="animation-delay:' + Math.min(i, 12) * 40 + 'ms">' +
      ui.plate(b.plateNumber) +
      "<div><strong>" + ui.escape(b.vehicleName) + '</strong><div class="small muted">' + b.id + (mine ? "" : " &middot; " + ui.escape(b.customerName)) + "</div></div>" +
      '<div class="when"><strong>' + ui.date(b.startDate) + " to " + ui.date(b.dueDate) + '</strong><span class="small muted">' + dueInfo(b) + "</span></div>" +
      "<div>" + statusBadge(b) + '<div style="font-weight:800;margin-top:4px">' + ui.money(b.total) + "</div></div>" +
      '<div class="actions">' +
      (b.status === "ACTIVE" && !mine ? '<a class="btn btn-go btn-sm" href="/bookings/return.html?id=' + b.id + '">Return</a>' : "") +
      (b.status === "ACTIVE" ? '<button class="btn btn-ghost btn-sm" data-cancel>Cancel</button>' : "") +
      (b.status !== "ACTIVE" && !mine ? '<button class="btn btn-ghost btn-sm" data-delete style="color:var(--stop)">Delete</button>' : "") +
      (b.status === "RETURNED" && mine ? '<a class="btn btn-ghost btn-sm" href="/reviews/submit.html?vehicleId=' + b.vehicleId + '">Review</a>' : "") +
      "</div></div>").join("");
    requestAnimationFrame(() => box.querySelectorAll(".due-bar span").forEach((el) => { el.style.width = el.dataset.w; }));
  }

  async function loadBookingStats() {
    const s = Session.get();
    if (mine) {
      const all = await api.get(api.url(API, { customerId: s.id }));
      ui.countUp($("sActive"), all.filter((b) => b.status === "ACTIVE").length);
      ui.countUp($("sOverdue"), all.filter((b) => b.overdue).length);
      ui.countUp($("sReturned"), all.filter((b) => b.status === "RETURNED").length);
      $("sMoneyLabel").textContent = "Total spent";
      ui.countUp($("sRevenue"), all.filter((b) => b.status === "RETURNED").reduce((t, b) => t + b.total, 0), { prefix: "Rs. " });
    } else {
      const st = await api.get(API + "/stats");
      ui.countUp($("sActive"), st.active);
      ui.countUp($("sOverdue"), st.overdue);
      ui.countUp($("sReturned"), st.returned);
      ui.countUp($("sRevenue"), st.revenue, { prefix: "Rs. " });
    }
  }

  async function initList() {
    const s = Session.get();
    if (!s) { Session.requireCustomer(); return; }
    mine = s.kind === "customer";
    if (mine) {
      $("listTitle").textContent = "My bookings";
      $("crumbLabel").textContent = "My bookings";
      $("listSub").textContent = "Your rentals, how many days are left and what you paid.";
      document.body.dataset.nav = "";
    }
    const refresh = () => { loadBookings(); loadBookingStats(); };
    refresh();
    setInterval(() => { if (!document.hidden) refresh(); }, 30000);    // keep due dates live

    $("bookingSearch").addEventListener("input", ui.debounce((e) => { listFilter.q = e.target.value; loadBookings(); }, 250));
    $("bookingChips").addEventListener("click", (e) => {
      const chip = e.target.closest(".chip");
      if (!chip) return;
      document.querySelectorAll("#bookingChips .chip").forEach((c) => c.classList.toggle("on", c === chip));
      listFilter.status = chip.dataset.status;
      loadBookings();
    });
    $("bookingList").addEventListener("click", async (e) => {
      const row = e.target.closest(".booking-row");
      if (!row) return;
      const id = row.dataset.id;
      if (e.target.closest("[data-cancel]")) {
        const ok = await confirmDialog({ title: "Cancel booking " + id + "?", message: "The vehicle will be released for other customers.", confirmText: "Cancel booking", cancelText: "Keep it", danger: true });
        if (!ok) return;
        try {
          await api.put(API + "/" + id + "/cancel");
          if (!mine) Session.logAdminAction("Cancelled booking " + id);
          toast("Booking " + id + " cancelled", "success");
          refresh();
        } catch (err) { toast(err.message, "error"); }
      }
      if (e.target.closest("[data-delete]")) {
        const ok = await confirmDialog({ title: "Delete " + id + "?", message: "This completed transaction will be removed from bookings.txt.", confirmText: "Delete", danger: true });
        if (!ok) return;
        try {
          await api.del(API + "/" + id);
          Session.logAdminAction("Deleted completed booking " + id);
          row.classList.add("leaving");
          setTimeout(refresh, 400);
          toast("Booking deleted", "success");
        } catch (err) { toast(err.message, "error"); }
      }
    });
  }

  document.addEventListener("DOMContentLoaded", () => {
    const page = document.body.dataset.page;
    if (page === "book") initBook();
    if (page === "return") initReturn();
    if (page === "list") initList();
  });
})();
