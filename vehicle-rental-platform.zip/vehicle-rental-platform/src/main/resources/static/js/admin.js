/* =====================================================================
   MEMBER 4 - Admin & Staff Management (front end)
   Pages: login.html, dashboard.html (reads all modules), register.html (Create / Update with ?id=),
          staff.html (Read, activate/deactivate, Delete, activity logs)
   Talks to AdminController: /api/admins
   ===================================================================== */

(function () {
  "use strict";

  const $ = (id) => document.getElementById(id);
  const API = "/api/admins";
  const roleBadge = (role, label) => '<span class="badge ' + ({ SUPER_ADMIN: "badge-stop", MANAGER: "badge-info", STAFF: "badge-amber" }[role] || "") + '">' + ui.escape(label) + "</span>";

  // ================================================================ login
  function initLogin() {
    if (Session.isAdmin()) { location.href = "/admin/dashboard.html"; return; }
    const form = $("adminLoginForm");
    form.addEventListener("submit", async (e) => {
      e.preventDefault();
      try {
        const admin = await ui.busy($("adminLoginBtn"), () => api.post(API + "/login", ui.formData(form)));
        Session.setAdmin(admin);
        toast("Welcome, " + admin.fullName, "success");
        const next = ui.param("next");
        setTimeout(() => { location.href = next && next.startsWith("/") ? next : "/admin/dashboard.html"; }, 400);
      } catch (err) {
        form.animate([{ transform: "translateX(-8px)" }, { transform: "translateX(8px)" }, { transform: "none" }], { duration: 300 });
        toast(err.message, "error");
      }
    });
  }

  // ================================================================ dashboard
  const STATUS_COLOURS = { AVAILABLE: "#0f9d7a", RENTED: "#c98a00", MAINTENANCE: "#d9443b" };     // validated status palette
  const STATUS_LABELS = { AVAILABLE: "Available", RENTED: "On rent", MAINTENANCE: "In maintenance" };
  let seenLogs = new Set();

  function donut(byStatus, total) {
    const r = 70;
    const c = 2 * Math.PI * r;
    let offset = 0;
    const gap = total > 1 ? 2 : 0;          // small surface gap between segments
    let segs = "";
    Object.keys(STATUS_COLOURS).forEach((k) => {
      const n = byStatus[k] || 0;
      if (!n) return;
      const len = (n / total) * c;
      segs += '<circle class="seg" cx="95" cy="95" r="' + r + '" fill="none" stroke="' + STATUS_COLOURS[k] + '" stroke-width="22" ' +
        'stroke-dasharray="' + Math.max(0, len - gap) + " " + (c - Math.max(0, len - gap)) + '" stroke-dashoffset="' + -offset + '"><title>' +
        STATUS_LABELS[k] + ": " + n + " (" + Math.round((n / total) * 100) + "%)</title></circle>";
      offset += len;
    });
    $("fleetDonut").innerHTML = '<svg viewBox="0 0 190 190"><circle cx="95" cy="95" r="' + r + '" fill="none" stroke="#eef1f5" stroke-width="22"/>' + segs + "</svg>" +
      '<div class="center"><div><strong>' + total + "</strong><span>vehicles</span></div></div>";
    $("fleetLegend").innerHTML = Object.keys(STATUS_COLOURS).map((k) =>
      '<li><i style="background:' + STATUS_COLOURS[k] + '"></i>' + STATUS_LABELS[k] + "<b>" + (byStatus[k] || 0) + "</b></li>").join("");
  }

  function bars(host, rows) {
    const max = Math.max(1, ...rows.map((r) => r[1]));
    host.innerHTML = rows.map((r) =>
      '<div class="bar-row" title="' + r[0] + ": " + r[1] + '"><span>' + r[0] + '</span><div class="bar-track"><div class="bar-fill" data-w="' + (r[1] / max) * 100 + '%"></div></div><b>' + r[1] + "</b></div>").join("");
    requestAnimationFrame(() => host.querySelectorAll(".bar-fill").forEach((b) => { b.style.width = b.dataset.w; }));
  }

  async function refreshDashboard() {
    const get = (url) => api.get(url).catch(() => null);
    const [vStats, bStats, customers, branches, rSummary, actives, logs, allBookings] = await Promise.all([
      get("/api/vehicles/stats"), get("/api/bookings/stats"), get("/api/customers"), get("/api/branches"),
      get("/api/reviews/summary"), get("/api/bookings?status=ACTIVE"), get(API + "/logs/recent?limit=20"), get("/api/bookings")
    ]);

    if (bStats) {
      ui.countUp($("kRevenue"), bStats.revenue, { prefix: "Rs. " });
      $("kFees").textContent = "incl. " + ui.money(bStats.lateFees) + " late fees";
      ui.countUp($("kActive"), bStats.active);
      ui.countUp($("kOverdue"), bStats.overdue);
      document.querySelector(".kpi-alert").classList.toggle("has", bStats.overdue > 0);
    }
    if (vStats) {
      $("kUtil").textContent = Math.round(((vStats.byStatus.RENTED || 0) / Math.max(1, vStats.total)) * 100) + "% of the fleet";
      donut(vStats.byStatus, vStats.total);
      bars($("typeBars"), [["Cars", vStats.byType.CAR || 0], ["Vans", vStats.byType.VAN || 0], ["Motorcycles", vStats.byType.MOTORCYCLE || 0]]);
    }
    if (allBookings) {
      const count = (s) => allBookings.filter((b) => b.status === s).length;
      bars($("bookingBars"), [["Active", count("ACTIVE")], ["Returned", count("RETURNED")], ["Cancelled", count("CANCELLED")]]);
    }
    if (customers) {
      ui.countUp($("kCustomers"), customers.length);
      $("kPremium").textContent = customers.filter((c) => c.membershipTier === "PREMIUM").length + " premium";
    }
    if (branches) {
      ui.countUp($("kBranches"), branches.filter((b) => b.openNow).length);
      $("kBranchTotal").textContent = "of " + branches.length + " branches";
    }
    if (rSummary) {
      ui.countUp($("kRating"), rSummary.average, { decimals: 1 });
      $("kFlagged").textContent = rSummary.flaggedCount + (rSummary.flaggedCount === 1 ? " review flagged" : " reviews flagged");
      $("qaFlagged").textContent = rSummary.flaggedCount ? rSummary.flaggedCount + " waiting for a decision" : "Nothing flagged right now";
    }
    if (actives) {
      const due = actives.filter((b) => b.overdue || b.daysUntilDue <= 0).sort((a, b) => b.daysLate - a.daysLate);
      $("dueList").innerHTML = due.length ? due.map((b) =>
        '<div class="due-item ' + (b.overdue ? "late" : "") + '">' + ui.plate(b.plateNumber) + "<div><strong>" + ui.escape(b.vehicleName) + '</strong><div class="small">' +
        ui.escape(b.customerName) + " &middot; due " + ui.date(b.dueDate) + (b.overdue ? ", " + b.daysLate + (b.daysLate === 1 ? " day" : " days") + " late" : ", due today") + "</div></div>" +
        '<a class="btn btn-sm btn-go" href="/bookings/return.html?id=' + b.id + '">Return</a></div>').join("")
        : '<div class="empty" style="padding:24px">Nothing overdue. Every vehicle is on schedule.</div>';
    }
    if (logs) {
      const firstLoad = seenLogs.size === 0;
      $("activityFeed").innerHTML = logs.map((l) => {
        const key = l.adminId + l.timestamp + l.action;
        const isNew = !firstLoad && !seenLogs.has(key);
        seenLogs.add(key);
        return '<li class="' + (isNew ? "new" : "") + '">' + ui.escape(l.action) + '<div class="meta">' + l.adminId + " &middot; " + ui.timeAgo(l.timestamp) + "</div></li>";
      }).join("") || '<li class="muted">No activity yet.</li>';
    }
    $("lastUpdate").textContent = new Date().toLocaleTimeString("en-GB");
  }

  function initDashboard() {
    const s = Session.requireAdmin();
    if (!s) return;
    const hour = new Date().getHours();
    $("greeting").textContent = (hour < 12 ? "Good morning, " : hour < 17 ? "Good afternoon, " : "Good evening, ") + s.name.split(" ")[0];
    $("roleLine").textContent = "Signed in as " + (s.roleLabel || "staff") + ". Figures refresh every 15 seconds.";
    document.querySelectorAll("#quickActions [data-perm]").forEach((a) => {
      if (!Session.can(a.dataset.perm)) { a.classList.add("locked"); a.title = "Your role does not include: " + a.dataset.perm; }
    });
    ui.poll(refreshDashboard, 15000);
  }

  // ================================================================ register / edit staff
  async function initRegister() {
    const s = Session.requireAdmin();
    if (!s) return;
    const form = $("staffForm");
    const editId = ui.param("id");
    const canManage = Session.can("Manage staff");

    try {
      const roles = await api.get(API + "/roles");
      roles.forEach((r) => {
        const el = document.querySelector('.perm-list[data-role="' + r.role + '"]');
        if (el) el.textContent = r.permissions.join(", ");
      });
    } catch (e) { /* optional */ }

    const preview = () => {
      const d = ui.formData(form);
      const roleInput = form.querySelector('input[name="role"]:checked');
      const label = roleInput ? roleInput.nextElementSibling.querySelector("strong").textContent : "";
      $("bcName").textContent = d.fullName || "New staff member";
      $("bcAvatar").textContent = d.fullName ? ui.initials(d.fullName) : "?";
      $("bcRole").textContent = label;
      $("bcEmail").textContent = d.email || "name@vehiclerental.lk";
      $("badgeCard").className = "badge-card " + (roleInput ? roleInput.value : "");
    };
    form.addEventListener("input", preview);
    form.addEventListener("change", preview);

    if (editId) {
      if (!canManage && editId !== s.id) { toast("Only a Super admin can edit other staff accounts", "error"); setTimeout(() => history.back(), 1200); return; }
      const a = await api.get(API + "/" + editId);
      $("formTitle").textContent = editId === s.id ? "My staff profile" : "Edit " + a.fullName;
      $("crumb").textContent = "Edit";
      $("formSub").textContent = a.id + ", joined " + ui.date(a.joinedDate) + ". Leave the password empty to keep the current one.";
      $("saveStaff").textContent = "Save changes";
      $("pwLabel").textContent = "New password";
      $("pwHint").textContent = "Optional";
      ui.fillForm(form, { fullName: a.fullName, username: a.username, email: a.email, phone: a.phone, role: a.role });
      $("username").disabled = true;
      if (!canManage) form.querySelectorAll('input[name="role"]').forEach((r) => { r.disabled = true; });
      $("logPanel").hidden = false;
      const logs = await api.get(API + "/" + editId + "/logs");
      $("ownLogs").innerHTML = logs.slice(0, 12).map((l) => "<li>" + ui.escape(l.action) + '<div class="meta">' + ui.timeAgo(l.timestamp) + "</div></li>").join("") || "<li>No activity yet.</li>";
    } else if (!canManage) {
      $("formSub").textContent = "Only a Super admin can register new staff. Ask a Super admin to create the account.";
      form.querySelectorAll("input,button[type=submit]").forEach((el) => { el.disabled = true; });
    }
    preview();

    form.addEventListener("submit", async (e) => {
      e.preventDefault();
      const data = ui.formData(form);
      data.actingAdminId = s.id;
      if (editId && !data.password) delete data.password;
      if (editId && !canManage) delete data.role;
      try {
        const saved = await ui.busy($("saveStaff"), () => editId ? api.put(API + "/" + editId, data) : api.post(API, data));
        if (saved.id === s.id) Session.setAdmin(saved);
        toast(editId ? "Staff account saved" : "Staff account " + saved.username + " created", "success");
        if (!editId) setTimeout(() => { location.href = "/admin/staff.html"; }, 800);
      } catch (err) { toast(err.message, "error"); ui.showFieldError(form, err.message); }
    });
  }

  // ================================================================ staff management panel
  const staffFilter = { q: "", role: "" };

  async function loadStaff() {
    const s = Session.get();
    const canManage = Session.can("Manage staff");
    const list = await api.get(api.url(API, staffFilter));
    $("staffGrid").innerHTML = list.length ? list.map((a, i) =>
      '<article class="staff-card-item ' + (a.active ? "" : "inactive") + '" data-id="' + a.id + '" style="animation-delay:' + i * 50 + 'ms">' +
      '<div class="sc-top"><span class="avatar">' + ui.initials(a.fullName) + "</span><div><strong>" + ui.escape(a.fullName) + (a.id === s.id ? ' <span class="small muted">(you)</span>' : "") +
      '</strong><div class="small muted">@' + ui.escape(a.username) + " &middot; " + a.id + "</div></div>" + roleBadge(a.role, a.roleLabel) + "</div>" +
      '<div class="small muted">' + ui.escape(a.email) + " &middot; " + ui.escape(a.phone) + "</div>" +
      '<div class="sc-perms">' + a.permissions.map((p) => "<span>" + ui.escape(p) + "</span>").join("") + "</div>" +
      '<div class="small">' + (a.lastActive ? "Last active " + ui.timeAgo(a.lastActive) : "No activity yet") + " &middot; " + a.activityCount + " logged actions</div>" +
      '<div class="sc-foot"><label class="toggle-label"><span class="switch"><input type="checkbox" data-active ' + (a.active ? "checked" : "") +
      (canManage && a.id !== s.id ? "" : " disabled") + '><span></span></span>' + (a.active ? "Active" : "Deactivated") + "</label>" +
      '<div class="actions"><button class="btn btn-ghost btn-sm" data-logs>Activity</button>' +
      (canManage || a.id === s.id ? '<a class="btn btn-ghost btn-sm" href="/admin/register.html?id=' + a.id + '">Edit</a>' : "") +
      (canManage && a.id !== s.id ? '<button class="btn btn-ghost btn-sm" data-delete style="color:var(--stop)">Delete</button>' : "") +
      "</div></div></article>").join("")
      : '<div class="empty">No staff match this search.</div>';
    document.querySelectorAll(".staff-card-item").forEach((el) => { el.__data = list.find((a) => a.id === el.dataset.id); });
  }

  function initStaff() {
    const s = Session.requireAdmin();
    if (!s) return;
    if (!Session.can("Manage staff")) $("permNotice").classList.remove("hidden");
    loadStaff();
    $("staffSearch").addEventListener("input", ui.debounce((e) => { staffFilter.q = e.target.value; loadStaff(); }, 250));
    $("roleChips").addEventListener("click", (e) => {
      const chip = e.target.closest(".chip");
      if (!chip) return;
      document.querySelectorAll("#roleChips .chip").forEach((c) => c.classList.toggle("on", c === chip));
      staffFilter.role = chip.dataset.role;
      loadStaff();
    });
    $("staffGrid").addEventListener("change", async (e) => {
      if (!e.target.matches("[data-active]")) return;
      const card = e.target.closest(".staff-card-item");
      try {
        await api.patch(API + "/" + card.dataset.id + "/active", { active: e.target.checked, actingAdminId: s.id });
        toast(card.__data.fullName + (e.target.checked ? " can sign in again" : " can no longer sign in"), "success");
        loadStaff();
      } catch (err) { e.target.checked = !e.target.checked; toast(err.message, "error"); }
    });
    $("staffGrid").addEventListener("click", async (e) => {
      const card = e.target.closest(".staff-card-item");
      if (!card) return;
      const a = card.__data;
      if (e.target.closest("[data-logs]")) {
        const logs = await api.get(API + "/" + a.id + "/logs");
        openModal("<h3>Activity of " + ui.escape(a.fullName) + '</h3><p class="small muted">' + logs.length + " logged actions, newest first</p>" +
          '<ol class="feed">' + (logs.map((l) => "<li>" + ui.escape(l.action) + '<div class="meta">' + new Date(l.timestamp).toLocaleString("en-GB") + "</div></li>").join("") || "<li>No activity.</li>") +
          '</ol><div class="form-actions"><button class="btn btn-dark" data-close>Close</button></div>', true);
      }
      if (e.target.closest("[data-delete]")) {
        const ok = await confirmDialog({ title: "Delete " + a.fullName + "?", message: "The account and its " + a.activityCount + " activity log entries will be removed.", confirmText: "Delete account", danger: true });
        if (!ok) return;
        try {
          await api.del(api.url(API + "/" + a.id, { actingAdminId: s.id }));
          card.classList.add("leaving");
          setTimeout(loadStaff, 400);
          toast("Staff account deleted", "success");
        } catch (err) { toast(err.message, "error"); }
      }
    });
  }

  document.addEventListener("DOMContentLoaded", () => {
    const page = document.body.dataset.page;
    if (page === "login") initLogin();
    if (page === "dashboard") initDashboard();
    if (page === "register") initRegister();
    if (page === "staff") initStaff();
  });
})();
